/*! TipTong Extension — © 2026 TipTong. All rights reserved.
 * Proprietary software. No license is granted to copy, modify, or redistribute. */(function(){"use strict";const F={brandElectricViolet:"#4E15FF",brandEnergeticGreen:"#0FFFB9",brandDarkViolet:"#160751",brandBrightOrange:"#FF5400",brandBrightYellow:"#FFDE00",brandWhite:"#FFFFFF",supportLavender:"#B6A6EB"},O={familyDisplay:"Bryant, Nunito, Montserrat, system-ui, sans-serif",familySans:'Montserrat, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif',sizeHero:"48px",sizeH1:"32px",sizeH2:"24px",sizeLabel:"18px",sizeBody:"16px",sizeSmall:"14px"},j={tile:"2px",sm:"5px",md:"12px",lg:"16px",xl:"24px",pill:"100px"},b={display:O.familyDisplay,sans:O.familySans,hero:O.sizeHero,h1:O.sizeH1,h2:O.sizeH2,label:O.sizeLabel,body:O.sizeBody,small:O.sizeSmall},C={tile:j.tile,sm:j.sm,md:j.md,lg:j.lg,xl:j.xl,pill:j.pill},r={violet:F.brandElectricViolet,green:F.brandEnergeticGreen,orange:F.brandBrightOrange,yellow:F.brandBrightYellow,dark:F.brandDarkViolet,white:F.brandWhite,lavender:F.supportLavender,greenInk:"#0A9E74"},W={gradient:`linear-gradient(170deg, #14406B 0%, #16265C 55%, ${r.dark} 100%)`,card:"rgba(255,255,255,0.06)",cardBorder:"1px solid rgba(255,255,255,0.12)"},He=`
.tt-highlight {
  background-color: ${r.violet}20 !important;
  border-bottom: 2px solid ${r.violet}60 !important;
  border-radius: ${C.tile} !important;
  cursor: pointer !important;
  transition: background-color 0.15s !important;
  position: relative !important;
  display: inline !important;
}
.tt-highlight:hover {
  background-color: ${r.violet}35 !important;
}
.tt-highlight--answer {
  background-color: ${r.green}20 !important;
  border-bottom-color: ${r.green}60 !important;
}
.tt-highlight--answer:hover {
  background-color: ${r.green}35 !important;
}
.tt-highlight--delete {
  background-color: ${r.orange}20 !important;
  border-bottom-color: ${r.orange} !important;
  text-decoration: line-through !important;
  cursor: pointer !important;
}
.tt-underline {
  border-bottom: 2px dotted ${r.green} !important;
  font-weight: bold !important;
  background-color: ${r.green}20 !important;
  border-radius: ${C.tile} !important;
  cursor: pointer !important;
}
.tt-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  border-radius: ${C.sm};
  color: white;
  font-size: ${b.small};
  font-weight: bold;
  margin-right: 3px;
  vertical-align: middle;
  line-height: 16px;
}
.tt-badge--q { background-color: ${r.violet}; }
.tt-badge--a { background-color: ${r.green}; }

/* Interactive sentence (HHH inline blanks) */
.tt-sentence {
  font-size: ${b.body};
  line-height: 2;
  background: ${W.card};
  border: ${W.cardBorder};
  border-radius: ${C.md};
  padding: 12px 16px;
  margin-bottom: 12px;
  color: ${r.white};
}
.tt-sentence-text { color: ${r.white}; }
.tt-inline-blank {
  font-weight: bold;
  color: ${r.lavender};
  background: ${r.white}10;
  border-radius: ${C.sm};
  padding: 2px 6px;
  cursor: pointer;
}
.tt-inline-blank--active {
  background: ${r.green}20;
  color: ${r.green};
}
.tt-inline-char { font-size: ${b.body}; }
.tt-inline-char--revealed { color: ${r.white}; background: ${r.green}; border-radius: ${C.tile}; padding: 0 1px; }
.tt-inline-char--correct { color: ${r.green}; font-weight: bold; }
.tt-inline-char--wrong { color: ${r.orange}; font-weight: bold; }
.tt-inline-char--empty { color: ${r.white}30; }
.tt-solved {
  font-weight: bold;
  color: ${r.green};
  background: ${r.green}10;
  border-radius: ${C.sm};
  padding: 2px 4px;
}

/* Word progress dots */
.tt-word-progress {
  display: flex;
  gap: 12px;
  justify-content: center;
  margin-bottom: 12px;
}
.tt-word-dot {
  width: 24px;
  height: 24px;
  border-radius: ${C.md};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: ${b.small};
  font-weight: 600;
  cursor: pointer;
  background: ${r.white}20;
  color: ${r.white};
  opacity: 0.6;
}
.tt-word-dot--done { background: ${r.green}; opacity: 1; }
.tt-word-dot--active { background: ${r.white}; color: ${r.green}; border: 2px solid ${r.green}; opacity: 1; }

/* Answer box */
.tt-answer-box {
  background: ${r.white}10;
  border-radius: ${C.md};
  padding: 12px;
  margin-top: 8px;
  border: 1px solid ${r.green}40;
}
.tt-answer-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}
.tt-answer-label {
  font-size: ${b.small};
  color: ${r.white};
  opacity: 0.6;
  text-transform: uppercase;
  letter-spacing: 1px;
}
.tt-bulb {
  /* The browser must not turn the fan drag into a scroll or text selection. */
  touch-action: none;
  user-select: none;
  background: ${r.white}15;
  border: none;
  border-radius: ${C.lg};
  width: 32px;
  height: 32px;
  font-size: ${b.body};
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
}
.tt-bulb:hover, .tt-bulb--active { background: ${r.yellow}40; }
.tt-hint-container { margin-bottom: 8px; }
.tt-blank--active { border-bottom-color: ${r.green}; }

/* Player popup */
.tt-popup {
  position: fixed;
  bottom: 20px;
  right: 20px;
  width: 380px;
  max-width: calc(100vw - 40px);
  background: ${W.gradient};
  border: ${W.cardBorder};
  border-radius: ${C.xl};
  box-shadow: 0 8px 32px rgba(0,0,0,0.4);
  z-index: 999999;
  font-family: ${b.sans};
  color: ${r.white};
  overflow: hidden;
}
.tt-popup__header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px;
  background: ${W.card};
  border-bottom: ${W.cardBorder};
}
.tt-popup__title {
  font-family: ${b.display};
  font-size: ${b.small};
  font-weight: 800;
  letter-spacing: 0.02em;
  color: ${r.green};
}
.tt-popup__close {
  background: none;
  border: none;
  color: ${r.white};
  font-size: ${b.label};
  cursor: pointer;
  opacity: 0.7;
  padding: 4px;
}
.tt-popup__minimize {
  background: none;
  border: none;
  color: ${r.white};
  font-size: ${b.small};
  cursor: pointer;
  opacity: 0.7;
  padding: 4px;
}
.tt-popup__close:hover, .tt-popup__minimize:hover { opacity: 1; }
.tt-popup__body {
  padding: 16px;
}
.tt-popup__question {
  font-size: ${b.body};
  line-height: 1.5;
  margin-bottom: 16px;
  color: ${r.white};
}

/* Blank boxes */
.tt-blanks {
  display: flex;
  flex-wrap: wrap;
  gap: 3px;
  margin-bottom: 12px;
}
.tt-blank-word-gap { width: 12px; }
.tt-blank {
  width: 22px;
  height: 28px;
  border-radius: ${C.sm};
  background: ${r.white}15;
  border-bottom: 2px solid ${r.violet}40;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: ${b.small};
  font-weight: bold;
  color: ${r.white}50;
}
.tt-blank--correct {
  color: ${r.green};
  background: ${r.green}15;
  border-bottom-color: ${r.green};
}
.tt-blank--wrong {
  color: ${r.orange};
  background: ${r.orange}15;
  border-bottom-color: ${r.orange};
}
.tt-blank--revealed {
  color: ${r.white};
  background: ${r.green};
  border-bottom-color: ${r.green};
}
.tt-blank--shuffled {
  color: ${r.yellow};
  background: ${r.yellow}15;
  border-bottom-color: ${r.yellow}40;
}

/* Input */
.tt-input {
  width: 100%;
  height: 40px;
  background: ${r.white}15;
  border: none;
  border-radius: ${C.sm};
  color: ${r.white};
  font-size: ${b.body};
  text-align: center;
  font-weight: 600;
  outline: none;
  box-sizing: border-box;
  padding: 0 12px;
}
.tt-input::placeholder { color: ${r.white}40; }
.tt-input:focus { box-shadow: 0 0 0 2px ${r.green}60; }

/* Hint bar */
.tt-hints {
  display: flex;
  gap: 6px;
  overflow-x: auto;
  padding: 8px 0;
  scrollbar-width: none;
}
.tt-hints::-webkit-scrollbar { display: none; }
.tt-hint-chip {
  display: flex;
  align-items: center;
  gap: 4px;
  background: ${r.white}15;
  border: none;
  border-radius: ${C.lg};
  padding: 6px 10px;
  color: ${r.white};
  font-size: ${b.small};
  font-weight: 600;
  cursor: pointer;
  white-space: nowrap;
  transition: background 0.15s;
}
.tt-hint-chip:hover { background: ${r.white}25; }
.tt-hint-chip--disabled { opacity: 0.3; pointer-events: none; }
/* Chip under the finger during a fan drag — dock magnification */
.tt-hint-chip--tracked {
  background: ${r.green}30;
  outline: 1px solid ${r.green};
  transform: scale(1.12);
}
/* Pending bulb suggestion, glowing for its confirming tap */
.tt-hint-chip--suggested {
  border: 1px solid ${r.green};
  background: ${r.green}15;
  cursor: pointer;
  box-shadow: 0 0 8px ${r.green}60;
}
/* Help progress bar */
.tt-help-bar {
  padding: 8px 12px;
}
.tt-help-bar__labels {
  display: flex;
  justify-content: space-between;
  margin-bottom: 4px;
}
.tt-help-bar__label {
  font-size: ${b.small};
  font-weight: 600;
  color: ${r.white};
}
.tt-help-bar__avg {
  font-size: ${b.small};
  color: ${r.white};
  opacity: 0.5;
}
.tt-help-bar__track {
  position: relative;
  height: 6px;
  border-radius: ${C.tile};
  background: ${r.white}15;
  overflow: hidden;
}
.tt-help-bar__fill {
  height: 100%;
  border-radius: ${C.tile};
  transition: width 0.3s ease, background-color 0.3s ease;
}
/* Hover price preview: grows out of the fill while a hint chip is hovered */
.tt-help-bar__ghost {
  position: absolute;
  top: 0;
  height: 100%;
  width: 0;
  background: ${r.white}55;
  border-radius: ${C.tile};
  transition: width 0.15s ease;
  pointer-events: none;
}
.tt-help-bar__preview {
  color: ${r.yellow};
  font-weight: 600;
}

/* Hint flash pill — inline to left of bulb */
.tt-hint-flash-inline {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  background: ${r.white}10;
  border: 1px solid ${r.green}40;
  border-radius: ${C.md};
  padding: 3px 8px;
  font-size: ${b.small};
  color: ${r.white};
  white-space: nowrap;
}

/* Hints bar inline in header */
.tt-hints-inline {
  flex: 1;
  overflow-x: auto;
  margin: 0 4px;
}
.tt-hints-inline::-webkit-scrollbar { display: none; }
.tt-hints-inline .tt-hints {
  flex-wrap: nowrap;
  gap: 4px;
}
.tt-hints-inline .tt-hint-chip {
  padding: 4px 8px;
  font-size: ${b.small};
}

/* Revealed "My cue" lines above the input */
.tt-cue-reveal {
  margin-bottom: 8px;
  display: grid;
  gap: 4px;
}
.tt-cue-reveal div {
  font-size: ${b.small};
  color: ${r.yellow};
  background: ${r.yellow}12;
  border-radius: ${C.sm};
  padding: 4px 8px;
}

/* ✎ marker on highlights that carry an authored cue */
.tt-has-cue::after {
  content: "✎";
  font-size: 10px;
  vertical-align: super;
  color: ${r.violet};
  opacity: 0.8;
  margin-left: 1px;
}

/* Cue editor (long-press on a highlight or underline) */
.tt-cue-context {
  font-size: ${b.small};
  color: ${r.lavender};
  font-style: italic;
  margin-bottom: 10px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.tt-cue-input {
  width: 100%;
  box-sizing: border-box;
  height: 36px;
  background: ${r.white}10;
  border: 1px solid ${r.white}20;
  border-radius: ${C.sm};
  padding: 0 10px;
  font-size: ${b.small};
  color: ${r.white};
  outline: none;
}
.tt-cue-input:focus { box-shadow: 0 0 0 2px ${r.green}60; }
.tt-cue-actions {
  display: flex;
  gap: 8px;
  margin-top: 14px;
  align-items: center;
}
.tt-cue-remove {
  font-size: ${b.small};
  color: ${r.orange};
  cursor: pointer;
  margin-right: auto;
}

/* Save modal */
.tt-save-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999999;
  padding: 24px;
}
.tt-save-card {
  background: ${W.gradient};
  border: ${W.cardBorder};
  border-radius: ${C.lg};
  padding: 20px;
  width: 100%;
  max-width: 360px;
  color: ${r.white};
}
.tt-save-card h3 {
  margin: 0;
  font-family: ${b.display};
  font-weight: 800;
  font-size: ${b.label};
}
.tt-save-card .tt-save-sub {
  font-size: ${b.small};
  opacity: 0.6;
  margin-top: 2px;
}

/* The invite: a centered hand-off card — the app surface in miniature,
   one number, one line, one glowing way forward. */
@keyframes tt-pop {
  from { opacity: 0; transform: scale(0.94) translateY(10px); }
  to   { opacity: 1; transform: scale(1) translateY(0); }
}
.tt-save-card--invite {
  text-align: center;
  padding: 26px 24px 18px;
  /* A green dawn over the app gradient — the moment feels like a win */
  background:
    radial-gradient(420px 220px at 50% -40%, ${r.green}2E, transparent 65%),
    ${W.gradient};
  animation: tt-pop 0.25s ease-out;
}
.tt-save-wordmark {
  font-family: ${b.display};
  font-weight: 800;
  font-size: ${b.small};
  letter-spacing: 0.04em;
  color: ${r.green};
}
.tt-save-num {
  font-family: ${b.display};
  font-weight: 800;
  font-size: 46px;
  line-height: 1.1;
  color: ${r.yellow};
  margin-top: 8px;
}
.tt-save-what {
  font-size: ${b.body};
  font-weight: 700;
  color: ${r.white};
  margin-bottom: 8px;
}
.tt-save-line {
  font-size: ${b.small};
  color: ${r.lavender};
  line-height: 1.5;
  max-width: 30ch;
  margin: 0 auto 18px;
}
.tt-save-go-btn {
  width: 100%;
  box-sizing: border-box;
  background: ${r.green};
  color: ${r.dark};
  border: none;
  border-radius: ${C.pill};
  padding: 13px 16px;
  font-family: ${b.display};
  font-size: ${b.body};
  font-weight: 800;
  cursor: pointer;
  box-shadow: 0 6px 20px ${r.green}40;
  transition: transform 0.12s ease, box-shadow 0.12s ease;
}
.tt-save-go-btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 8px 24px ${r.green}55;
}
.tt-save-done-ring {
  width: 56px;
  height: 56px;
  margin: 8px auto 12px;
  border-radius: ${C.pill};
  background: ${r.green};
  color: ${r.dark};
  font-size: ${b.h2};
  font-weight: 800;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 6px 20px ${r.green}40;
}
.tt-save-row {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 8px;
  border-bottom: 1px solid ${r.white}10;
  cursor: pointer;
  border-radius: ${C.sm};
}
.tt-save-row:hover {
  background: ${r.white}10;
}
.tt-save-input {
  flex: 1;
  height: 32px;
  background: ${r.white}10;
  border: 1px solid ${r.white}20;
  border-radius: ${C.sm};
  padding: 0 8px;
  font-size: ${b.small};
  color: ${r.white};
}
.tt-save-input::placeholder { color: ${r.white}40; }
.tt-save-create-btn {
  background: ${r.green};
  border: none;
  border-radius: ${C.pill};
  padding: 6px 14px;
  font-weight: bold;
  color: ${r.dark};
  cursor: pointer;
  font-size: ${b.small};
}
.tt-save-cancel {
  text-align: center;
  margin-top: 12px;
  font-size: ${b.small};
  opacity: 0.5;
  cursor: pointer;
}
.tt-save-check {
  text-align: center;
  font-size: ${b.h1};
  color: ${r.green};
}
.tt-save-msg {
  text-align: center;
  font-size: ${b.small};
  font-weight: 600;
  margin-top: 8px;
}

/* Toast animations */
@keyframes tt-fade-in {
  from { opacity: 0; transform: translateY(-4px); }
  to { opacity: 1; transform: translateY(0); }
}
@keyframes tt-toast-fade {
  0% { opacity: 0; transform: translateY(-10px); }
  10% { opacity: 1; transform: translateY(0); }
  80% { opacity: 1; transform: translateY(0); }
  100% { opacity: 0; transform: translateY(-10px); }
}
.tt-toast {
  position: fixed;
  top: 52px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 999999;
  background: ${r.orange};
  color: white;
  padding: 10px 20px;
  border-radius: ${C.sm};
  font-family: ${b.sans};
  font-size: ${b.small};
  font-weight: 600;
  box-shadow: 0 4px 12px rgba(0,0,0,0.3);
  animation: tt-toast-fade 3s ease forwards;
  pointer-events: none;
}

/* Score */
.tt-score {
  text-align: center;
  padding: 8px;
  font-size: ${b.small};
  color: ${r.white};
  opacity: 0.6;
}

/* Complete state */
.tt-complete {
  text-align: center;
  padding: 20px;
}
.tt-complete__check {
  font-size: ${b.hero};
  color: ${r.green};
  margin-bottom: 8px;
}
.tt-complete__score {
  font-size: ${b.h1};
  font-weight: bold;
  /* Not electric violet: on the dark surface it reads as a gap (see HelpDonut). */
  color: ${r.yellow};
}

/* Cue editor card + first-run guide.
   These render inside arbitrary host pages whose CSS can reach into our
   DOM (no shadow root), so every text/background property that decides
   legibility is pinned with !important — a host rule once turned the cue
   input's text black on the dark card. */
.tt-brand-row {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 12px;
}
.tt-brand-row svg { display: block; flex: none; }
.tt-brand-title {
  font-family: ${b.display} !important;
  font-weight: 800 !important;
  font-size: ${b.label} !important;
  color: ${r.white} !important;
  margin: 0 !important;
  line-height: 1.2 !important;
}
.tt-brand-kicker {
  font-family: ${b.sans} !important;
  font-size: ${b.small} !important;
  color: ${r.lavender} !important;
  margin: 0 !important;
}
.tt-cue-card .tt-cue-context {
  color: ${r.lavender} !important;
  background: ${r.white}0A;
  border-radius: ${C.sm};
  padding: 8px 10px;
}
.tt-cue-card .tt-cue-input {
  color: ${r.white} !important;
  background: ${r.white}12 !important;
  caret-color: ${r.green} !important;
  font-family: ${b.sans} !important;
  -webkit-text-fill-color: ${r.white} !important;
}
.tt-cue-card .tt-cue-input::placeholder {
  color: ${r.white} !important;
  -webkit-text-fill-color: ${r.white} !important;
  opacity: 0.45 !important;
}
.tt-cue-card .tt-save-cancel,
.tt-cue-card .tt-cue-remove { font-family: ${b.sans} !important; }
.tt-cue-meta {
  margin-top: 5px;
  font-family: ${b.sans} !important;
  font-size: 11px !important;
  color: ${r.lavender} !important;
  opacity: 0.8;
  text-align: right;
}
.tt-cue-meta--over {
  color: ${r.orange} !important;
  opacity: 1;
  font-weight: 700 !important;
}
.tt-param-label {
  display: block;
  margin-bottom: 6px;
  font-family: ${b.sans} !important;
  font-size: ${b.small} !important;
  font-weight: 700 !important;
  color: ${r.white} !important;
}
.tt-param-hint {
  margin: 6px 0 0 !important;
  font-family: ${b.sans} !important;
  font-size: 11px !important;
  color: ${r.lavender} !important;
  line-height: 1.5 !important;
}

/* First-run guide */
.tt-guide-steps { display: grid; gap: 12px; margin: 14px 0 18px; }
.tt-guide-step { display: flex; gap: 12px; align-items: flex-start; }
.tt-guide-num {
  flex: none;
  width: 26px; height: 26px;
  border-radius: ${C.pill};
  background: ${r.green};
  color: ${r.dark} !important;
  font-family: ${b.display} !important;
  font-weight: 800 !important;
  font-size: ${b.small} !important;
  display: flex; align-items: center; justify-content: center;
}
.tt-guide-step b {
  color: ${r.white} !important;
  font-family: ${b.sans} !important;
  font-size: ${b.body} !important;
  font-weight: 700 !important;
}
.tt-guide-step p {
  margin: 2px 0 0 !important;
  color: ${r.lavender} !important;
  font-family: ${b.sans} !important;
  font-size: ${b.small} !important;
  line-height: 1.5 !important;
}
.tt-guide-chip {
  display: inline-block;
  font-family: ${b.display} !important;
  font-weight: 800 !important;
  font-size: 11px !important;
  color: ${r.green} !important;
  border: 1px solid ${r.green}60;
  border-radius: ${C.pill};
  padding: 0 7px;
}
`;function Me(e=34){return`<svg width="${e}" height="${e}" viewBox="0 0 46.18 46.18" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <rect width="46.18" height="46.18" rx="10.2" fill="#0FFFB9"/>
    <g transform="translate(-79 -333)" fill="#4E15FF">
      <path d="M99.8499 344.37H88.4299C87.1499 344.37 86.1699 345.38 86.1699 346.63C86.1699 347.88 87.1799 348.85 88.4299 348.85H95.1199V368.19C95.1199 369.51 96.1299 370.6 97.4499 370.6C98.7699 370.6 99.8599 369.51 99.8599 368.19V348.84L99.8399 344.37H99.8499Z"/>
      <path d="M112.49 344.37H104.8V348.84H112.49C113.77 348.84 114.75 347.83 114.75 346.62C114.75 345.41 113.74 344.36 112.49 344.36V344.37Z"/>
      <path d="M104.66 355.42C104.66 354.14 105.71 353.09 107 353.09C108.29 353.09 109.34 354.14 109.34 355.42V368.26C109.34 369.54 108.29 370.59 107 370.59C105.71 370.59 104.66 369.54 104.66 368.26V355.42Z"/>
    </g>
  </svg>`}function Y(){if(document.getElementById("tt-styles"))return;Ne();const e=document.createElement("style");e.id="tt-styles",e.textContent=He,document.head.appendChild(e)}function Ne(){if(!document.getElementById("tt-fonts"))try{const e=document.createElement("link");e.id="tt-fonts",e.rel="stylesheet",e.href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Nunito:wght@700&display=swap",document.head.appendChild(e)}catch{}}const Ae=50;var H=(e=>(e.CHARACTER_PLACEHOLDERS="CHARACTER_PLACEHOLDERS",e.NEXT_LETTER="NEXT_LETTER",e.ALL_VOWELS="ALL_VOWELS",e.ALL_CONSONANTS="ALL_CONSONANTS",e.SHUFFLED_LETTERS="SHUFFLED_LETTERS",e.RANDOM_LETTER="RANDOM_LETTER",e.HANGMAN="HANGMAN",e.FIRST_CONSONANT="FIRST_CONSONANT",e.FIRST_VOWEL="FIRST_VOWEL",e.CONSONANT_LIST="CONSONANT_LIST",e.SELF_AUTHORED="SELF_AUTHORED",e))(H||{});function K(e){return e.normalize("NFD").replace(/[\u0300-\u036f]/g,"")}const J=new Set(["a","e","i","o","u","y"]);function de(e){const n=[...e];for(let t=n.length-1;t>0;t--){const o=Math.floor(Math.random()*(t+1));[n[t],n[o]]=[n[o],n[t]]}return n}function ne(e){return e>0?100/e:0}function qe(e,n){let t=0;for(let o=0;o<e.length;o++)n.has(o)&&t++;return t}const Re={id:H.CHARACTER_PLACEHOLDERS,label:"Show length",icon:"📏",iconName:"ruler",description:"Shows how many characters the word has",repeatable:!1,autoRevealsLength:!0,revealsPositions:!1,costType:"free",modality:"text",group:"reveal",apply(e,n){return{type:this.id,revealedIndices:[],cost:0}}},ze={id:H.NEXT_LETTER,label:"Next letter",icon:"➡️",iconName:"arrow-right",description:"Reveals the next unrevealed letter from left to right",repeatable:!0,autoRevealsLength:!1,revealsPositions:!0,costType:"per-letter",modality:"text",group:"reveal",apply(e,n){for(let t=0;t<e.length;t++)if(!n.has(t))return{type:this.id,revealedIndices:[t],cost:ne(e.length)};return{type:this.id,revealedIndices:[],cost:0}}},Oe={id:H.ALL_VOWELS,label:"Vowels",icon:"🔤",iconName:"vowels",description:"Reveals all vowels (a, e, i, o, u, y — including accented)",repeatable:!1,autoRevealsLength:!0,revealsPositions:!0,costType:"proportional",modality:"text",group:"reveal",apply(e,n){const t=e.toLowerCase(),o=[];for(let i=0;i<e.length;i++)J.has(K(t[i]))&&!n.has(i)&&o.push(i);return{type:this.id,revealedIndices:o,cost:e.length>0?o.length/e.length*100:0}}},We={id:H.ALL_CONSONANTS,label:"Consonants",icon:"🔡",iconName:"consonants",description:"Reveals all consonants (including accented like ç, ñ)",repeatable:!1,autoRevealsLength:!0,revealsPositions:!0,costType:"proportional",modality:"text",group:"reveal",apply(e,n){const t=e.toLowerCase(),o=[];for(let i=0;i<e.length;i++)!J.has(K(t[i]))&&!n.has(i)&&o.push(i);return{type:this.id,revealedIndices:o,cost:e.length>0?o.length/e.length*100:0}}},De={id:H.SHUFFLED_LETTERS,label:"Shuffle",icon:"🔀",iconName:"shuffle",description:"Shuffles the letters within each word (doesn't reveal positions)",repeatable:!0,autoRevealsLength:!0,revealsPositions:!1,costType:"flat",flatCost:40,modality:"text",group:"reorder",apply(e,n){const t=e.length-qe(e,n);if(t===0)return{type:this.id,revealedIndices:[],cost:0};const o=e.split(" ").map(i=>de(i.split("")).join("")).join(" ");return{type:this.id,revealedIndices:[],cost:40*(t/e.length),displayData:o}}},Fe={id:H.RANDOM_LETTER,label:"Random",icon:"🎲",iconName:"dice",description:"Reveals one random unrevealed letter",repeatable:!0,autoRevealsLength:!0,revealsPositions:!0,costType:"per-letter",modality:"text",group:"reveal",apply(e,n){const t=[];for(let i=0;i<e.length;i++)n.has(i)||t.push(i);if(t.length===0)return{type:this.id,revealedIndices:[],cost:0};const o=t[Math.floor(Math.random()*t.length)];return{type:this.id,revealedIndices:[o],cost:ne(e.length)}}},Be={id:H.HANGMAN,label:"Structure",icon:"␣",iconName:"slots",description:"Shows the word breaks and punctuation, with a slot for each letter",repeatable:!1,autoRevealsLength:!0,revealsPositions:!0,costType:"proportional",modality:"text",group:"reveal",apply(e,n){const t=[];for(let o=0;o<e.length;o++){const i=e[o];!/[\p{L}\p{N}]/u.test(i)&&!n.has(o)&&t.push(o)}return{type:this.id,revealedIndices:t,cost:e.length>0?t.length/e.length*100:0}}};function ce(e,n){return(t,o)=>{const i=t.toLowerCase();for(let s=0;s<t.length;s++){const d=K(i[s]);if(/[a-z]/.test(d)&&J.has(d)===n&&!o.has(s))return{type:e,revealedIndices:[s],cost:ne(t.length)}}return{type:e,revealedIndices:[],cost:0}}}const Pe={id:H.FIRST_CONSONANT,label:"Consonant",icon:"🔡",iconName:"consonant",description:"Reveals the first consonant, then each following one",repeatable:!0,autoRevealsLength:!1,revealsPositions:!0,costType:"per-letter",modality:"text",group:"reveal",apply(e,n){return ce(H.FIRST_CONSONANT,!1)(e,n)}},je={id:H.FIRST_VOWEL,label:"Vowel",icon:"🔤",iconName:"vowel",description:"Reveals the first vowel, then each following one",repeatable:!0,autoRevealsLength:!1,revealsPositions:!0,costType:"per-letter",modality:"text",group:"reveal",apply(e,n){return ce(H.FIRST_VOWEL,!0)(e,n)}},Ue={id:H.CONSONANT_LIST,label:"Consonant list",icon:"🔡",iconName:"list",description:"Lists the consonants you still need in random order, without their positions",repeatable:!1,autoRevealsLength:!1,revealsPositions:!1,costType:"proportional",modality:"text",group:"reorder",apply(e,n){const t=e.toLowerCase(),o=[];for(let i=0;i<e.length;i++){if(n.has(i))continue;const s=t[i],d=K(s);/[a-z]/.test(d)&&!J.has(d)&&o.push(s)}return o.length===0?{type:this.id,revealedIndices:[],cost:0}:{type:this.id,revealedIndices:[],cost:e.length>0?o.length/e.length*50:0,displayData:de(o).join(" ")}}},oe=[{id:H.SELF_AUTHORED,label:"My cue",icon:"✎",iconName:"pen",description:"Shows a cue you wrote yourself when creating this exercise",repeatable:!0,autoRevealsLength:!1,revealsPositions:!1,costType:"flat",flatCost:10,modality:"text",group:"reveal",apply(e,n){return{type:this.id,revealedIndices:[],cost:10}}},Re,ze,Fe,Oe,je,We,Pe,Ue,De],Qe=[...oe,Be];function Q(e){const n=Qe.find(t=>t.id===e);if(!n)throw new Error(`Unknown hint type: ${e}`);return n}function Ve(e,n,t=new Set){return Q(n).apply(e,t)}function ie(e){const n=e.reduce((t,o)=>t+o.cost,0);return Math.min(n,100)}function ue(e,n,t){return e.apply(n,new Set(t))}function pe(e,n,t){return ue(e,n,t).cost}function Ye(e,n,t,o={}){if(n.length===0)return!1;if(e.id===H.CHARACTER_PLACEHOLDERS)return o.lengthAlreadyKnown!==!0;if(e.id===H.SELF_AUTHORED)return o.remainingCues===void 0||o.remainingCues>0;const i=ue(e,n,t);return i.revealedIndices.length>0||i.displayData!==void 0}function Xe(e,n){return(e??[]).slice(n)}let he="strict";function Z(){return he}function Ge(e){return e.normalize("NFD").replace(/[̀-ͯ]/g,"")}function ge(e,n){const t=e.toLowerCase();return n==="strict"?t:Ge(t)}function ee(e,n,t=he){return n===""?!1:ge(e,t)===ge(n,t)}function X(e,n=Z()){const t=new Set;return e.blanks.forEach((o,i)=>{(o.revealed||ee(o.expected,o.actual,n))&&t.add(i)}),t}function fe(e){return{exercise:e,hintUsages:[],isComplete:!1,shuffledLettersMap:{}}}function Ke(e){return e.blanks.map(n=>n.actual).join("")}function Je(e,n,t,o=Z()){const i=e.exercise.queries.find(x=>x.id===n);if(!i)return e;const s=A(i,o);if(s.correct===s.total)return e;const d=i.blanks.map((x,E)=>{const $=t[E]??"";return x.revealed&&$!==""&&!ee(x.expected,$,o)?{...x,actual:$,revealed:!1}:{...x,actual:$}}),u={...i,blanks:d},h=e.exercise.queries.map(x=>x.id===n?u:x),v={...e.exercise,queries:h};return{...e,exercise:v,isComplete:se(v)}}function Ze(e,n,t){const o=e.exercise.queries.find(l=>l.id===n);if(!o)return e;const i=Q(t),s=X(o);if(!i.repeatable&&e.hintUsages.some(c=>c.queryId===n&&c.type===t))return e;const d=Ve(o.answer,t,s);if(i.id!==H.CHARACTER_PLACEHOLDERS&&d.revealedIndices.length===0&&!d.displayData&&d.cost===0)return e;const u=o.blanks.map((l,c)=>d.revealedIndices.includes(c)?{...l,revealed:!0}:l),h={...o,blanks:u},v=e.exercise.queries.map(l=>l.id===n?h:l),x={queryId:n,type:t,cost:d.cost,usedAt:new Date,displayData:d.displayData},E={...e.exercise,queries:v},$={...e.shuffledLettersMap};return d.displayData&&t==="SHUFFLED_LETTERS"&&($[n]=d.displayData),{...e,exercise:E,hintUsages:[...e.hintUsages,x],isComplete:se(E),shuffledLettersMap:$}}function et(e,n,t){const o=e.exercise.queries.find(x=>x.id===n);if(!o||t<0||t>=o.blanks.length||X(o).has(t))return e;const i=o.blanks.map((x,E)=>E===t?{...x,revealed:!0}:x),s={...o,blanks:i},d=e.exercise.queries.map(x=>x.id===n?s:x),u=o.answer.length>0?100/o.answer.length:0,h={queryId:n,type:H.NEXT_LETTER,cost:u,usedAt:new Date},v={...e.exercise,queries:d};return{...e,exercise:v,hintUsages:[...e.hintUsages,h],isComplete:se(v)}}function se(e,n=Z()){return e.queries.every(t=>t.blanks.every(o=>ee(o.expected,o.actual,n)))}function A(e,n=Z()){const t=e.blanks.length;return{correct:e.blanks.filter(i=>ee(i.expected,i.actual,n)).length,total:t}}function me(){return Math.random().toString(36).substring(2,10)}function tt(e){return Array.from(e).filter(n=>/[\p{L}\p{M}'''\-\s]/u.test(n)).join("")}function nt(e){return e.split("").map(n=>({expected:n,actual:"",revealed:!1}))}function ot(e){const n=e.match(/^[.,;:!?'"()\-–—\s]+/),t=n?n[0].length:0,o=e.match(/[.,;:!?'"()\-–—\s]+$/),i=o?o[0].length:0;return{cleaned:e.slice(t,e.length-i||void 0),leadingLen:t,trailingLen:i}}function it(e,n){if(e.length<=1)return e;const t=[...e].sort((i,s)=>i.start-s.start),o=[{...t[0]}];for(let i=1;i<t.length;i++){const s=t[i],d=o[o.length-1];n.slice(d.end,s.start).trim().length===0?d.end=s.end:o.push({...s})}return o}function st(e){if(!e.sentenceSelection||e.wordSelections.length===0)return null;const n=e.sourceText.slice(e.sentenceSelection.start,e.sentenceSelection.end),t=it(e.wordSelections,e.sourceText),o=[];let i=n;for(let s=t.length-1;s>=0;s--){const d=t[s],u=d.start-e.sentenceSelection.start,h=d.end-e.sentenceSelection.start,v=n.slice(u,h),{cleaned:x,leadingLen:E,trailingLen:$}=ot(v),l=tt(x);if(l.length===0)continue;const c=u+E,a=h-$,m={id:me(),answer:l,blanks:nt(l),startIndex:c,endIndex:a};o.unshift(m);const f="_".repeat(l.length);i=i.slice(0,c)+f+i.slice(a)}return o.length===0?null:{id:me(),type:"hhh",originalSentence:n,sentenceWithBlanks:i,queries:o,createdAt:new Date}}function be(){return Math.random().toString(36).substring(2,10)}function rt(e){return Array.from(e).filter(n=>/[\p{L}\p{M}'''\-\s]/u.test(n)).join("")}function at(e){return e.split("").map(n=>({expected:n,actual:"",revealed:!1}))}function lt(e,n){const t=e.slice(n.question.start,n.question.end).trim(),o=rt(e.slice(n.answer.start,n.answer.end).trim());if(t.length===0||o.length===0)return null;const i={id:be(),answer:o,blanks:at(o),startIndex:0,endIndex:o.length},s="_".repeat(o.length);return{id:be(),type:"qa",originalSentence:t,sentenceWithBlanks:s,queries:[i],createdAt:new Date}}const ve=new Date("2026-09-28");function xe(e){return e.split("").map(n=>({expected:n,actual:"",revealed:!1}))}function k(e,n,t){return{id:e,type:"qa",originalSentence:n,sentenceWithBlanks:"_".repeat(t.length),queries:[{id:`${e}-q1`,answer:t,blanks:xe(t),startIndex:0,endIndex:t.length}],createdAt:ve}}function dt(e,n){let t=0;for(;;){const o=e.indexOf(n,t);if(o<0)throw new Error(`Fixture error: "${n}" not found in "${e}"`);const i=e[o-1],s=e[o+n.length],d=u=>u!==void 0&&new RegExp("\\p{L}","u").test(u);if(!d(i)&&!d(s))return o;t=o+1}}function S(e,n,t){const o=t.map((s,d)=>{const u=dt(n,s);return{id:`${e}-q${d+1}`,answer:s,blanks:xe(s),startIndex:u,endIndex:u+s.length}}).sort((s,d)=>s.startIndex-d.startIndex);let i=n;for(const s of o)i=i.slice(0,s.startIndex)+"_".repeat(s.answer.length)+i.slice(s.endIndex);return{id:e,type:"hhh",originalSentence:n,sentenceWithBlanks:i,queries:o,createdAt:ve}}k("b1-nl-qa-1","Hoe noem je de persoon die brood en taarten bakt?","de bakker"),k("b1-nl-qa-2","Wat neem je mee als het regent?","een paraplu"),k("b1-nl-qa-3","Hoe noem je het gebouw waar je boeken kunt lenen?","de bibliotheek"),k("b1-nl-qa-4","Welk seizoen komt na de zomer?","de herfst"),k("b1-nl-qa-5","Hoe noem je de dokter die zieke dieren beter maakt?","de dierenarts"),k("b1-nl-qa-6","Hoe noem je het eerste eten van de dag?","het ontbijt"),k("b1-nl-qa-7","Hoe noem je de broer van je moeder?","de oom"),k("b1-nl-qa-8","Waar wacht je op de trein?","op het station"),k("b1-nl-qa-9","Hoe noem je iemand die in een restaurant kookt?","de kok"),k("b1-nl-qa-10","Hoe noem je het geld dat je elke maand verdient?","het salaris"),S("b1-nl-pres-1","Hallo, ik heet Thomas en ik ben dertig jaar oud.",["heet","oud"]),S("b1-nl-pres-2","Ik werk als verpleegkundige in een groot ziekenhuis in Antwerpen.",["verpleegkundige","ziekenhuis"]),S("b1-nl-pres-3","In het weekend ga ik graag wandelen in het bos met mijn hond.",["wandelen","hond"]),S("b1-nl-pres-4","Mijn grootste droom is om een lange reis door Azië te maken.",["droom","reis"]),S("b1-nl-pres-5","Daarom spaar ik elke maand een beetje geld voor die reis.",["spaar","geld"]),S("b1-nl-pres-6","Elke ochtend fiets ik in twintig minuten naar mijn werk.",["twintig minuten","werk"]),S("b1-nl-pres-7","Mijn zus woont in Gent en ik bezoek haar elke zondag.",["woont","elke zondag"]),S("b1-nl-pres-8","Op vrijdag kook ik graag verse soep met groenten uit de tuin.",["verse soep","tuin"]),S("b1-nl-pres-9","Volgend jaar wil ik een cursus Japans volgen voor mijn reis.",["cursus Japans","reis"]),S("b1-nl-pres-10","Mijn hond heet Max en hij wordt volgende maand vier jaar oud.",["volgende maand","vier jaar"]),k("b1-nl-opp-1","Wat is het tegenovergestelde van 'duur'?","goedkoop"),k("b1-nl-opp-2","Wat is het tegenovergestelde van 'groot'?","klein"),k("b1-nl-opp-3","Wat is het tegenovergestelde van 'snel'?","langzaam"),k("b1-nl-opp-4","Wat is het tegenovergestelde van 'makkelijk'?","moeilijk"),k("b1-nl-opp-5","Wat is het tegenovergestelde van 'vol'?","leeg"),k("b1-nl-opp-6","Wat is het tegenovergestelde van 'zwaar'?","licht"),k("b1-nl-opp-7","Wat is het tegenovergestelde van 'schoon'?","vuil"),k("b1-nl-opp-8","Wat is het tegenovergestelde van 'dichtbij'?","ver weg"),k("b1-nl-opp-9","Wat is het tegenovergestelde van 'beginnen'?","stoppen"),k("b1-nl-opp-10","Wat is het tegenovergestelde van 'vroeg'?","laat"),S("b1-nl-city-1","Vanochtend nemen we de trein naar het centrum van Amsterdam.",["de trein","centrum"]),S("b1-nl-city-2","Eerst drinken we koffie met appeltaart in een klein café aan de gracht.",["koffie","gracht"]),S("b1-nl-city-3","Daarna huren we fietsen om door het Vondelpark te rijden.",["huren","fietsen"]),S("b1-nl-city-4","In het museum bekijken we de beroemde schilderijen van Van Gogh.",["museum","beroemde schilderijen"]),S("b1-nl-city-5","Voor de lunch eten we een broodje haring bij een kraampje op de markt.",["broodje haring","markt"]),S("b1-nl-city-6","In de middag maken we een rondvaart door de oude grachten van de stad.",["rondvaart","oude grachten"]),S("b1-nl-city-7","We kopen souvenirs en verse kaas in een gezellige winkel.",["souvenirs","verse kaas"]),S("b1-nl-city-8","Het begint zacht te regenen, dus we schuilen onder een grote paraplu.",["regenen","grote paraplu"]),S("b1-nl-city-9","Voor het diner bestellen we pannenkoeken met stroop en poedersuiker.",["bestellen","pannenkoeken"]),S("b1-nl-city-10","Moe maar gelukkig nemen we de laatste trein terug naar huis.",["laatste trein","huis"]),k("b1-en-qa-1","What do you call the person who flies a plane?","a pilot"),k("b1-en-qa-2","What do you use to open a locked door?","a key"),k("b1-en-qa-3","What do you call the meal you eat in the morning?","breakfast"),k("b1-en-qa-4","Which season comes after winter?","spring"),k("b1-en-qa-5","What do you call the place where you watch films on a big screen?","the cinema"),k("b1-en-qa-6","What do you call the room where you cook your meals?","the kitchen"),k("b1-en-qa-7","What do you call your mother's brother?","your uncle"),k("b1-en-qa-8","Where do you wait for a train?","at the station"),k("b1-en-qa-9","What do you call a person who cooks in a restaurant?","a chef"),k("b1-en-qa-10","What do you call the money you earn every month?","a salary"),S("b1-en-pres-1","Hi, my name is Sarah and I am twenty-eight years old.",["name","old"]),S("b1-en-pres-2","I work as an engineer at a small software company in Manchester.",["engineer","company"]),S("b1-en-pres-3","Every morning I take the train to work and read a book on the way.",["train","book"]),S("b1-en-pres-4","My biggest dream is to open my own restaurant one day.",["dream","restaurant"]),S("b1-en-pres-5","That is why I save money every month and take cooking classes in the evening.",["save","cooking"]),S("b1-en-pres-6","Every evening I cook a new recipe from an old Italian cookbook.",["new recipe","cookbook"]),S("b1-en-pres-7","My brother lives in Leeds and I visit him every weekend.",["lives","every weekend"]),S("b1-en-pres-8","Next year I want to take a business course to learn about restaurants.",["business course","learn"]),S("b1-en-pres-9","My favourite dish is a simple pasta with fresh tomatoes and basil.",["favourite dish","fresh tomatoes"]),S("b1-en-pres-10","With a bit of luck I will open the doors of my restaurant in five years.",["doors","five years"]),k("b1-en-opp-1","What is the opposite of 'expensive'?","cheap"),k("b1-en-opp-2","What is the opposite of 'big'?","small"),k("b1-en-opp-3","What is the opposite of 'fast'?","slow"),k("b1-en-opp-4","What is the opposite of 'easy'?","difficult"),k("b1-en-opp-5","What is the opposite of 'full'?","empty"),k("b1-en-opp-6","What is the opposite of 'heavy'?","light"),k("b1-en-opp-7","What is the opposite of 'clean'?","dirty"),k("b1-en-opp-8","What is the opposite of 'near'?","far away"),k("b1-en-opp-9","What is the opposite of 'to begin'?","to stop"),k("b1-en-opp-10","What is the opposite of 'early'?","late"),S("b1-en-city-1","This morning we take the red bus to the centre of London.",["red bus","centre"]),S("b1-en-city-2","First we drink tea with scones in a small café near the river.",["tea","river"]),S("b1-en-city-3","Then we walk through Hyde Park and feed the friendly ducks.",["walk","friendly ducks"]),S("b1-en-city-4","In the museum we look at old maps and famous paintings.",["museum","famous paintings"]),S("b1-en-city-5","For lunch we eat fish and chips at a busy market.",["lunch","busy market"]),S("b1-en-city-6","In the afternoon we take a boat trip on the River Thames.",["afternoon","boat trip"]),S("b1-en-city-7","We buy postcards and small gifts for our friends at home.",["postcards","small gifts"]),S("b1-en-city-8","It starts to rain softly, so we hide under a large umbrella.",["rain","large umbrella"]),S("b1-en-city-9","For dinner we order hot soup and fresh bread in a warm pub.",["order","hot soup"]),S("b1-en-city-10","Tired but happy, we take the last train back to our hotel.",["last train","hotel"]);let te=Ae;function ct(e){var h,v,x,E;Y(),(h=document.getElementById("tt-cue-overlay"))==null||h.remove();const n=document.createElement("div");n.id="tt-cue-overlay",n.className="tt-save-overlay",n.innerHTML=`<div class="tt-save-card tt-cue-card">
    <div class="tt-brand-row">
      ${Me(34)}
      <div>
        <h3 class="tt-brand-title" style="color:#FFFFFF !important"><span style="color:#0FFFB9 !important">✎</span> My cue — this ${e.scope}</h3>
        <p class="tt-brand-kicker" style="color:#B6A6EB !important">A hint in your own words, offered during play</p>
      </div>
    </div>
    <div class="tt-cue-context">“${ut(e.context)}”</div>
    <input class="tt-cue-input" id="tt-cue-input" placeholder="e.g. where you sit" maxlength="${te}" />
    <div class="tt-cue-meta" id="tt-cue-meta"></div>
    <div class="tt-cue-actions">
      ${e.initial?'<span class="tt-cue-remove" id="tt-cue-remove">🗑 Remove</span>':""}
      <span class="tt-save-cancel" style="margin:0" id="tt-cue-cancel">Cancel</span>
      <button class="tt-save-create-btn" id="tt-cue-save">✓ Save cue</button>
    </div>
  </div>`,document.body.appendChild(n);const t=n.querySelector("#tt-cue-input"),o=n.querySelector("#tt-cue-meta");t.value=e.initial,setTimeout(()=>t.focus(),50);const i=()=>t.value.trim().length>te,s=($=!1)=>{o.textContent=$?`Keep it a nudge — max ${te} characters`:`${t.value.length}/${te}`,o.classList.toggle("tt-cue-meta--over",$||i())};t.addEventListener("input",()=>s()),s();const d=()=>n.remove(),u=()=>{if(i()){s(!0),t.focus();return}const $=t.value.trim();$?e.onSave($):e.initial&&e.onRemove(),d()};(v=n.querySelector("#tt-cue-save"))==null||v.addEventListener("click",u),t.addEventListener("keydown",$=>{$.key==="Enter"&&u(),$.key==="Escape"&&d(),$.stopPropagation()}),(x=n.querySelector("#tt-cue-cancel"))==null||x.addEventListener("click",d),(E=n.querySelector("#tt-cue-remove"))==null||E.addEventListener("click",()=>{e.onRemove(),d()}),n.addEventListener("click",$=>{$.target===n&&d()})}function ut(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}let pt=1;function P(){const e=window.getSelection();e&&(window.__tiptongClearing=!0,e.removeAllRanges(),window.__tiptongClearing=!1)}function re(e,n,t){const o=[];if(e.startContainer===e.endContainer&&e.startContainer.nodeType===Node.TEXT_NODE){const h=document.createElement("span");return h.className=n,h.dataset.ttId=t,e.surroundContents(h),o.push(h),o}const i=[],s=document.createTreeWalker(e.commonAncestorContainer,NodeFilter.SHOW_TEXT);let d,u=!1;for(;d=s.nextNode();)if(d===e.startContainer)u=!0,i.push({node:d,start:e.startOffset,end:d.textContent.length});else if(d===e.endContainer){i.push({node:d,start:0,end:e.endOffset});break}else u&&i.push({node:d,start:0,end:d.textContent.length});for(let h=i.length-1;h>=0;h--){const{node:v,start:x,end:E}=i[h];if(x===E)continue;const $=document.createRange();$.setStart(v,x),$.setEnd(v,E);const l=document.createElement("span");l.className=n,l.dataset.ttId=t,$.surroundContents(l),o.push(l)}return o.reverse(),o}function ht(e){const n=document.caretRangeFromPoint(e.clientX,e.clientY);if(!n||n.startContainer.nodeType!==Node.TEXT_NODE)return null;const t=n.startContainer,o=t.textContent||"",i=n.startOffset;if(i>=o.length||o[i]===" "||o[i]===`
`)return null;let s=i;for(;s>0&&o[s-1]!==" "&&o[s-1]!==`
`;)s--;let d=i;for(;d<o.length&&o[d]!==" "&&o[d]!==`
`;)d++;const u=document.createRange();return u.setStart(t,s),u.setEnd(t,d),u}function gt(e,n,t){if(t!=="qa")return;const o=document.createElement("span");o.className=`tt-badge ${n==="answer"?"tt-badge--a":"tt-badge--q"}`,o.setAttribute("data-tt-badge",""),o.textContent=n==="answer"?"A":"Q",e.insertBefore(o,e.firstChild)}function ft(e){return Array.from(e).filter(n=>/[\p{L}\p{M}'''\-\s]/u.test(n)).join("")}function G(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function ae(e){let n="";for(const t of e.childNodes)if(t.nodeType===Node.TEXT_NODE)n+=t.textContent;else if(t.nodeType===Node.ELEMENT_NODE){const o=t;if(o.dataset.ttHandle||o.hasAttribute("data-tt-badge"))continue;n+=ae(o)}return n}function mt(e){if(e.startContainer.nodeType===Node.TEXT_NODE){const n=e.startContainer.textContent||"";let t=e.startOffset;for(;t>0&&n[t-1]!==" "&&n[t-1]!==`
`;)t--;e.setStart(e.startContainer,t)}if(e.endContainer.nodeType===Node.TEXT_NODE){const n=e.endContainer.textContent||"";let t=e.endOffset;for(;t<n.length&&n[t]!==" "&&n[t]!==`
`;)t++;e.setEnd(e.endContainer,t)}}function bt(){Y();const e={mode:"hhh",highlights:[],deleteMode:!1};let n=[];function t(l){var a,m,f,p;let c=l.nodeType===Node.TEXT_NODE?l.parentElement:l;for(;c;){if((a=c.dataset)!=null&&a.ttId)return e.highlights.find(g=>g.id===c.dataset.ttId)??null;if((m=c.classList)!=null&&m.contains("tt-underline")&&((p=(f=c.parentElement)==null?void 0:f.dataset)!=null&&p.ttId))return e.highlights.find(g=>g.id===c.parentElement.dataset.ttId)??null;c=c.parentElement}return null}function o(){if(e.deleteMode){const M=window.getSelection();if(M&&!M.isCollapsed&&M.toString().trim().length>0){e.deleteMode=!1;for(const N of e.highlights)for(const R of N.spans)R.classList.remove("tt-highlight--delete")}else return}const l=window.getSelection();if(!l||l.isCollapsed||!l.rangeCount||!l.toString().trim())return;const a=l.getRangeAt(0),m=document.getElementById("tt-toolbar"),f=document.getElementById("tt-popup");if(m!=null&&m.contains(a.startContainer)){P();return}if(f!=null&&f.contains(a.startContainer)){P();return}mt(a);const p=a.toString().trim();if(!p){P();return}const g=t(a.startContainer),w=t(a.endContainer);if(g&&g===w){if(e.mode==="hhh"&&g.role==="sentence"){P();return}P();return}const y=g||w;if(y){u(y,a),P();return}if(e.mode==="hhh"&&p.split(/\s+/).filter(Boolean).length<2){P();return}const T=e.highlights.filter(M=>M.role!=="sentence").length,_=e.mode==="qa"?T%2===0?"question":"answer":"sentence",L=`tt-${pt++}`,I=re(a,_==="answer"?"tt-highlight tt-highlight--answer":"tt-highlight",L);if(I.length>0){gt(I[0],_,e.mode);const M={id:L,text:p,role:_,spans:I,underlinedWords:[]};e.highlights.push(M),I.forEach(N=>E(N,M))}P()}function i(l,c){const a=l.underlinedWords[c];if(!a)return;const m=a.span.parentNode;if(m){for(;a.span.firstChild;)m.insertBefore(a.span.firstChild,a.span);m.removeChild(a.span),m.normalize()}l.underlinedWords.splice(c,1)}function s(l,c){var p,g;const a=ht(c);if(!a)return;const m=a.toString().trim();if(!m)return;const f=l.underlinedWords.findIndex(w=>w.span.contains(a.startContainer)||w.text===m);if(f>=0)i(l,f);else{const w=c.target;if((p=w.classList)!=null&&p.contains("tt-underline")||(g=w.closest)!=null&&g.call(w,".tt-underline")){const L=w.classList.contains("tt-underline")?w:w.closest(".tt-underline"),q=l.underlinedWords.findIndex(I=>I.span===L);if(q>=0){i(l,q);return}}const y=l.text.split(/\s+/).filter(Boolean).length,T=Math.floor(y/2);if(l.underlinedWords.length>=T)return;const _=document.createElement("span");_.className="tt-underline";try{a.surroundContents(_),l.underlinedWords.push({text:m,span:_})}catch{}}}function d(l){const c=e.highlights.find(m=>m.id===l);if(!c)return;const a=new Set([l]);if(c.role==="question"||c.role==="answer"){const m=e.highlights.filter(w=>w.role!=="sentence"),f=m.findIndex(w=>w.id===l),g=f%2===0?f+1:f-1;g>=0&&g<m.length&&a.add(m[g].id)}for(const m of a){const f=e.highlights.find(p=>p.id===m);if(f){for(const p of f.underlinedWords){const g=p.span.parentNode;if(g){for(;p.span.firstChild;)g.insertBefore(p.span.firstChild,p.span);g.removeChild(p.span)}}for(const p of f.spans)p.querySelectorAll("[data-tt-badge]").forEach(g=>g.remove());for(const p of f.spans){const g=p.parentNode;if(g){for(;p.firstChild;)g.insertBefore(p.firstChild,p);g.removeChild(p),g.normalize()}}}}e.highlights=e.highlights.filter(m=>!a.has(m.id)),e.highlights.length===0&&(e.deleteMode=!1)}function u(l,c){try{const a=t(c.startContainer)===l,m=t(c.endContainer)===l;if(!a){const f=l.spans[0],p=document.createRange();if(p.setStart(c.startContainer,c.startOffset),p.setEndBefore(f),p.toString().length>0)try{const g=re(p,f.className,l.id);l.spans.unshift(...g);const w=f.querySelector("[data-tt-badge]");w&&g[0]&&g[0].insertBefore(w,g[0].firstChild),g.forEach(y=>E(y,l))}catch{}}if(!m){const f=l.spans[l.spans.length-1],p=document.createRange();if(p.setStartAfter(f),p.setEnd(c.endContainer,c.endOffset),p.toString().length>0)try{const g=re(p,f.className,l.id);l.spans.push(...g),g.forEach(w=>E(w,l))}catch{}}for(l.text=l.spans.map(f=>ae(f)).join("");l.underlinedWords.length>0;)i(l,0)}catch{}}let h=0;function v(l,c){l.classList.toggle("tt-has-cue",!!c),c?l.title=`My cue: ${c}`:l.removeAttribute("title")}function x(l,c){l.addEventListener("pointerdown",a=>{var T,_;if(e.deleteMode)return;const m=a.clientX,f=a.clientY,p=(_=(T=a.target).closest)==null?void 0:_.call(T,".tt-underline");let g=setTimeout(()=>{g=null,h=Date.now()+600,P();const L=p?c.underlinedWords.find(q=>q.span===p):void 0;ct({context:L?L.text:c.text,scope:L?"word":"exercise",initial:(L?L.cue:c.cue)??"",onSave:q=>{L?(L.cue=q,v(L.span,q)):(c.cue=q,v(c.spans[0],q))},onRemove:()=>{L?(L.cue=void 0,v(L.span,void 0)):(c.cue=void 0,v(c.spans[0],void 0))}})},500);const w=()=>{g&&(clearTimeout(g),g=null),document.removeEventListener("pointermove",y),document.removeEventListener("pointerup",w)},y=L=>{Math.hypot(L.clientX-m,L.clientY-f)>8&&w()};document.addEventListener("pointermove",y),document.addEventListener("pointerup",w)})}function E(l,c){x(l,c),l.addEventListener("click",a=>{var f,p,g,w;if(Date.now()<h){a.preventDefault(),a.stopPropagation();return}if(((p=(f=a.target).closest)==null?void 0:p.call(f,"a"))&&(a.preventDefault(),a.stopPropagation()),e.deleteMode){a.preventDefault(),a.stopPropagation();const y=(w=(g=a.target).closest)==null?void 0:w.call(g,".tt-underline");if(y&&c.role==="sentence"){const T=c.underlinedWords.findIndex(_=>_.span===y);if(T>=0){i(c,T);return}}d(c.id);return}if(e.mode==="hhh"&&!e.deleteMode){const y=window.getSelection();if(y&&!y.isCollapsed)return;a.preventDefault(),a.stopPropagation(),s(c,a)}})}const $=()=>setTimeout(o,10);return document.addEventListener("mouseup",$,!0),{getSelections:()=>e.highlights.map(l=>({id:l.id,text:l.text,role:l.role,underlinedCount:l.underlinedWords.length})),validate:()=>{const l=[];return e.highlights.filter(a=>a.role!=="sentence").length%2!==0&&l.push("Last question needs an answer"),l},getMode:()=>e.mode,setMode:l=>{if(e.mode=l,e.deleteMode){e.deleteMode=!1;for(const c of e.highlights)for(const a of c.spans)a.classList.remove("tt-highlight--delete")}},toggleDeleteMode:()=>{e.deleteMode=!e.deleteMode;for(const l of e.highlights)for(const c of l.spans)c.classList.toggle("tt-highlight--delete",e.deleteMode);return e.deleteMode},isDeleteMode:()=>e.deleteMode,getQAPairs:()=>{const l=e.highlights.filter(a=>a.role!=="sentence"),c=[];for(let a=0;a+1<l.length;a+=2)c.push({question:l[a].text,answer:l[a+1].text});return c},getHHHData:()=>e.highlights.filter(c=>c.role==="sentence").map(c=>{const a=c.text,m=c.underlinedWords.map(f=>{const p=a.indexOf(f.text);return p>=0?{start:p,end:p+f.text.length}:null}).filter(f=>f!==null);return{sourceText:a,sentenceStart:0,sentenceEnd:a.length,underlinedWords:m}}),getOrderedExerciseData:()=>{const l=[];n=[];const c=[...e.highlights].sort((f,p)=>{const g=f.spans[0],w=p.spans[0];if(!g||!w)return 0;const y=g.compareDocumentPosition(w);return y&Node.DOCUMENT_POSITION_FOLLOWING?-1:y&Node.DOCUMENT_POSITION_PRECEDING?1:0}),a=c.filter(f=>f.role!=="sentence"),m=new Set;for(const f of c)if(f.role==="question"){const p=a.indexOf(f),g=Math.floor(p/2);if(m.has(g))continue;const w=a[p+1];w&&(m.add(g),l.push({type:"qa",question:f.text,answer:w.text,cue:f.cue??w.cue}),n.push(w.id))}else{if(f.role==="answer")continue;{const p=f.text;let g=f.underlinedWords.map(w=>{const y=p.indexOf(w.text);return y>=0?{start:y,end:y+w.text.length,cue:w.cue}:null}).filter(w=>w!==null);g.length===0&&f.randomPick&&(g=[{start:f.randomPick.start,end:f.randomPick.end}]),l.push({type:"hhh",sourceText:p,sentenceStart:0,sentenceEnd:p.length,underlinedWords:g,cue:f.cue}),n.push(f.id)}}return l},hideAnswers:()=>{for(const l of e.highlights)if(l.role==="answer")for(const c of l.spans){c.dataset.ttOriginal=c.innerHTML;const a="•".repeat(Math.min(l.text.length,12));c.innerHTML=`<span style="letter-spacing:2px;color:${r.violet};font-weight:bold">${a}</span>`}},hideUnderlinedWords:()=>{for(const l of e.highlights)if(l.role==="sentence")if(l.underlinedWords.length>0)for(const c of l.underlinedWords){c.span.dataset.ttOriginal=c.span.innerHTML;const a="•".repeat(Math.min(c.text.length,8));c.span.innerHTML=`<span style="letter-spacing:2px;color:${r.violet};font-weight:bold">${a}</span>`}else{const c=[];for(const a of l.spans){const m=ae(a),f=/[\p{L}\p{M}'']+/gu;let p;for(;(p=f.exec(m))!==null;)c.push({span:a,text:m,localStart:p.index,localEnd:p.index+p[0].length,word:p[0]})}if(c.length>0){const a=c[Math.floor(Math.random()*c.length)],f=l.text.indexOf(a.word);l.randomPick={text:a.word,start:f>=0?f:0,end:f>=0?f+a.word.length:a.word.length},a.span.dataset.ttOriginal=a.span.innerHTML,a.span.dataset.ttRandomStart=String(a.localStart),a.span.dataset.ttRandomEnd=String(a.localEnd);const p=G(a.text.slice(0,a.localStart)),g="•".repeat(Math.min(a.word.length,8)),w=G(a.text.slice(a.localEnd));a.span.innerHTML=`${p}<span style="letter-spacing:2px;color:${r.violet};font-weight:bold">${g}</span>${w}`}}},revealWord:(l,c)=>{var f;const a=c!=null?n[c]:void 0,m=a?e.highlights.filter(p=>p.id===a):e.highlights;for(const p of m){for(const g of p.underlinedWords)if((g.text.replace(/^[.,;:!?'"()\-–—\s]+|[.,;:!?'"()\-–—\s]+$/g,"")===l||g.text===l)&&g.span.dataset.ttOriginal){g.span.innerHTML=`<span style="color:${r.greenInk};font-weight:bold">${g.span.dataset.ttOriginal}</span>`;return}if(p.role==="sentence"&&((f=p.randomPick)==null?void 0:f.text)===l){for(const g of p.spans)if(g.dataset.ttOriginal&&g.dataset.ttRandomStart){const w=parseInt(g.dataset.ttRandomStart,10),y=parseInt(g.dataset.ttRandomEnd,10),T=document.createElement("span");T.innerHTML=g.dataset.ttOriginal;const _=T.textContent||"",L=G(_.slice(0,w)),q=G(_.slice(w,y)),I=G(_.slice(y));g.innerHTML=`${L}<span style="color:${r.greenInk};font-weight:bold">${q}</span>${I}`;return}}if(p.role==="answer"&&ft(p.text)===l){for(const g of p.spans)g.dataset.ttOriginal&&(g.innerHTML=`<span style="color:${r.greenInk};font-weight:bold">${g.dataset.ttOriginal}</span>`);return}}},showAnswers:()=>{for(const l of e.highlights){for(const c of l.underlinedWords)c.span.dataset.ttOriginal&&(c.span.innerHTML=c.span.dataset.ttOriginal,delete c.span.dataset.ttOriginal);for(const c of l.spans)c.dataset.ttOriginal&&(c.innerHTML=c.dataset.ttOriginal,delete c.dataset.ttOriginal,delete c.dataset.ttRandomStart,delete c.dataset.ttRandomEnd);delete l.randomPick}},destroy:()=>{for(const l of[...e.highlights])d(l.id);e.highlights=[],document.removeEventListener("mouseup",$,!0)}}}function we(e,n){return e.hintUsages.filter(t=>t.queryId===n&&t.type===H.SELF_AUTHORED).length}function $e(e,n,t){const o=e.hintUsages.some(i=>i.queryId===n.id&&Q(i.type).autoRevealsLength);return Ye(t,n.answer,X(n),{lengthAlreadyKnown:o,remainingCues:Xe(n.customCues,we(e,n.id)).length})}function le(e,n,t){const o=e.exercise.queries.find(d=>d.id===n);if(!o)return null;const i=new Set(e.hintUsages.filter(d=>d.queryId===n).map(d=>d.type)),s=oe.filter(d=>t!=null&&t.has(d.id)?!1:(!i.has(d.id)||d.repeatable)&&$e(e,o,d));return s.length===0?null:s[Math.floor(Math.random()*s.length)]}function vt(e,n){const t=n?e.hintUsages.filter(u=>u.queryId===n):[],o=Math.min(t.reduce((u,h)=>u+h.cost,0),100),i=e.exercise.queries.filter(u=>A(u).correct===A(u).total).map(u=>ie(e.hintUsages.filter(h=>h.queryId===u.id))),s=i.length>0?i.reduce((u,h)=>u+h,0)/i.length:0,d=o<30?r.green:o<60?r.yellow:r.orange;return`
    <div class="tt-help-bar" data-score="${o}">
      <div class="tt-help-bar__labels">
        <span class="tt-help-bar__label">Help used: ${Math.round(o)}%<span class="tt-help-bar__preview"></span></span>
        ${i.length>0?`<span class="tt-help-bar__avg">avg: ${Math.round(s)===0?"Perfect!":Math.round(s)+"%"}</span>`:""}
      </div>
      <div class="tt-help-bar__track">
        <div class="tt-help-bar__fill" style="width:${Math.min(o,100)}%;background:${d}"></div>
        <div class="tt-help-bar__ghost" style="left:${Math.min(o,100)}%"></div>
      </div>
    </div>
  `}const xt=(()=>{try{return localStorage.getItem("tiptong_app_url")??"https://maganino.github.io/TipTong-pilot"}catch{return"https://maganino.github.io/TipTong-pilot"}})();function ye(e,n){var i,s,d;(i=document.getElementById("tt-save-overlay"))==null||i.remove();const t=document.createElement("div");t.id="tt-save-overlay",t.className="tt-save-overlay";const o=e.length;t.innerHTML=`<div class="tt-save-card tt-save-card--invite">
    <div class="tt-save-wordmark">TipTong</div>
    <div class="tt-save-num">${o}</div>
    <div class="tt-save-what">exercise${o!==1?"s":""} ready</div>
    <div class="tt-save-line">Yours to keep — play anywhere, hints and scores included.</div>
    <button class="tt-save-go-btn" id="tt-save-go">▶&nbsp; Save &amp; play in the app</button>
    <div class="tt-save-cancel" id="tt-save-cancel">Not now</div>
  </div>`,document.body.appendChild(t),(s=t.querySelector("#tt-save-go"))==null||s.addEventListener("click",()=>{var E;const u=n&&n.length>0?{exercises:e,scores:n}:e,h=JSON.stringify(u),v=btoa(encodeURIComponent(h).replace(/%([0-9A-F]{2})/g,($,l)=>String.fromCharCode(parseInt(l,16)))),x=`${xt}/?import=${v}`;typeof chrome<"u"&&((E=chrome.runtime)!=null&&E.sendMessage)?chrome.runtime.sendMessage({type:"tiptong:open-tab",url:x}):window.open(x,"_blank"),t.querySelector(".tt-save-card").innerHTML=`
      <div class="tt-save-done-ring">&#10003;</div>
      <div class="tt-save-what">Off to the app</div>
      <div class="tt-save-line" style="margin-bottom:8px">Pick a playlist there to finish</div>
    `,setTimeout(()=>t.remove(),2e3)}),(d=t.querySelector("#tt-save-cancel"))==null||d.addEventListener("click",()=>t.remove()),t.addEventListener("click",u=>{u.target===t&&t.remove()})}function wt(e,n){var d,u;const t=new Array(e.blanks.length).fill(null),o=new Set;for(let h=0;h<e.blanks.length;h++){const v=e.blanks[h];if(v.revealed||v.actual!==""&&v.actual.toLowerCase()===v.expected.toLowerCase()){if(!o.has(h)&&((d=n[h])==null?void 0:d.toLowerCase())===v.expected.toLowerCase())o.add(h);else for(let x=0;x<n.length;x++)if(!o.has(x)&&((u=n[x])==null?void 0:u.toLowerCase())===v.expected.toLowerCase()){o.add(x);break}}}const i=[];for(let h=0;h<n.length;h++)!o.has(h)&&n[h]!==" "&&i.push(n[h]);let s=0;for(let h=0;h<e.blanks.length;h++){const v=e.blanks[h];v.expected===" "||v.revealed||v.actual!==""&&v.actual.toLowerCase()===v.expected.toLowerCase()||v.actual===""&&s<i.length&&(t[h]=i[s],s++)}return t}function ke(e,n){return n.some(t=>t.queryId!==e?!1:Q(t.type).autoRevealsLength)}function Se(e,n){if(!e.blanks.some(d=>d.actual!==""||d.revealed))return`<span class="tt-inline-blank ${n?"tt-inline-blank--active":""}" data-query="${e.id}">···</span>`;let o=-1;for(let d=e.blanks.length-1;d>=0;d--){const u=e.blanks[d];if(u.revealed||u.actual!==""){o=d;break}}const i=o<e.blanks.length-1;let s=`<span class="tt-inline-blank" data-query="${e.id}">`;for(let d=0;d<=o;d++){const u=e.blanks[d];if(u.expected===" ")s+=" ";else if(u.revealed)s+=`<span class="tt-inline-char tt-inline-char--revealed">${u.expected}</span>`;else if(u.actual==="")s+='<span class="tt-inline-char tt-inline-char--empty">·</span>';else{const h=u.actual.toLowerCase()===u.expected.toLowerCase();s+=`<span class="tt-inline-char ${h?"tt-inline-char--correct":"tt-inline-char--wrong"}">${u.actual}</span>`}}return i&&(s+='<span class="tt-inline-char tt-inline-char--empty">...</span>'),s+="</span>",s}function Ee(e,n,t){const o=t?wt(e,t):null;let i='<div class="tt-blanks">';for(let s=0;s<e.blanks.length;s++){const d=e.blanks[s];if(d.expected===" "){i+='<div class="tt-blank-word-gap"></div>';continue}const u=d.actual!=="",h=d.revealed,v=u&&d.actual.toLowerCase()===d.expected.toLowerCase(),x=u&&!v&&!h,E=o==null?void 0:o[s],$=!h&&!u&&!!E;let l="tt-blank";h?l+=" tt-blank--revealed":v?l+=" tt-blank--correct":x?l+=" tt-blank--wrong":$&&(l+=" tt-blank--shuffled"),n&&(l+=" tt-blank--active");const c=h?d.expected:u?d.actual:$?E:" ";i+=`<div class="${l}" data-reveal-char="${s}" data-reveal-query="${e.id}" style="cursor:pointer">${c}</div>`}return i+="</div>",i}function $t(e){const n=e.state,{exercise:t}=n,{originalSentence:o,queries:i}=t;let s="",d=0;for(const u of i){u.startIndex>d&&(s+=`<span class="tt-sentence-text">${U(o.slice(d,u.startIndex))}</span>`);const h=A(u),v=h.correct===h.total,x=ke(u.id,n.hintUsages),E=e.activeQueryId===u.id,$=n.shuffledLettersMap[u.id];v?s+=`<span class="tt-solved">${U(u.answer)}</span>`:x?s+=`<span data-query="${u.id}">${Ee(u,E,$)}</span>`:s+=Se(u,E),d=u.endIndex}return d<o.length&&(s+=`<span class="tt-sentence-text">${U(o.slice(d))}</span>`),s}function yt(e){const n=e.state.exercise.queries;if(n.length<=1)return"";let t='<div class="tt-word-progress">';for(let o=0;o<n.length;o++){const i=n[o],s=A(i).correct===A(i).total,d=e.activeQueryId===i.id;let u="tt-word-dot";s&&(u+=" tt-word-dot--done"),d&&(u+=" tt-word-dot--active"),t+=`<span class="${u}" data-query-dot="${i.id}">${s?"✓":o+1}</span>`}return t+="</div>",t}function kt(e,n){const t=e.exercise.queries.find(s=>s.id===n);if(!t)return"";const o=new Set(e.hintUsages.filter(s=>s.queryId===n).map(s=>s.type));let i='<div class="tt-hints">';for(const s of oe){const u=o.has(s.id)&&!s.repeatable||!$e(e,t,s),h=`tt-hint-chip${u?" tt-hint-chip--disabled":""}`,v=u?0:pe(s,t.answer,X(t)),x=v>0?`${s.description} — costs ${v}% help`:s.description;i+=`<button class="${h}" data-hint="${s.id}" data-cost="${v}" title="${x}"${u?" disabled":""}>${s.icon} ${s.label.split(" ")[0]}</button>`}return i+="</div>",i}function St(e,n){const t=Math.round(n)===0?"Perfect!":`Help: ${Math.round(n)}%`,o=n<30?r.green:n<60?r.yellow:r.orange,i=document.createElement("div");i.className="tt-query-score",i.style.cssText=`
    text-align:center;padding:6px 12px;margin:4px 0;
    border-radius: ${C.sm};font-size: ${b.small};font-weight:700;
    color:${o};background:${o}15;
    animation:tt-fade-in 0.2s ease;
  `,i.textContent=t;const s=e.querySelector(".tt-answer-box");s?s.parentNode.insertBefore(i,s):e.appendChild(i)}function z(e){var c;if(!e.state||!e.popup)return;const{exercise:n}=e.state,t=e.popup.querySelector(".tt-popup__body");if(!t)return;if(e.minimized){t.style.display="none";return}t.style.display="block",n.type;const o=n.type==="hhh";if(!e.activeQueryId){const a=n.queries.find(m=>A(m).correct!==A(m).total);a&&(e.activeQueryId=a.id)}if(n.queries.every(a=>A(a).correct===A(a).total)){const a=e.currentIndex>=e.exercises.length-1,m=ie(e.state.hintUsages),f=Math.round(m)===0?"Perfect!":`Help needed: ${Math.round(m)}%`;t.innerHTML=`
      <div class="tt-complete">
        <div class="tt-complete__check">&#10003;</div>
        <p style="font-size: ${b.body};margin:8px 0">${U(n.originalSentence)}</p>
        <p style="font-size: ${b.small};color:${m<30?r.green:m<60?r.yellow:r.orange};font-weight:600;margin:4px 0">${f}</p>
        ${a?`<button class="tt-hint-chip" style="margin-top:16px;font-size:${b.small}" data-action="close">Done</button>`:`<button class="tt-hint-chip" style="margin-top:16px;font-size:${b.small}" data-action="next">Next &rarr;</button>`}
        ${a?`<button class="tt-hint-chip" style="margin-top:8px;font-size:${b.small};border:1px solid ${r.yellow};color:${r.yellow}" data-action="save">Save to playlist</button>`:""}
      </div>
    `,Ce(e);return}const s=n.queries.find(a=>a.id===e.activeQueryId)??null,d=s?n.queries.indexOf(s):-1;let u="";if(o)u+=`<div class="tt-sentence">${$t(e)}</div>`,u+=yt(e);else if(u+=`<div class="tt-popup__question">${U(n.originalSentence)} ?</div>`,s){const a=ke(s.id,e.state.hintUsages),m=e.state.shuffledLettersMap[s.id];a?u+=Ee(s,!0,m):u+=Se(s,!0)}if(s){const a=Ke(s),m=o?`${d+1}/${n.queries.length}`:"Type the answer",f=e.flashHint?`<span class="tt-hint-flash-inline">${e.flashHint.icon} ${e.flashHint.label}</span>`:"",p=e.suggestedFor===s.id?e.suggested:null,g=!e.showHints&&!e.flashHint&&p?`<button class="tt-hint-flash-inline tt-hint-chip--suggested" id="tt-suggested">${p.icon} ${p.label.split(" ")[0]} · ${pe(p,s.answer,X(s))}%</button>`:"",w=e.showHints?`<div class="tt-hints-inline">${kt(e.state,s.id)}</div>`:"",T=(s.customCues??[]).slice(0,we(e.state,s.id)),_=T.length>0?`<div class="tt-cue-reveal">${T.map(L=>`<div>✎ ${U(L)}</div>`).join("")}</div>`:"";u+=`
      <div class="tt-answer-box">
        <div class="tt-answer-header">
          <span class="tt-answer-label">${m}</span>
          ${w}
          <div style="display:flex;align-items:center;margin-left:auto;gap:4px">
            ${f}${g}
            <button class="tt-bulb ${e.showHints?"tt-bulb--active":""}" id="tt-bulb">💡</button>
          </div>
        </div>
        ${_}
        <input class="tt-input" value="${U(a)}" placeholder="Type here..." autocomplete="off" autocorrect="off" autocapitalize="off" />
      </div>
    `}u+=vt(e.state,e.activeQueryId),u+=`<div class="tt-score">Exercise ${e.currentIndex+1} of ${e.exercises.length}</div>`,t.innerHTML=u;const h=a=>{!e.state||!s||(e.state=Ze(e.state,s.id,a.id),e.flashHint=a,e.suggested=null,e.suggestedFor=null,e.showHints=!1,z(e),setTimeout(()=>{e.flashHint===a&&(e.flashHint=null,z(e))},2e3))},v=t.querySelector("#tt-bulb");if(v&&s){let f=null,p=!1,g=!1,w=0,y=0,T=null;const _=()=>{T==null||T.classList.remove("tt-hint-chip--tracked"),T=null},L=(I,M)=>{var R,Ie;const N=(Ie=(R=document.elementFromPoint(I,M))==null?void 0:R.closest)==null?void 0:Ie.call(R,"[data-hint]");N!==T&&(_(),N&&!N.hasAttribute("disabled")&&(T=N,N.classList.add("tt-hint-chip--tracked")))},q=()=>{if(!e.state)return;const I=new Set;e.suggested&&I.add(e.suggested.id),e.lastSuggestion&&I.add(e.lastSuggestion);const M=e.suggested?new Set([e.suggested.id]):void 0,N=le(e.state,s.id,I)??le(e.state,s.id,M)??le(e.state,s.id);N&&(e.lastSuggestion=N.id,e.suggested=N,e.suggestedFor=s.id,e.flashHint=null,z(e))};v.addEventListener("pointerdown",I=>{I.preventDefault(),p=!1,g=!1,w=I.clientX,y=I.clientY,e.showHints||(f=setTimeout(()=>{f=null,g=!0,e.suggested=null,e.suggestedFor=null,e.flashHint=null,e.showHints=!0,z(e)},300));const M=R=>{!p&&Math.hypot(R.clientX-w,R.clientY-y)>10&&(p=!0),e.showHints&&L(R.clientX,R.clientY)},N=()=>{if(document.removeEventListener("pointermove",M),f&&(clearTimeout(f),f=null),e.showHints){const R=T;_(),R?h(Q(R.dataset.hint)):!g&&!p&&(e.showHints=!1,z(e))}else p||q()};document.addEventListener("pointermove",M),document.addEventListener("pointerup",N,{once:!0})}),v.addEventListener("contextmenu",I=>I.preventDefault())}(c=t.querySelector("#tt-suggested"))==null||c.addEventListener("click",()=>{const a=e.suggestedFor===(s==null?void 0:s.id)?e.suggested:null;a&&h(a)});const x=t.querySelector(".tt-input");x&&s&&(x.focus(),x.setSelectionRange(x.value.length,x.value.length),x.addEventListener("input",()=>{var f;if(!e.state||!s)return;e.flashHint=null,e.state=Je(e.state,s.id,x.value);const a=e.state.exercise.queries.find(p=>p.id===s.id),m=A(a);if(m.correct===m.total){(f=e.onWordComplete)==null||f.call(e,a.answer,e.currentIndex);const p=e.state.hintUsages.filter(y=>y.queryId===s.id),g=ie(p);e.completedScores.push({exerciseId:e.state.exercise.id,queryId:s.id,score:g,hintUsages:p.map(y=>({type:y.type,cost:y.cost}))});const w=e.state.exercise.queries.find(y=>y.id!==s.id&&A(y).correct!==A(y).total);if(w){St(t,g),setTimeout(()=>{e.activeQueryId=w.id,z(e)},1200);return}}z(e)}));const E=t.querySelector(".tt-help-bar"),$=t.querySelector(".tt-help-bar__ghost"),l=t.querySelector(".tt-help-bar__preview");t.querySelectorAll("[data-hint]").forEach(a=>{a.addEventListener("click",()=>{!e.state||!s||h(Q(a.dataset.hint))}),a.addEventListener("mouseenter",()=>{const m=Number(a.dataset.cost??0);if(!E||!$||m<=0)return;const f=Number(E.dataset.score??0);$.style.width=`${Math.max(0,Math.min(m,100-f))}%`,l&&(l.textContent=` → ${Math.min(Math.round(f+m),100)}%`)}),a.addEventListener("mouseleave",()=>{$&&($.style.width="0%"),l&&(l.textContent="")})}),t.querySelectorAll("[data-reveal-char]").forEach(a=>{a.addEventListener("click",m=>{var w;if(m.stopPropagation(),!e.state)return;const f=parseInt(a.dataset.revealChar,10),p=a.dataset.revealQuery;e.activeQueryId!==p&&(e.activeQueryId=p),e.state=et(e.state,p,f);const g=e.state.exercise.queries.find(y=>y.id===p);if(g){const y=A(g);y.correct===y.total&&((w=e.onWordComplete)==null||w.call(e,g.answer,e.currentIndex))}z(e)})}),t.querySelectorAll("[data-query]").forEach(a=>{a.addEventListener("click",()=>{const m=a.dataset.query;e.activeQueryId!==m&&(e.activeQueryId=m,z(e))})}),t.querySelectorAll("[data-query-dot]").forEach(a=>{a.addEventListener("click",()=>{const m=a.dataset.queryDot;e.activeQueryId=m,e.showHints=!1,e.flashHint=null,z(e)})}),Ce(e)}function Ce(e){var n,t;e.popup&&(e.popup.querySelectorAll("[data-action]").forEach(o=>{o.addEventListener("click",()=>{const i=o.dataset.action;i==="next"?(e.currentIndex++,e.activeQueryId=null,e.showHints=!1,e.flashHint=null,e.currentIndex<e.exercises.length&&(e.state=fe(e.exercises[e.currentIndex]),z(e))):i==="close"?Le(e):i==="save"&&ye(e.exercises,e.completedScores)})}),(n=e.popup.querySelector(".tt-popup__close"))==null||n.addEventListener("click",()=>{Le(e)}),(t=e.popup.querySelector(".tt-popup__minimize"))==null||t.addEventListener("click",()=>{e.minimized=!e.minimized;const o=e.popup.querySelector(".tt-popup__minimize");o&&(o.textContent=e.minimized?"▲":"▼"),z(e)}))}function Le(e){var n,t;e._keyHandler&&document.removeEventListener("keydown",e._keyHandler),(n=e.popup)==null||n.remove(),e.popup=null,(t=e.onClose)==null||t.call(e)}function U(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function Et(e,n){var s;Y(),(s=document.getElementById("tt-popup"))==null||s.remove();const t=document.createElement("div");t.id="tt-popup",t.className="tt-popup",t.innerHTML=`
    <div class="tt-popup__header">
      <span class="tt-popup__title">TipTong</span>
      <div style="display:flex;gap:8px">
        <button class="tt-popup__minimize" title="Minimize">▼</button>
        <button class="tt-popup__close" title="Close">&times;</button>
      </div>
    </div>
    <div class="tt-popup__body"></div>
  `,document.body.appendChild(t);const o={exercises:e,currentIndex:0,state:e.length>0?fe(e[0]):null,activeQueryId:null,showHints:!1,flashHint:null,minimized:!1,popup:t,suggested:null,suggestedFor:null,lastSuggestion:null,completedScores:[],onClose:n==null?void 0:n.onClose,onWordComplete:n==null?void 0:n.onWordComplete},i=d=>{if(d.key!=="Enter"||!o.popup)return;const u=o.popup.querySelector("[data-action='next']"),h=o.popup.querySelector("[data-action='close']");u?(d.preventDefault(),u.click()):h&&(d.preventDefault(),h.click())};document.addEventListener("keydown",i),o._keyHandler=i,z(o)}function Ct(e,n,t){const o=e.slice(n,t),i=[],s=/[\p{L}\p{M}'']+/gu;let d;for(;(d=s.exec(o))!==null;)i.push({start:n+d.index,end:n+d.index+d[0].length});return i.length===0?{start:n,end:t}:i[Math.floor(Math.random()*i.length)]}function Te(e,n){if(n.cue&&(e.queries=e.queries.map(t=>({...t,customCues:[n.cue]}))),n.type==="hhh")for(const t of n.underlinedWords){if(!t.cue)continue;const o=t.start-n.sentenceStart,i=t.end-n.sentenceStart,s=e.queries.find(d=>d.startIndex<i&&d.endIndex>o);s&&(s.customCues=[...s.customCues??[],t.cue])}return e}function _e(e){const n=[];for(const t of e)if(t.type==="qa"){const o=t.question+" "+t.answer,i=lt(o,{question:{start:0,end:t.question.length},answer:{start:t.question.length+1,end:o.length}});i&&n.push(Te(i,t))}else{let o=t.underlinedWords;o.length===0&&(o=[Ct(t.sourceText,t.sentenceStart,t.sentenceEnd)]);const i=st({sourceText:t.sourceText,sentenceSelection:{start:t.sentenceStart,end:t.sentenceEnd},wordSelections:o});i&&n.push(Te(i,t))}return n}function Lt(e,n){Et(_e(e),n)}function Tt(e){const n=_e(e);return n.length===0?!1:(Y(),ye(n),!0)}const D={green:F.brandEnergeticGreen,orange:F.brandBrightOrange,dark:F.brandDarkViolet},B={display:O.familyDisplay,sans:O.familySans,body:O.sizeBody,small:O.sizeSmall},V={lg:j.lg};function _t(){return window.__pdfReady?Promise.resolve():new Promise(e=>{document.addEventListener("tiptong:pdf-ready",()=>e(),{once:!0}),setTimeout(()=>e(),5e3)})}async function It(){await _t(),Y();const e=document.getElementById("pdf-container"),n=document.createElement("div");n.id="tt-toolbar",n.style.cssText=`
    position: fixed; top: 0; left: 0; right: 0; z-index: 999998;
    background: ${W.gradient}; padding: 10px 16px;
    display: flex; align-items: center; gap: 10px;
    border-bottom: ${W.cardBorder};
    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    font-family: ${B.sans};
  `,n.innerHTML=`
    <span style="color:${D.green};font-family:${B.display};font-weight:800;font-size: ${B.body}">TipTong</span>
    <span style="color:rgba(255,255,255,0.4);font-size: ${B.small};margin-right:auto">PDF</span>
    <div style="display:flex;background:rgba(255,255,255,0.15);border-radius: ${V.lg};overflow:hidden">
      <button data-tt-mode="hhh" style="background:transparent;border:none;color:rgba(255,255,255,0.7);padding:6px 12px;font-size: ${B.small};font-weight:600;cursor:pointer;border-radius: ${V.lg}">HHH</button>
      <button data-tt-mode="qa" style="background:white;border:none;color:${D.dark};padding:6px 12px;font-size: ${B.small};font-weight:600;cursor:pointer;border-radius: ${V.lg}">Q&A</button>
    </div>
    <button id="tt-delete-btn" style="background:transparent;border:1px solid rgba(255,138,0,0.5);color:${D.orange};padding:6px 12px;font-size: ${B.small};font-weight:600;cursor:pointer;border-radius: ${V.lg}">Delete</button>
    <span id="tt-status" style="color:rgba(255,255,255,0.7);font-size: ${B.small}">Select text to highlight</span>
    <button id="tt-save-btn" style="background:transparent;border:1px solid ${D.green};color:${D.green};padding:6px 14px;font-size: ${B.small};font-weight:bold;cursor:pointer;border-radius: ${V.lg}">Save</button>
    <button id="tt-play-btn" style="background:${D.green};border:none;color:${D.dark};padding:6px 16px;font-size: ${B.small};font-weight:bold;cursor:pointer;border-radius: ${V.lg}">Play</button>
  `,document.body.appendChild(n),e&&(e.style.top=n.offsetHeight+"px");const t=bt(),o=n.querySelector("#tt-status");n.querySelectorAll("[data-tt-mode]").forEach(h=>{h.addEventListener("click",()=>{n.querySelectorAll("[data-tt-mode]").forEach(v=>{v.style.background="transparent",v.style.color="rgba(255,255,255,0.7)"}),h.style.background="white",h.style.color=D.dark,t.setMode(h.dataset.ttMode),d()})});const i=n.querySelector("#tt-delete-btn");i.addEventListener("click",()=>{const h=t.toggleDeleteMode();i.style.background=h?D.orange:"transparent",i.style.color=h?"white":D.orange,i.textContent=h?"Done":"Delete"}),n.querySelector("#tt-save-btn").addEventListener("click",()=>{const h=t.validate();if(h.length>0){s(h[0]);return}const v=t.getOrderedExerciseData();if(v.length===0){o.textContent="No highlights yet";return}Tt(v)||(o.textContent="No complete exercises")}),n.querySelector("#tt-play-btn").addEventListener("click",()=>{if(t.getSelections().length===0){o.textContent="No highlights yet";return}const v=t.validate();if(v.length>0){s(v[0]);return}t.isDeleteMode()&&t.toggleDeleteMode(),i.style.display="none",t.showAnswers(),t.hideAnswers(),t.hideUnderlinedWords();const x=t.getOrderedExerciseData();if(x.length===0){o.textContent="No complete exercises",i.style.display="";return}Lt(x,{onClose:()=>{t.showAnswers(),i.style.display=""},onWordComplete:E=>t.revealWord(E)})});function s(h){var x;(x=document.querySelector(".tt-toast"))==null||x.remove();const v=document.createElement("div");v.className="tt-toast",v.textContent="⚠ "+h,document.body.appendChild(v),setTimeout(()=>v.remove(),3e3)}function d(){t.isDeleteMode()||(i.style.background="transparent",i.style.color=D.orange,i.textContent="Delete");const h=t.getSelections();if(h.length===0){o.textContent="Select text to highlight";return}const v=h.filter($=>$.role!=="sentence"),x=h.filter($=>$.role==="sentence"),E=[];if(v.length>0){const $=Math.floor(v.length/2);E.push(`${$} Q&A${v.length%2!==0?" · answer next":""}`)}x.length>0&&E.push(`${x.length} HHH`),o.textContent=E.join(" + ")}const u=()=>setTimeout(d,50);document.addEventListener("mouseup",u)}It()})();
