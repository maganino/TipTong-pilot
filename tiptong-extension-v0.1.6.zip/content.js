/*! TipTong Extension — © 2026 TipTong. All rights reserved.
 * Proprietary software. No license is granted to copy, modify, or redistribute. */(function(){"use strict";const Y={brandElectricViolet:"#4E15FF",brandEnergeticGreen:"#0FFFB9",brandDarkViolet:"#160751",brandBrightOrange:"#FF5400",brandBrightYellow:"#FFDE00",brandWhite:"#FFFFFF",supportLavender:"#B6A6EB"},B={familyDisplay:"Bryant, Nunito, Montserrat, system-ui, sans-serif",familySans:'Montserrat, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif',sizeHero:"48px",sizeH1:"32px",sizeH2:"24px",sizeLabel:"18px",sizeBody:"16px",sizeSmall:"14px"},te={tile:"2px",sm:"5px",md:"12px",lg:"16px",xl:"24px",pill:"100px"},E={display:B.familyDisplay,sans:B.familySans,hero:B.sizeHero,h1:B.sizeH1,h2:B.sizeH2,label:B.sizeLabel,body:B.sizeBody,small:B.sizeSmall},N={tile:te.tile,sm:te.sm,md:te.md,lg:te.lg,xl:te.xl,pill:te.pill},a={violet:Y.brandElectricViolet,green:Y.brandEnergeticGreen,orange:Y.brandBrightOrange,yellow:Y.brandBrightYellow,dark:Y.brandDarkViolet,white:Y.brandWhite,lavender:Y.supportLavender,greenInk:"#0A9E74"},Q={gradient:`linear-gradient(170deg, #14406B 0%, #16265C 55%, ${a.dark} 100%)`,card:"rgba(255,255,255,0.06)",cardBorder:"1px solid rgba(255,255,255,0.12)"},mt=`
.tt-highlight {
  background-color: ${a.violet}20 !important;
  border-bottom: 2px solid ${a.violet}60 !important;
  border-radius: ${N.tile} !important;
  cursor: pointer !important;
  transition: background-color 0.15s !important;
  position: relative !important;
  display: inline !important;
}
.tt-highlight:hover {
  background-color: ${a.violet}35 !important;
}
.tt-highlight--answer {
  background-color: ${a.green}20 !important;
  border-bottom-color: ${a.green}60 !important;
}
.tt-highlight--answer:hover {
  background-color: ${a.green}35 !important;
}
.tt-highlight--delete {
  background-color: ${a.orange}20 !important;
  border-bottom-color: ${a.orange} !important;
  text-decoration: line-through !important;
  cursor: pointer !important;
}
.tt-underline {
  border-bottom: 2px dotted ${a.green} !important;
  font-weight: bold !important;
  background-color: ${a.green}20 !important;
  border-radius: ${N.tile} !important;
  cursor: pointer !important;
}
.tt-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  border-radius: ${N.sm};
  color: white;
  font-size: ${E.small};
  font-weight: bold;
  margin-right: 3px;
  vertical-align: middle;
  line-height: 16px;
}
.tt-badge--q { background-color: ${a.violet}; }
.tt-badge--a { background-color: ${a.green}; }

/* Interactive sentence (HHH inline blanks) */
.tt-sentence {
  font-size: ${E.body};
  line-height: 2;
  background: ${Q.card};
  border: ${Q.cardBorder};
  border-radius: ${N.md};
  padding: 12px 16px;
  margin-bottom: 12px;
  color: ${a.white};
}
.tt-sentence-text { color: ${a.white}; }
.tt-inline-blank {
  font-weight: bold;
  color: ${a.lavender};
  background: ${a.white}10;
  border-radius: ${N.sm};
  padding: 2px 6px;
  cursor: pointer;
}
.tt-inline-blank--active {
  background: ${a.green}20;
  color: ${a.green};
}
.tt-inline-char { font-size: ${E.body}; }
.tt-inline-char--revealed { color: ${a.white}; background: ${a.green}; border-radius: ${N.tile}; padding: 0 1px; }
.tt-inline-char--correct { color: ${a.green}; font-weight: bold; }
.tt-inline-char--wrong { color: ${a.orange}; font-weight: bold; }
.tt-inline-char--empty { color: ${a.white}30; }
.tt-solved {
  font-weight: bold;
  color: ${a.green};
  background: ${a.green}10;
  border-radius: ${N.sm};
  padding: 2px 4px;
}

/* Word progress dots */
.tt-word-progress {
  display: flex;
  gap: 12px;
  justify-content: center;
  margin-bottom: 12px;
}
.tt-word-dot {
  width: 24px;
  height: 24px;
  border-radius: ${N.md};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: ${E.small};
  font-weight: 600;
  cursor: pointer;
  background: ${a.white}20;
  color: ${a.white};
  opacity: 0.6;
}
.tt-word-dot--done { background: ${a.green}; opacity: 1; }
.tt-word-dot--active { background: ${a.white}; color: ${a.green}; border: 2px solid ${a.green}; opacity: 1; }

/* Answer box */
.tt-answer-box {
  background: ${a.white}10;
  border-radius: ${N.md};
  padding: 12px;
  margin-top: 8px;
  border: 1px solid ${a.green}40;
}
.tt-answer-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}
.tt-answer-label {
  font-size: ${E.small};
  color: ${a.white};
  opacity: 0.6;
  text-transform: uppercase;
  letter-spacing: 1px;
}
.tt-bulb {
  /* The browser must not turn the fan drag into a scroll or text selection. */
  touch-action: none;
  user-select: none;
  background: ${a.white}15;
  border: none;
  border-radius: ${N.lg};
  width: 32px;
  height: 32px;
  font-size: ${E.body};
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
}
.tt-bulb:hover, .tt-bulb--active { background: ${a.yellow}40; }
.tt-hint-container { margin-bottom: 8px; }
.tt-blank--active { border-bottom-color: ${a.green}; }

/* Player popup */
.tt-popup {
  position: fixed;
  bottom: 20px;
  right: 20px;
  width: 380px;
  max-width: calc(100vw - 40px);
  background: ${Q.gradient};
  border: ${Q.cardBorder};
  border-radius: ${N.xl};
  box-shadow: 0 8px 32px rgba(0,0,0,0.4);
  z-index: 999999;
  font-family: ${E.sans};
  color: ${a.white};
  overflow: hidden;
}
.tt-popup__header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px;
  background: ${Q.card};
  border-bottom: ${Q.cardBorder};
}
.tt-popup__title {
  font-family: ${E.display};
  font-size: ${E.small};
  font-weight: 800;
  letter-spacing: 0.02em;
  color: ${a.green};
}
.tt-popup__close {
  background: none;
  border: none;
  color: ${a.white};
  font-size: ${E.label};
  cursor: pointer;
  opacity: 0.7;
  padding: 4px;
}
.tt-popup__minimize {
  background: none;
  border: none;
  color: ${a.white};
  font-size: ${E.small};
  cursor: pointer;
  opacity: 0.7;
  padding: 4px;
}
.tt-popup__close:hover, .tt-popup__minimize:hover { opacity: 1; }
.tt-popup__body {
  padding: 16px;
}
.tt-popup__question {
  font-size: ${E.body};
  line-height: 1.5;
  margin-bottom: 16px;
  color: ${a.white};
}

/* Blank boxes */
.tt-blanks {
  display: flex;
  flex-wrap: wrap;
  gap: 3px;
  margin-bottom: 12px;
}
.tt-blank-word-gap { width: 12px; }
.tt-blank {
  width: 22px;
  height: 28px;
  border-radius: ${N.sm};
  background: ${a.white}15;
  border-bottom: 2px solid ${a.violet}40;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: ${E.small};
  font-weight: bold;
  color: ${a.white}50;
}
.tt-blank--correct {
  color: ${a.green};
  background: ${a.green}15;
  border-bottom-color: ${a.green};
}
.tt-blank--wrong {
  color: ${a.orange};
  background: ${a.orange}15;
  border-bottom-color: ${a.orange};
}
.tt-blank--revealed {
  color: ${a.white};
  background: ${a.green};
  border-bottom-color: ${a.green};
}
.tt-blank--shuffled {
  color: ${a.yellow};
  background: ${a.yellow}15;
  border-bottom-color: ${a.yellow}40;
}

/* Input */
.tt-input {
  width: 100%;
  height: 40px;
  background: ${a.white}15;
  border: none;
  border-radius: ${N.sm};
  color: ${a.white};
  font-size: ${E.body};
  text-align: center;
  font-weight: 600;
  outline: none;
  box-sizing: border-box;
  padding: 0 12px;
}
.tt-input::placeholder { color: ${a.white}40; }
.tt-input:focus { box-shadow: 0 0 0 2px ${a.green}60; }

/* Hint bar */
.tt-hints {
  display: flex;
  gap: 6px;
  overflow-x: auto;
  padding: 8px 0;
  scrollbar-width: none;
}
.tt-hints::-webkit-scrollbar { display: none; }
.tt-hint-chip {
  display: flex;
  align-items: center;
  gap: 4px;
  background: ${a.white}15;
  border: none;
  border-radius: ${N.lg};
  padding: 6px 10px;
  color: ${a.white};
  font-size: ${E.small};
  font-weight: 600;
  cursor: pointer;
  white-space: nowrap;
  transition: background 0.15s;
}
.tt-hint-chip:hover { background: ${a.white}25; }
.tt-hint-chip--disabled { opacity: 0.3; pointer-events: none; }
/* Chip under the finger during a fan drag — dock magnification */
.tt-hint-chip--tracked {
  background: ${a.green}30;
  outline: 1px solid ${a.green};
  transform: scale(1.12);
}
/* Pending bulb suggestion, glowing for its confirming tap */
.tt-hint-chip--suggested {
  border: 1px solid ${a.green};
  background: ${a.green}15;
  cursor: pointer;
  box-shadow: 0 0 8px ${a.green}60;
}
/* Help progress bar */
.tt-help-bar {
  padding: 8px 12px;
}
.tt-help-bar__labels {
  display: flex;
  justify-content: space-between;
  margin-bottom: 4px;
}
.tt-help-bar__label {
  font-size: ${E.small};
  font-weight: 600;
  color: ${a.white};
}
.tt-help-bar__avg {
  font-size: ${E.small};
  color: ${a.white};
  opacity: 0.5;
}
.tt-help-bar__track {
  position: relative;
  height: 6px;
  border-radius: ${N.tile};
  background: ${a.white}15;
  overflow: hidden;
}
.tt-help-bar__fill {
  height: 100%;
  border-radius: ${N.tile};
  transition: width 0.3s ease, background-color 0.3s ease;
}
/* Hover price preview: grows out of the fill while a hint chip is hovered */
.tt-help-bar__ghost {
  position: absolute;
  top: 0;
  height: 100%;
  width: 0;
  background: ${a.white}55;
  border-radius: ${N.tile};
  transition: width 0.15s ease;
  pointer-events: none;
}
.tt-help-bar__preview {
  color: ${a.yellow};
  font-weight: 600;
}

/* Hint flash pill — inline to left of bulb */
.tt-hint-flash-inline {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  background: ${a.white}10;
  border: 1px solid ${a.green}40;
  border-radius: ${N.md};
  padding: 3px 8px;
  font-size: ${E.small};
  color: ${a.white};
  white-space: nowrap;
}

/* Hints bar inline in header */
.tt-hints-inline {
  flex: 1;
  overflow-x: auto;
  margin: 0 4px;
}
.tt-hints-inline::-webkit-scrollbar { display: none; }
.tt-hints-inline .tt-hints {
  flex-wrap: nowrap;
  gap: 4px;
}
.tt-hints-inline .tt-hint-chip {
  padding: 4px 8px;
  font-size: ${E.small};
}

/* Revealed "My cue" lines above the input */
.tt-cue-reveal {
  margin-bottom: 8px;
  display: grid;
  gap: 4px;
}
.tt-cue-reveal div {
  font-size: ${E.small};
  color: ${a.yellow};
  background: ${a.yellow}12;
  border-radius: ${N.sm};
  padding: 4px 8px;
}

/* ✎ marker on highlights that carry an authored cue */
.tt-has-cue::after {
  content: "✎";
  font-size: 10px;
  vertical-align: super;
  color: ${a.violet};
  opacity: 0.8;
  margin-left: 1px;
}

/* Cue editor (long-press on a highlight or underline) */
.tt-cue-context {
  font-size: ${E.small};
  color: ${a.lavender};
  font-style: italic;
  margin-bottom: 10px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.tt-cue-input {
  width: 100%;
  box-sizing: border-box;
  height: 36px;
  background: ${a.white}10;
  border: 1px solid ${a.white}20;
  border-radius: ${N.sm};
  padding: 0 10px;
  font-size: ${E.small};
  color: ${a.white};
  outline: none;
}
.tt-cue-input:focus { box-shadow: 0 0 0 2px ${a.green}60; }
.tt-cue-actions {
  display: flex;
  gap: 8px;
  margin-top: 14px;
  align-items: center;
}
.tt-cue-remove {
  font-size: ${E.small};
  color: ${a.orange};
  cursor: pointer;
  margin-right: auto;
}

/* Save modal */
.tt-save-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999999;
  padding: 24px;
}
.tt-save-card {
  background: ${Q.gradient};
  border: ${Q.cardBorder};
  border-radius: ${N.lg};
  padding: 20px;
  width: 100%;
  max-width: 360px;
  color: ${a.white};
}
.tt-save-card h3 {
  margin: 0;
  font-family: ${E.display};
  font-weight: 800;
  font-size: ${E.label};
}
.tt-save-card .tt-save-sub {
  font-size: ${E.small};
  opacity: 0.6;
  margin-top: 2px;
}

/* The invite: a centered hand-off card — the app surface in miniature,
   one number, one line, one glowing way forward. */
@keyframes tt-pop {
  from { opacity: 0; transform: scale(0.94) translateY(10px); }
  to   { opacity: 1; transform: scale(1) translateY(0); }
}
.tt-save-card--invite {
  text-align: center;
  padding: 26px 24px 18px;
  /* A green dawn over the app gradient — the moment feels like a win */
  background:
    radial-gradient(420px 220px at 50% -40%, ${a.green}2E, transparent 65%),
    ${Q.gradient};
  animation: tt-pop 0.25s ease-out;
}
.tt-save-wordmark {
  font-family: ${E.display};
  font-weight: 800;
  font-size: ${E.small};
  letter-spacing: 0.04em;
  color: ${a.green};
}
.tt-save-num {
  font-family: ${E.display};
  font-weight: 800;
  font-size: 46px;
  line-height: 1.1;
  color: ${a.yellow};
  margin-top: 8px;
}
.tt-save-what {
  font-size: ${E.body};
  font-weight: 700;
  color: ${a.white};
  margin-bottom: 8px;
}
.tt-save-line {
  font-size: ${E.small};
  color: ${a.lavender};
  line-height: 1.5;
  max-width: 30ch;
  margin: 0 auto 18px;
}
.tt-save-go-btn {
  width: 100%;
  box-sizing: border-box;
  background: ${a.green};
  color: ${a.dark};
  border: none;
  border-radius: ${N.pill};
  padding: 13px 16px;
  font-family: ${E.display};
  font-size: ${E.body};
  font-weight: 800;
  cursor: pointer;
  box-shadow: 0 6px 20px ${a.green}40;
  transition: transform 0.12s ease, box-shadow 0.12s ease;
}
.tt-save-go-btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 8px 24px ${a.green}55;
}
.tt-save-done-ring {
  width: 56px;
  height: 56px;
  margin: 8px auto 12px;
  border-radius: ${N.pill};
  background: ${a.green};
  color: ${a.dark};
  font-size: ${E.h2};
  font-weight: 800;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 6px 20px ${a.green}40;
}
.tt-save-row {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 8px;
  border-bottom: 1px solid ${a.white}10;
  cursor: pointer;
  border-radius: ${N.sm};
}
.tt-save-row:hover {
  background: ${a.white}10;
}
.tt-save-input {
  flex: 1;
  height: 32px;
  background: ${a.white}10;
  border: 1px solid ${a.white}20;
  border-radius: ${N.sm};
  padding: 0 8px;
  font-size: ${E.small};
  color: ${a.white};
}
.tt-save-input::placeholder { color: ${a.white}40; }
.tt-save-create-btn {
  background: ${a.green};
  border: none;
  border-radius: ${N.pill};
  padding: 6px 14px;
  font-weight: bold;
  color: ${a.dark};
  cursor: pointer;
  font-size: ${E.small};
}
.tt-save-cancel {
  text-align: center;
  margin-top: 12px;
  font-size: ${E.small};
  opacity: 0.5;
  cursor: pointer;
}
.tt-save-check {
  text-align: center;
  font-size: ${E.h1};
  color: ${a.green};
}
.tt-save-msg {
  text-align: center;
  font-size: ${E.small};
  font-weight: 600;
  margin-top: 8px;
}

/* Toast animations */
@keyframes tt-fade-in {
  from { opacity: 0; transform: translateY(-4px); }
  to { opacity: 1; transform: translateY(0); }
}
@keyframes tt-toast-fade {
  0% { opacity: 0; transform: translateY(-10px); }
  10% { opacity: 1; transform: translateY(0); }
  80% { opacity: 1; transform: translateY(0); }
  100% { opacity: 0; transform: translateY(-10px); }
}
.tt-toast {
  position: fixed;
  top: 52px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 999999;
  background: ${a.orange};
  color: white;
  padding: 10px 20px;
  border-radius: ${N.sm};
  font-family: ${E.sans};
  font-size: ${E.small};
  font-weight: 600;
  box-shadow: 0 4px 12px rgba(0,0,0,0.3);
  animation: tt-toast-fade 3s ease forwards;
  pointer-events: none;
}

/* Score */
.tt-score {
  text-align: center;
  padding: 8px;
  font-size: ${E.small};
  color: ${a.white};
  opacity: 0.6;
}

/* Complete state */
.tt-complete {
  text-align: center;
  padding: 20px;
}
.tt-complete__check {
  font-size: ${E.hero};
  color: ${a.green};
  margin-bottom: 8px;
}
.tt-complete__score {
  font-size: ${E.h1};
  font-weight: bold;
  /* Not electric violet: on the dark surface it reads as a gap (see HelpDonut). */
  color: ${a.yellow};
}

/* Cue editor card + first-run guide.
   These render inside arbitrary host pages whose CSS can reach into our
   DOM (no shadow root), so every text/background property that decides
   legibility is pinned with !important — a host rule once turned the cue
   input's text black on the dark card. */
.tt-brand-row {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 12px;
}
.tt-brand-row svg { display: block; flex: none; }
.tt-brand-title {
  font-family: ${E.display} !important;
  font-weight: 800 !important;
  font-size: ${E.label} !important;
  color: ${a.white} !important;
  margin: 0 !important;
  line-height: 1.2 !important;
}
.tt-brand-kicker {
  font-family: ${E.sans} !important;
  font-size: ${E.small} !important;
  color: ${a.lavender} !important;
  margin: 0 !important;
}
.tt-cue-card .tt-cue-context {
  color: ${a.lavender} !important;
  background: ${a.white}0A;
  border-radius: ${N.sm};
  padding: 8px 10px;
}
.tt-cue-card .tt-cue-input {
  color: ${a.white} !important;
  background: ${a.white}12 !important;
  caret-color: ${a.green} !important;
  font-family: ${E.sans} !important;
  -webkit-text-fill-color: ${a.white} !important;
}
.tt-cue-card .tt-cue-input::placeholder {
  color: ${a.white} !important;
  -webkit-text-fill-color: ${a.white} !important;
  opacity: 0.45 !important;
}
.tt-cue-card .tt-save-cancel,
.tt-cue-card .tt-cue-remove { font-family: ${E.sans} !important; }
.tt-cue-meta {
  margin-top: 5px;
  font-family: ${E.sans} !important;
  font-size: 11px !important;
  color: ${a.lavender} !important;
  opacity: 0.8;
  text-align: right;
}
.tt-cue-meta--over {
  color: ${a.orange} !important;
  opacity: 1;
  font-weight: 700 !important;
}
.tt-param-label {
  display: block;
  margin-bottom: 6px;
  font-family: ${E.sans} !important;
  font-size: ${E.small} !important;
  font-weight: 700 !important;
  color: ${a.white} !important;
}
.tt-param-hint {
  margin: 6px 0 0 !important;
  font-family: ${E.sans} !important;
  font-size: 11px !important;
  color: ${a.lavender} !important;
  line-height: 1.5 !important;
}

/* First-run guide */
.tt-guide-steps { display: grid; gap: 12px; margin: 14px 0 18px; }
.tt-guide-step { display: flex; gap: 12px; align-items: flex-start; }
.tt-guide-num {
  flex: none;
  width: 26px; height: 26px;
  border-radius: ${N.pill};
  background: ${a.green};
  color: ${a.dark} !important;
  font-family: ${E.display} !important;
  font-weight: 800 !important;
  font-size: ${E.small} !important;
  display: flex; align-items: center; justify-content: center;
}
.tt-guide-step b {
  color: ${a.white} !important;
  font-family: ${E.sans} !important;
  font-size: ${E.body} !important;
  font-weight: 700 !important;
}
.tt-guide-step p {
  margin: 2px 0 0 !important;
  color: ${a.lavender} !important;
  font-family: ${E.sans} !important;
  font-size: ${E.small} !important;
  line-height: 1.5 !important;
}
.tt-guide-chip {
  display: inline-block;
  font-family: ${E.display} !important;
  font-weight: 800 !important;
  font-size: 11px !important;
  color: ${a.green} !important;
  border: 1px solid ${a.green}60;
  border-radius: ${N.pill};
  padding: 0 7px;
}
`;function pe(e=34){return`<svg width="${e}" height="${e}" viewBox="0 0 46.18 46.18" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <rect width="46.18" height="46.18" rx="10.2" fill="#0FFFB9"/>
    <g transform="translate(-79 -333)" fill="#4E15FF">
      <path d="M99.8499 344.37H88.4299C87.1499 344.37 86.1699 345.38 86.1699 346.63C86.1699 347.88 87.1799 348.85 88.4299 348.85H95.1199V368.19C95.1199 369.51 96.1299 370.6 97.4499 370.6C98.7699 370.6 99.8599 369.51 99.8599 368.19V348.84L99.8399 344.37H99.8499Z"/>
      <path d="M112.49 344.37H104.8V348.84H112.49C113.77 348.84 114.75 347.83 114.75 346.62C114.75 345.41 113.74 344.36 112.49 344.36V344.37Z"/>
      <path d="M104.66 355.42C104.66 354.14 105.71 353.09 107 353.09C108.29 353.09 109.34 354.14 109.34 355.42V368.26C109.34 369.54 108.29 370.59 107 370.59C105.71 370.59 104.66 369.54 104.66 368.26V355.42Z"/>
    </g>
  </svg>`}function ee(){if(document.getElementById("tt-styles"))return;bt();const e=document.createElement("style");e.id="tt-styles",e.textContent=mt,document.head.appendChild(e)}function bt(){if(!document.getElementById("tt-fonts"))try{const e=document.createElement("link");e.id="tt-fonts",e.rel="stylesheet",e.href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Nunito:wght@700&display=swap",document.head.appendChild(e)}catch{}}const vt=`
::highlight(tt-question) {
  background-color: ${a.violet}20;
  color: inherit;
}
::highlight(tt-answer) {
  background-color: ${a.green}20;
  color: inherit;
}
::highlight(tt-sentence) {
  background-color: ${a.violet}20;
  color: inherit;
}
::highlight(tt-underline) {
  background-color: ${a.green}20;
  text-decoration: underline dotted ${a.green};
  text-decoration-thickness: 2px;
  color: inherit;
}
::highlight(tt-delete) {
  background-color: ${a.orange}20;
  text-decoration: line-through;
  color: inherit;
}
`;function xt(){if(document.getElementById("tt-css-highlight-styles"))return;const e=document.createElement("style");e.id="tt-css-highlight-styles",e.textContent=vt,document.head.appendChild(e)}const Me=50;var W=(e=>(e.CHARACTER_PLACEHOLDERS="CHARACTER_PLACEHOLDERS",e.NEXT_LETTER="NEXT_LETTER",e.ALL_VOWELS="ALL_VOWELS",e.ALL_CONSONANTS="ALL_CONSONANTS",e.SHUFFLED_LETTERS="SHUFFLED_LETTERS",e.RANDOM_LETTER="RANDOM_LETTER",e.HANGMAN="HANGMAN",e.FIRST_CONSONANT="FIRST_CONSONANT",e.FIRST_VOWEL="FIRST_VOWEL",e.CONSONANT_LIST="CONSONANT_LIST",e.SELF_AUTHORED="SELF_AUTHORED",e))(W||{});function he(e){return e.normalize("NFD").replace(/[\u0300-\u036f]/g,"")}const ge=new Set(["a","e","i","o","u","y"]);function Ie(e){const t=[...e];for(let n=t.length-1;n>0;n--){const o=Math.floor(Math.random()*(n+1));[t[n],t[o]]=[t[o],t[n]]}return t}function ye(e){return e>0?100/e:0}function wt(e,t){let n=0;for(let o=0;o<e.length;o++)t.has(o)&&n++;return n}const yt={id:W.CHARACTER_PLACEHOLDERS,label:"Show length",icon:"📏",iconName:"ruler",description:"Shows how many characters the word has",repeatable:!1,autoRevealsLength:!0,revealsPositions:!1,costType:"free",modality:"text",group:"reveal",apply(e,t){return{type:this.id,revealedIndices:[],cost:0}}},$t={id:W.NEXT_LETTER,label:"Next letter",icon:"➡️",iconName:"arrow-right",description:"Reveals the next unrevealed letter from left to right",repeatable:!0,autoRevealsLength:!1,revealsPositions:!0,costType:"per-letter",modality:"text",group:"reveal",apply(e,t){for(let n=0;n<e.length;n++)if(!t.has(n))return{type:this.id,revealedIndices:[n],cost:ye(e.length)};return{type:this.id,revealedIndices:[],cost:0}}},kt={id:W.ALL_VOWELS,label:"Vowels",icon:"🔤",iconName:"vowels",description:"Reveals all vowels (a, e, i, o, u, y — including accented)",repeatable:!1,autoRevealsLength:!0,revealsPositions:!0,costType:"proportional",modality:"text",group:"reveal",apply(e,t){const n=e.toLowerCase(),o=[];for(let r=0;r<e.length;r++)ge.has(he(n[r]))&&!t.has(r)&&o.push(r);return{type:this.id,revealedIndices:o,cost:e.length>0?o.length/e.length*100:0}}},St={id:W.ALL_CONSONANTS,label:"Consonants",icon:"🔡",iconName:"consonants",description:"Reveals all consonants (including accented like ç, ñ)",repeatable:!1,autoRevealsLength:!0,revealsPositions:!0,costType:"proportional",modality:"text",group:"reveal",apply(e,t){const n=e.toLowerCase(),o=[];for(let r=0;r<e.length;r++)!ge.has(he(n[r]))&&!t.has(r)&&o.push(r);return{type:this.id,revealedIndices:o,cost:e.length>0?o.length/e.length*100:0}}},Et={id:W.SHUFFLED_LETTERS,label:"Shuffle",icon:"🔀",iconName:"shuffle",description:"Shuffles the letters within each word (doesn't reveal positions)",repeatable:!0,autoRevealsLength:!0,revealsPositions:!1,costType:"flat",flatCost:40,modality:"text",group:"reorder",apply(e,t){const n=e.length-wt(e,t);if(n===0)return{type:this.id,revealedIndices:[],cost:0};const o=e.split(" ").map(r=>Ie(r.split("")).join("")).join(" ");return{type:this.id,revealedIndices:[],cost:40*(n/e.length),displayData:o}}},Ct={id:W.RANDOM_LETTER,label:"Random",icon:"🎲",iconName:"dice",description:"Reveals one random unrevealed letter",repeatable:!0,autoRevealsLength:!0,revealsPositions:!0,costType:"per-letter",modality:"text",group:"reveal",apply(e,t){const n=[];for(let r=0;r<e.length;r++)t.has(r)||n.push(r);if(n.length===0)return{type:this.id,revealedIndices:[],cost:0};const o=n[Math.floor(Math.random()*n.length)];return{type:this.id,revealedIndices:[o],cost:ye(e.length)}}},Tt={id:W.HANGMAN,label:"Structure",icon:"␣",iconName:"slots",description:"Shows the word breaks and punctuation, with a slot for each letter",repeatable:!1,autoRevealsLength:!0,revealsPositions:!0,costType:"proportional",modality:"text",group:"reveal",apply(e,t){const n=[];for(let o=0;o<e.length;o++){const r=e[o];!/[\p{L}\p{N}]/u.test(r)&&!t.has(o)&&n.push(o)}return{type:this.id,revealedIndices:n,cost:e.length>0?n.length/e.length*100:0}}};function Ne(e,t){return(n,o)=>{const r=n.toLowerCase();for(let s=0;s<n.length;s++){const i=he(r[s]);if(/[a-z]/.test(i)&&ge.has(i)===t&&!o.has(s))return{type:e,revealedIndices:[s],cost:ye(n.length)}}return{type:e,revealedIndices:[],cost:0}}}const _t={id:W.FIRST_CONSONANT,label:"Consonant",icon:"🔡",iconName:"consonant",description:"Reveals the first consonant, then each following one",repeatable:!0,autoRevealsLength:!1,revealsPositions:!0,costType:"per-letter",modality:"text",group:"reveal",apply(e,t){return Ne(W.FIRST_CONSONANT,!1)(e,t)}},Lt={id:W.FIRST_VOWEL,label:"Vowel",icon:"🔤",iconName:"vowel",description:"Reveals the first vowel, then each following one",repeatable:!0,autoRevealsLength:!1,revealsPositions:!0,costType:"per-letter",modality:"text",group:"reveal",apply(e,t){return Ne(W.FIRST_VOWEL,!0)(e,t)}},Rt={id:W.CONSONANT_LIST,label:"Consonant list",icon:"🔡",iconName:"list",description:"Lists the consonants you still need in random order, without their positions",repeatable:!1,autoRevealsLength:!1,revealsPositions:!1,costType:"proportional",modality:"text",group:"reorder",apply(e,t){const n=e.toLowerCase(),o=[];for(let r=0;r<e.length;r++){if(t.has(r))continue;const s=n[r],i=he(s);/[a-z]/.test(i)&&!ge.has(i)&&o.push(s)}return o.length===0?{type:this.id,revealedIndices:[],cost:0}:{type:this.id,revealedIndices:[],cost:e.length>0?o.length/e.length*50:0,displayData:Ie(o).join(" ")}}},$e=[{id:W.SELF_AUTHORED,label:"My cue",icon:"✎",iconName:"pen",description:"Shows a cue you wrote yourself when creating this exercise",repeatable:!0,autoRevealsLength:!1,revealsPositions:!1,costType:"flat",flatCost:10,modality:"text",group:"reveal",apply(e,t){return{type:this.id,revealedIndices:[],cost:10}}},yt,$t,Ct,kt,Lt,St,_t,Rt,Et],At=[...$e,Tt];function re(e){const t=At.find(n=>n.id===e);if(!t)throw new Error(`Unknown hint type: ${e}`);return t}function Ht(e,t,n=new Set){return re(t).apply(e,n)}function ke(e){const t=e.reduce((n,o)=>n+o.cost,0);return Math.min(t,100)}function Oe(e,t,n){return e.apply(t,new Set(n))}function qe(e,t,n){return Oe(e,t,n).cost}function Mt(e,t,n,o={}){if(t.length===0)return!1;if(e.id===W.CHARACTER_PLACEHOLDERS)return o.lengthAlreadyKnown!==!0;if(e.id===W.SELF_AUTHORED)return o.remainingCues===void 0||o.remainingCues>0;const r=Oe(e,t,n);return r.revealedIndices.length>0||r.displayData!==void 0}function It(e,t){return(e??[]).slice(t)}let We="strict";function fe(){return We}function Nt(e){return e.normalize("NFD").replace(/[̀-ͯ]/g,"")}function De(e,t){const n=e.toLowerCase();return t==="strict"?n:Nt(n)}function me(e,t,n=We){return t===""?!1:De(e,n)===De(t,n)}function ae(e,t=fe()){const n=new Set;return e.blanks.forEach((o,r)=>{(o.revealed||me(o.expected,o.actual,t))&&n.add(r)}),n}function ze(e){return{exercise:e,hintUsages:[],isComplete:!1,shuffledLettersMap:{}}}function Ot(e){return e.blanks.map(t=>t.actual).join("")}function qt(e,t,n,o=fe()){const r=e.exercise.queries.find($=>$.id===t);if(!r)return e;const s=z(r,o);if(s.correct===s.total)return e;const i=r.blanks.map(($,L)=>{const _=n[L]??"";return $.revealed&&_!==""&&!me($.expected,_,o)?{...$,actual:_,revealed:!1}:{...$,actual:_}}),c={...r,blanks:i},f=e.exercise.queries.map($=>$.id===t?c:$),p={...e.exercise,queries:f};return{...e,exercise:p,isComplete:Se(p)}}function Wt(e,t,n){const o=e.exercise.queries.find(d=>d.id===t);if(!o)return e;const r=re(n),s=ae(o);if(!r.repeatable&&e.hintUsages.some(h=>h.queryId===t&&h.type===n))return e;const i=Ht(o.answer,n,s);if(r.id!==W.CHARACTER_PLACEHOLDERS&&i.revealedIndices.length===0&&!i.displayData&&i.cost===0)return e;const c=o.blanks.map((d,h)=>i.revealedIndices.includes(h)?{...d,revealed:!0}:d),f={...o,blanks:c},p=e.exercise.queries.map(d=>d.id===t?f:d),$={queryId:t,type:n,cost:i.cost,usedAt:new Date,displayData:i.displayData},L={...e.exercise,queries:p},_={...e.shuffledLettersMap};return i.displayData&&n==="SHUFFLED_LETTERS"&&(_[t]=i.displayData),{...e,exercise:L,hintUsages:[...e.hintUsages,$],isComplete:Se(L),shuffledLettersMap:_}}function Dt(e,t,n){const o=e.exercise.queries.find($=>$.id===t);if(!o||n<0||n>=o.blanks.length||ae(o).has(n))return e;const r=o.blanks.map(($,L)=>L===n?{...$,revealed:!0}:$),s={...o,blanks:r},i=e.exercise.queries.map($=>$.id===t?s:$),c=o.answer.length>0?100/o.answer.length:0,f={queryId:t,type:W.NEXT_LETTER,cost:c,usedAt:new Date},p={...e.exercise,queries:i};return{...e,exercise:p,hintUsages:[...e.hintUsages,f],isComplete:Se(p)}}function Se(e,t=fe()){return e.queries.every(n=>n.blanks.every(o=>me(o.expected,o.actual,t)))}function z(e,t=fe()){const n=e.blanks.length;return{correct:e.blanks.filter(r=>me(r.expected,r.actual,t)).length,total:n}}function Fe(){return Math.random().toString(36).substring(2,10)}function zt(e){return Array.from(e).filter(t=>/[\p{L}\p{M}'''\-\s]/u.test(t)).join("")}function Ft(e){return e.split("").map(t=>({expected:t,actual:"",revealed:!1}))}function Bt(e){const t=e.match(/^[.,;:!?'"()\-–—\s]+/),n=t?t[0].length:0,o=e.match(/[.,;:!?'"()\-–—\s]+$/),r=o?o[0].length:0;return{cleaned:e.slice(n,e.length-r||void 0),leadingLen:n,trailingLen:r}}function Pt(e,t){if(e.length<=1)return e;const n=[...e].sort((r,s)=>r.start-s.start),o=[{...n[0]}];for(let r=1;r<n.length;r++){const s=n[r],i=o[o.length-1];t.slice(i.end,s.start).trim().length===0?i.end=s.end:o.push({...s})}return o}function jt(e){if(!e.sentenceSelection||e.wordSelections.length===0)return null;const t=e.sourceText.slice(e.sentenceSelection.start,e.sentenceSelection.end),n=Pt(e.wordSelections,e.sourceText),o=[];let r=t;for(let s=n.length-1;s>=0;s--){const i=n[s],c=i.start-e.sentenceSelection.start,f=i.end-e.sentenceSelection.start,p=t.slice(c,f),{cleaned:$,leadingLen:L,trailingLen:_}=Bt(p),d=zt($);if(d.length===0)continue;const h=c+L,u=f-_,S={id:Fe(),answer:d,blanks:Ft(d),startIndex:h,endIndex:u};o.unshift(S);const k="_".repeat(d.length);r=r.slice(0,h)+k+r.slice(u)}return o.length===0?null:{id:Fe(),type:"hhh",originalSentence:t,sentenceWithBlanks:r,queries:o,createdAt:new Date}}function Be(){return Math.random().toString(36).substring(2,10)}function Ut(e){return Array.from(e).filter(t=>/[\p{L}\p{M}'''\-\s]/u.test(t)).join("")}function Qt(e){return e.split("").map(t=>({expected:t,actual:"",revealed:!1}))}function Xt(e,t){const n=e.slice(t.question.start,t.question.end).trim(),o=Ut(e.slice(t.answer.start,t.answer.end).trim());if(n.length===0||o.length===0)return null;const r={id:Be(),answer:o,blanks:Qt(o),startIndex:0,endIndex:o.length},s="_".repeat(o.length);return{id:Be(),type:"qa",originalSentence:n,sentenceWithBlanks:s,queries:[r],createdAt:new Date}}const Pe=new Date("2026-09-28");function je(e){return e.split("").map(t=>({expected:t,actual:"",revealed:!1}))}function H(e,t,n){return{id:e,type:"qa",originalSentence:t,sentenceWithBlanks:"_".repeat(n.length),queries:[{id:`${e}-q1`,answer:n,blanks:je(n),startIndex:0,endIndex:n.length}],createdAt:Pe}}function Yt(e,t){let n=0;for(;;){const o=e.indexOf(t,n);if(o<0)throw new Error(`Fixture error: "${t}" not found in "${e}"`);const r=e[o-1],s=e[o+t.length],i=c=>c!==void 0&&new RegExp("\\p{L}","u").test(c);if(!i(r)&&!i(s))return o;n=o+1}}function M(e,t,n){const o=n.map((s,i)=>{const c=Yt(t,s);return{id:`${e}-q${i+1}`,answer:s,blanks:je(s),startIndex:c,endIndex:c+s.length}}).sort((s,i)=>s.startIndex-i.startIndex);let r=t;for(const s of o)r=r.slice(0,s.startIndex)+"_".repeat(s.answer.length)+r.slice(s.endIndex);return{id:e,type:"hhh",originalSentence:t,sentenceWithBlanks:r,queries:o,createdAt:Pe}}H("b1-nl-qa-1","Hoe noem je de persoon die brood en taarten bakt?","de bakker"),H("b1-nl-qa-2","Wat neem je mee als het regent?","een paraplu"),H("b1-nl-qa-3","Hoe noem je het gebouw waar je boeken kunt lenen?","de bibliotheek"),H("b1-nl-qa-4","Welk seizoen komt na de zomer?","de herfst"),H("b1-nl-qa-5","Hoe noem je de dokter die zieke dieren beter maakt?","de dierenarts"),H("b1-nl-qa-6","Hoe noem je het eerste eten van de dag?","het ontbijt"),H("b1-nl-qa-7","Hoe noem je de broer van je moeder?","de oom"),H("b1-nl-qa-8","Waar wacht je op de trein?","op het station"),H("b1-nl-qa-9","Hoe noem je iemand die in een restaurant kookt?","de kok"),H("b1-nl-qa-10","Hoe noem je het geld dat je elke maand verdient?","het salaris"),M("b1-nl-pres-1","Hallo, ik heet Thomas en ik ben dertig jaar oud.",["heet","oud"]),M("b1-nl-pres-2","Ik werk als verpleegkundige in een groot ziekenhuis in Antwerpen.",["verpleegkundige","ziekenhuis"]),M("b1-nl-pres-3","In het weekend ga ik graag wandelen in het bos met mijn hond.",["wandelen","hond"]),M("b1-nl-pres-4","Mijn grootste droom is om een lange reis door Azië te maken.",["droom","reis"]),M("b1-nl-pres-5","Daarom spaar ik elke maand een beetje geld voor die reis.",["spaar","geld"]),M("b1-nl-pres-6","Elke ochtend fiets ik in twintig minuten naar mijn werk.",["twintig minuten","werk"]),M("b1-nl-pres-7","Mijn zus woont in Gent en ik bezoek haar elke zondag.",["woont","elke zondag"]),M("b1-nl-pres-8","Op vrijdag kook ik graag verse soep met groenten uit de tuin.",["verse soep","tuin"]),M("b1-nl-pres-9","Volgend jaar wil ik een cursus Japans volgen voor mijn reis.",["cursus Japans","reis"]),M("b1-nl-pres-10","Mijn hond heet Max en hij wordt volgende maand vier jaar oud.",["volgende maand","vier jaar"]),H("b1-nl-opp-1","Wat is het tegenovergestelde van 'duur'?","goedkoop"),H("b1-nl-opp-2","Wat is het tegenovergestelde van 'groot'?","klein"),H("b1-nl-opp-3","Wat is het tegenovergestelde van 'snel'?","langzaam"),H("b1-nl-opp-4","Wat is het tegenovergestelde van 'makkelijk'?","moeilijk"),H("b1-nl-opp-5","Wat is het tegenovergestelde van 'vol'?","leeg"),H("b1-nl-opp-6","Wat is het tegenovergestelde van 'zwaar'?","licht"),H("b1-nl-opp-7","Wat is het tegenovergestelde van 'schoon'?","vuil"),H("b1-nl-opp-8","Wat is het tegenovergestelde van 'dichtbij'?","ver weg"),H("b1-nl-opp-9","Wat is het tegenovergestelde van 'beginnen'?","stoppen"),H("b1-nl-opp-10","Wat is het tegenovergestelde van 'vroeg'?","laat"),M("b1-nl-city-1","Vanochtend nemen we de trein naar het centrum van Amsterdam.",["de trein","centrum"]),M("b1-nl-city-2","Eerst drinken we koffie met appeltaart in een klein café aan de gracht.",["koffie","gracht"]),M("b1-nl-city-3","Daarna huren we fietsen om door het Vondelpark te rijden.",["huren","fietsen"]),M("b1-nl-city-4","In het museum bekijken we de beroemde schilderijen van Van Gogh.",["museum","beroemde schilderijen"]),M("b1-nl-city-5","Voor de lunch eten we een broodje haring bij een kraampje op de markt.",["broodje haring","markt"]),M("b1-nl-city-6","In de middag maken we een rondvaart door de oude grachten van de stad.",["rondvaart","oude grachten"]),M("b1-nl-city-7","We kopen souvenirs en verse kaas in een gezellige winkel.",["souvenirs","verse kaas"]),M("b1-nl-city-8","Het begint zacht te regenen, dus we schuilen onder een grote paraplu.",["regenen","grote paraplu"]),M("b1-nl-city-9","Voor het diner bestellen we pannenkoeken met stroop en poedersuiker.",["bestellen","pannenkoeken"]),M("b1-nl-city-10","Moe maar gelukkig nemen we de laatste trein terug naar huis.",["laatste trein","huis"]),H("b1-en-qa-1","What do you call the person who flies a plane?","a pilot"),H("b1-en-qa-2","What do you use to open a locked door?","a key"),H("b1-en-qa-3","What do you call the meal you eat in the morning?","breakfast"),H("b1-en-qa-4","Which season comes after winter?","spring"),H("b1-en-qa-5","What do you call the place where you watch films on a big screen?","the cinema"),H("b1-en-qa-6","What do you call the room where you cook your meals?","the kitchen"),H("b1-en-qa-7","What do you call your mother's brother?","your uncle"),H("b1-en-qa-8","Where do you wait for a train?","at the station"),H("b1-en-qa-9","What do you call a person who cooks in a restaurant?","a chef"),H("b1-en-qa-10","What do you call the money you earn every month?","a salary"),M("b1-en-pres-1","Hi, my name is Sarah and I am twenty-eight years old.",["name","old"]),M("b1-en-pres-2","I work as an engineer at a small software company in Manchester.",["engineer","company"]),M("b1-en-pres-3","Every morning I take the train to work and read a book on the way.",["train","book"]),M("b1-en-pres-4","My biggest dream is to open my own restaurant one day.",["dream","restaurant"]),M("b1-en-pres-5","That is why I save money every month and take cooking classes in the evening.",["save","cooking"]),M("b1-en-pres-6","Every evening I cook a new recipe from an old Italian cookbook.",["new recipe","cookbook"]),M("b1-en-pres-7","My brother lives in Leeds and I visit him every weekend.",["lives","every weekend"]),M("b1-en-pres-8","Next year I want to take a business course to learn about restaurants.",["business course","learn"]),M("b1-en-pres-9","My favourite dish is a simple pasta with fresh tomatoes and basil.",["favourite dish","fresh tomatoes"]),M("b1-en-pres-10","With a bit of luck I will open the doors of my restaurant in five years.",["doors","five years"]),H("b1-en-opp-1","What is the opposite of 'expensive'?","cheap"),H("b1-en-opp-2","What is the opposite of 'big'?","small"),H("b1-en-opp-3","What is the opposite of 'fast'?","slow"),H("b1-en-opp-4","What is the opposite of 'easy'?","difficult"),H("b1-en-opp-5","What is the opposite of 'full'?","empty"),H("b1-en-opp-6","What is the opposite of 'heavy'?","light"),H("b1-en-opp-7","What is the opposite of 'clean'?","dirty"),H("b1-en-opp-8","What is the opposite of 'near'?","far away"),H("b1-en-opp-9","What is the opposite of 'to begin'?","to stop"),H("b1-en-opp-10","What is the opposite of 'early'?","late"),M("b1-en-city-1","This morning we take the red bus to the centre of London.",["red bus","centre"]),M("b1-en-city-2","First we drink tea with scones in a small café near the river.",["tea","river"]),M("b1-en-city-3","Then we walk through Hyde Park and feed the friendly ducks.",["walk","friendly ducks"]),M("b1-en-city-4","In the museum we look at old maps and famous paintings.",["museum","famous paintings"]),M("b1-en-city-5","For lunch we eat fish and chips at a busy market.",["lunch","busy market"]),M("b1-en-city-6","In the afternoon we take a boat trip on the River Thames.",["afternoon","boat trip"]),M("b1-en-city-7","We buy postcards and small gifts for our friends at home.",["postcards","small gifts"]),M("b1-en-city-8","It starts to rain softly, so we hide under a large umbrella.",["rain","large umbrella"]),M("b1-en-city-9","For dinner we order hot soup and fresh bread in a warm pub.",["order","hot soup"]),M("b1-en-city-10","Tired but happy, we take the last train back to our hotel.",["last train","hotel"]);let le=Me;function Ue(e){Number.isFinite(e)&&(le=Math.min(Math.max(Math.round(e),10),200))}function Qe(e){var f,p,$,L;ee(),(f=document.getElementById("tt-cue-overlay"))==null||f.remove();const t=document.createElement("div");t.id="tt-cue-overlay",t.className="tt-save-overlay",t.innerHTML=`<div class="tt-save-card tt-cue-card">
    <div class="tt-brand-row">
      ${pe(34)}
      <div>
        <h3 class="tt-brand-title" style="color:#FFFFFF !important"><span style="color:#0FFFB9 !important">✎</span> My cue — this ${e.scope}</h3>
        <p class="tt-brand-kicker" style="color:#B6A6EB !important">A hint in your own words, offered during play</p>
      </div>
    </div>
    <div class="tt-cue-context">“${Vt(e.context)}”</div>
    <input class="tt-cue-input" id="tt-cue-input" placeholder="e.g. where you sit" maxlength="${le}" />
    <div class="tt-cue-meta" id="tt-cue-meta"></div>
    <div class="tt-cue-actions">
      ${e.initial?'<span class="tt-cue-remove" id="tt-cue-remove">🗑 Remove</span>':""}
      <span class="tt-save-cancel" style="margin:0" id="tt-cue-cancel">Cancel</span>
      <button class="tt-save-create-btn" id="tt-cue-save">✓ Save cue</button>
    </div>
  </div>`,document.body.appendChild(t);const n=t.querySelector("#tt-cue-input"),o=t.querySelector("#tt-cue-meta");n.value=e.initial,setTimeout(()=>n.focus(),50);const r=()=>n.value.trim().length>le,s=(_=!1)=>{o.textContent=_?`Keep it a nudge — max ${le} characters`:`${n.value.length}/${le}`,o.classList.toggle("tt-cue-meta--over",_||r())};n.addEventListener("input",()=>s()),s();const i=()=>t.remove(),c=()=>{if(r()){s(!0),n.focus();return}const _=n.value.trim();_?e.onSave(_):e.initial&&e.onRemove(),i()};(p=t.querySelector("#tt-cue-save"))==null||p.addEventListener("click",c),n.addEventListener("keydown",_=>{_.key==="Enter"&&c(),_.key==="Escape"&&i(),_.stopPropagation()}),($=t.querySelector("#tt-cue-cancel"))==null||$.addEventListener("click",i),(L=t.querySelector("#tt-cue-remove"))==null||L.addEventListener("click",()=>{e.onRemove(),i()}),t.addEventListener("click",_=>{_.target===t&&i()})}function Vt(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}let Gt=1;function G(){const e=window.getSelection();e&&(window.__tiptongClearing=!0,e.removeAllRanges(),window.__tiptongClearing=!1)}function Ee(e,t,n){const o=[];if(e.startContainer===e.endContainer&&e.startContainer.nodeType===Node.TEXT_NODE){const f=document.createElement("span");return f.className=t,f.dataset.ttId=n,e.surroundContents(f),o.push(f),o}const r=[],s=document.createTreeWalker(e.commonAncestorContainer,NodeFilter.SHOW_TEXT);let i,c=!1;for(;i=s.nextNode();)if(i===e.startContainer)c=!0,r.push({node:i,start:e.startOffset,end:i.textContent.length});else if(i===e.endContainer){r.push({node:i,start:0,end:e.endOffset});break}else c&&r.push({node:i,start:0,end:i.textContent.length});for(let f=r.length-1;f>=0;f--){const{node:p,start:$,end:L}=r[f];if($===L)continue;const _=document.createRange();_.setStart(p,$),_.setEnd(p,L);const d=document.createElement("span");d.className=t,d.dataset.ttId=n,_.surroundContents(d),o.push(d)}return o.reverse(),o}function Kt(e){const t=document.caretRangeFromPoint(e.clientX,e.clientY);if(!t||t.startContainer.nodeType!==Node.TEXT_NODE)return null;const n=t.startContainer,o=n.textContent||"",r=t.startOffset;if(r>=o.length||o[r]===" "||o[r]===`
`)return null;let s=r;for(;s>0&&o[s-1]!==" "&&o[s-1]!==`
`;)s--;let i=r;for(;i<o.length&&o[i]!==" "&&o[i]!==`
`;)i++;const c=document.createRange();return c.setStart(n,s),c.setEnd(n,i),c}function Jt(e,t,n){if(n!=="qa")return;const o=document.createElement("span");o.className=`tt-badge ${t==="answer"?"tt-badge--a":"tt-badge--q"}`,o.setAttribute("data-tt-badge",""),o.textContent=t==="answer"?"A":"Q",e.insertBefore(o,e.firstChild)}function Zt(e){return Array.from(e).filter(t=>/[\p{L}\p{M}'''\-\s]/u.test(t)).join("")}function ce(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function Ce(e){let t="";for(const n of e.childNodes)if(n.nodeType===Node.TEXT_NODE)t+=n.textContent;else if(n.nodeType===Node.ELEMENT_NODE){const o=n;if(o.dataset.ttHandle||o.hasAttribute("data-tt-badge"))continue;t+=Ce(o)}return t}function en(e){if(e.startContainer.nodeType===Node.TEXT_NODE){const t=e.startContainer.textContent||"";let n=e.startOffset;for(;n>0&&t[n-1]!==" "&&t[n-1]!==`
`;)n--;e.setStart(e.startContainer,n)}if(e.endContainer.nodeType===Node.TEXT_NODE){const t=e.endContainer.textContent||"";let n=e.endOffset;for(;n<t.length&&t[n]!==" "&&t[n]!==`
`;)n++;e.setEnd(e.endContainer,n)}}function tn(){ee();const e={mode:"hhh",highlights:[],deleteMode:!1};let t=[];function n(d){var u,S,k,b;let h=d.nodeType===Node.TEXT_NODE?d.parentElement:d;for(;h;){if((u=h.dataset)!=null&&u.ttId)return e.highlights.find(y=>y.id===h.dataset.ttId)??null;if((S=h.classList)!=null&&S.contains("tt-underline")&&((b=(k=h.parentElement)==null?void 0:k.dataset)!=null&&b.ttId))return e.highlights.find(y=>y.id===h.parentElement.dataset.ttId)??null;h=h.parentElement}return null}function o(){if(e.deleteMode){const x=window.getSelection();if(x&&!x.isCollapsed&&x.toString().trim().length>0){e.deleteMode=!1;for(const w of e.highlights)for(const m of w.spans)m.classList.remove("tt-highlight--delete")}else return}const d=window.getSelection();if(!d||d.isCollapsed||!d.rangeCount||!d.toString().trim())return;const u=d.getRangeAt(0),S=document.getElementById("tt-toolbar"),k=document.getElementById("tt-popup");if(S!=null&&S.contains(u.startContainer)){G();return}if(k!=null&&k.contains(u.startContainer)){G();return}en(u);const b=u.toString().trim();if(!b){G();return}const y=n(u.startContainer),T=n(u.endContainer);if(y&&y===T){if(e.mode==="hhh"&&y.role==="sentence"){G();return}G();return}const R=y||T;if(R){c(R,u),G();return}if(e.mode==="hhh"&&b.split(/\s+/).filter(Boolean).length<2){G();return}const O=e.highlights.filter(x=>x.role!=="sentence").length,q=e.mode==="qa"?O%2===0?"question":"answer":"sentence",l=`tt-${Gt++}`,g=Ee(u,q==="answer"?"tt-highlight tt-highlight--answer":"tt-highlight",l);if(g.length>0){Jt(g[0],q,e.mode);const x={id:l,text:b,role:q,spans:g,underlinedWords:[]};e.highlights.push(x),g.forEach(w=>L(w,x))}G()}function r(d,h){const u=d.underlinedWords[h];if(!u)return;const S=u.span.parentNode;if(S){for(;u.span.firstChild;)S.insertBefore(u.span.firstChild,u.span);S.removeChild(u.span),S.normalize()}d.underlinedWords.splice(h,1)}function s(d,h){var b,y;const u=Kt(h);if(!u)return;const S=u.toString().trim();if(!S)return;const k=d.underlinedWords.findIndex(T=>T.span.contains(u.startContainer)||T.text===S);if(k>=0)r(d,k);else{const T=h.target;if((b=T.classList)!=null&&b.contains("tt-underline")||(y=T.closest)!=null&&y.call(T,".tt-underline")){const l=T.classList.contains("tt-underline")?T:T.closest(".tt-underline"),v=d.underlinedWords.findIndex(g=>g.span===l);if(v>=0){r(d,v);return}}const R=d.text.split(/\s+/).filter(Boolean).length,O=Math.floor(R/2);if(d.underlinedWords.length>=O)return;const q=document.createElement("span");q.className="tt-underline";try{u.surroundContents(q),d.underlinedWords.push({text:S,span:q})}catch{}}}function i(d){const h=e.highlights.find(S=>S.id===d);if(!h)return;const u=new Set([d]);if(h.role==="question"||h.role==="answer"){const S=e.highlights.filter(T=>T.role!=="sentence"),k=S.findIndex(T=>T.id===d),y=k%2===0?k+1:k-1;y>=0&&y<S.length&&u.add(S[y].id)}for(const S of u){const k=e.highlights.find(b=>b.id===S);if(k){for(const b of k.underlinedWords){const y=b.span.parentNode;if(y){for(;b.span.firstChild;)y.insertBefore(b.span.firstChild,b.span);y.removeChild(b.span)}}for(const b of k.spans)b.querySelectorAll("[data-tt-badge]").forEach(y=>y.remove());for(const b of k.spans){const y=b.parentNode;if(y){for(;b.firstChild;)y.insertBefore(b.firstChild,b);y.removeChild(b),y.normalize()}}}}e.highlights=e.highlights.filter(S=>!u.has(S.id)),e.highlights.length===0&&(e.deleteMode=!1)}function c(d,h){try{const u=n(h.startContainer)===d,S=n(h.endContainer)===d;if(!u){const k=d.spans[0],b=document.createRange();if(b.setStart(h.startContainer,h.startOffset),b.setEndBefore(k),b.toString().length>0)try{const y=Ee(b,k.className,d.id);d.spans.unshift(...y);const T=k.querySelector("[data-tt-badge]");T&&y[0]&&y[0].insertBefore(T,y[0].firstChild),y.forEach(R=>L(R,d))}catch{}}if(!S){const k=d.spans[d.spans.length-1],b=document.createRange();if(b.setStartAfter(k),b.setEnd(h.endContainer,h.endOffset),b.toString().length>0)try{const y=Ee(b,k.className,d.id);d.spans.push(...y),y.forEach(T=>L(T,d))}catch{}}for(d.text=d.spans.map(k=>Ce(k)).join("");d.underlinedWords.length>0;)r(d,0)}catch{}}let f=0;function p(d,h){d.classList.toggle("tt-has-cue",!!h),h?d.title=`My cue: ${h}`:d.removeAttribute("title")}function $(d,h){d.addEventListener("pointerdown",u=>{var O,q;if(e.deleteMode)return;const S=u.clientX,k=u.clientY,b=(q=(O=u.target).closest)==null?void 0:q.call(O,".tt-underline");let y=setTimeout(()=>{y=null,f=Date.now()+600,G();const l=b?h.underlinedWords.find(v=>v.span===b):void 0;Qe({context:l?l.text:h.text,scope:l?"word":"exercise",initial:(l?l.cue:h.cue)??"",onSave:v=>{l?(l.cue=v,p(l.span,v)):(h.cue=v,p(h.spans[0],v))},onRemove:()=>{l?(l.cue=void 0,p(l.span,void 0)):(h.cue=void 0,p(h.spans[0],void 0))}})},500);const T=()=>{y&&(clearTimeout(y),y=null),document.removeEventListener("pointermove",R),document.removeEventListener("pointerup",T)},R=l=>{Math.hypot(l.clientX-S,l.clientY-k)>8&&T()};document.addEventListener("pointermove",R),document.addEventListener("pointerup",T)})}function L(d,h){$(d,h),d.addEventListener("click",u=>{var k,b,y,T;if(Date.now()<f){u.preventDefault(),u.stopPropagation();return}if(((b=(k=u.target).closest)==null?void 0:b.call(k,"a"))&&(u.preventDefault(),u.stopPropagation()),e.deleteMode){u.preventDefault(),u.stopPropagation();const R=(T=(y=u.target).closest)==null?void 0:T.call(y,".tt-underline");if(R&&h.role==="sentence"){const O=h.underlinedWords.findIndex(q=>q.span===R);if(O>=0){r(h,O);return}}i(h.id);return}if(e.mode==="hhh"&&!e.deleteMode){const R=window.getSelection();if(R&&!R.isCollapsed)return;u.preventDefault(),u.stopPropagation(),s(h,u)}})}const _=()=>setTimeout(o,10);return document.addEventListener("mouseup",_,!0),{getSelections:()=>e.highlights.map(d=>({id:d.id,text:d.text,role:d.role,underlinedCount:d.underlinedWords.length})),validate:()=>{const d=[];return e.highlights.filter(u=>u.role!=="sentence").length%2!==0&&d.push("Last question needs an answer"),d},getMode:()=>e.mode,setMode:d=>{if(e.mode=d,e.deleteMode){e.deleteMode=!1;for(const h of e.highlights)for(const u of h.spans)u.classList.remove("tt-highlight--delete")}},toggleDeleteMode:()=>{e.deleteMode=!e.deleteMode;for(const d of e.highlights)for(const h of d.spans)h.classList.toggle("tt-highlight--delete",e.deleteMode);return e.deleteMode},isDeleteMode:()=>e.deleteMode,getQAPairs:()=>{const d=e.highlights.filter(u=>u.role!=="sentence"),h=[];for(let u=0;u+1<d.length;u+=2)h.push({question:d[u].text,answer:d[u+1].text});return h},getHHHData:()=>e.highlights.filter(h=>h.role==="sentence").map(h=>{const u=h.text,S=h.underlinedWords.map(k=>{const b=u.indexOf(k.text);return b>=0?{start:b,end:b+k.text.length}:null}).filter(k=>k!==null);return{sourceText:u,sentenceStart:0,sentenceEnd:u.length,underlinedWords:S}}),getOrderedExerciseData:()=>{const d=[];t=[];const h=[...e.highlights].sort((k,b)=>{const y=k.spans[0],T=b.spans[0];if(!y||!T)return 0;const R=y.compareDocumentPosition(T);return R&Node.DOCUMENT_POSITION_FOLLOWING?-1:R&Node.DOCUMENT_POSITION_PRECEDING?1:0}),u=h.filter(k=>k.role!=="sentence"),S=new Set;for(const k of h)if(k.role==="question"){const b=u.indexOf(k),y=Math.floor(b/2);if(S.has(y))continue;const T=u[b+1];T&&(S.add(y),d.push({type:"qa",question:k.text,answer:T.text,cue:k.cue??T.cue}),t.push(T.id))}else{if(k.role==="answer")continue;{const b=k.text;let y=k.underlinedWords.map(T=>{const R=b.indexOf(T.text);return R>=0?{start:R,end:R+T.text.length,cue:T.cue}:null}).filter(T=>T!==null);y.length===0&&k.randomPick&&(y=[{start:k.randomPick.start,end:k.randomPick.end}]),d.push({type:"hhh",sourceText:b,sentenceStart:0,sentenceEnd:b.length,underlinedWords:y,cue:k.cue}),t.push(k.id)}}return d},hideAnswers:()=>{for(const d of e.highlights)if(d.role==="answer")for(const h of d.spans){h.dataset.ttOriginal=h.innerHTML;const u="•".repeat(Math.min(d.text.length,12));h.innerHTML=`<span style="letter-spacing:2px;color:${a.violet};font-weight:bold">${u}</span>`}},hideUnderlinedWords:()=>{for(const d of e.highlights)if(d.role==="sentence")if(d.underlinedWords.length>0)for(const h of d.underlinedWords){h.span.dataset.ttOriginal=h.span.innerHTML;const u="•".repeat(Math.min(h.text.length,8));h.span.innerHTML=`<span style="letter-spacing:2px;color:${a.violet};font-weight:bold">${u}</span>`}else{const h=[];for(const u of d.spans){const S=Ce(u),k=/[\p{L}\p{M}'']+/gu;let b;for(;(b=k.exec(S))!==null;)h.push({span:u,text:S,localStart:b.index,localEnd:b.index+b[0].length,word:b[0]})}if(h.length>0){const u=h[Math.floor(Math.random()*h.length)],k=d.text.indexOf(u.word);d.randomPick={text:u.word,start:k>=0?k:0,end:k>=0?k+u.word.length:u.word.length},u.span.dataset.ttOriginal=u.span.innerHTML,u.span.dataset.ttRandomStart=String(u.localStart),u.span.dataset.ttRandomEnd=String(u.localEnd);const b=ce(u.text.slice(0,u.localStart)),y="•".repeat(Math.min(u.word.length,8)),T=ce(u.text.slice(u.localEnd));u.span.innerHTML=`${b}<span style="letter-spacing:2px;color:${a.violet};font-weight:bold">${y}</span>${T}`}}},revealWord:(d,h)=>{var k;const u=h!=null?t[h]:void 0,S=u?e.highlights.filter(b=>b.id===u):e.highlights;for(const b of S){for(const y of b.underlinedWords)if((y.text.replace(/^[.,;:!?'"()\-–—\s]+|[.,;:!?'"()\-–—\s]+$/g,"")===d||y.text===d)&&y.span.dataset.ttOriginal){y.span.innerHTML=`<span style="color:${a.greenInk};font-weight:bold">${y.span.dataset.ttOriginal}</span>`;return}if(b.role==="sentence"&&((k=b.randomPick)==null?void 0:k.text)===d){for(const y of b.spans)if(y.dataset.ttOriginal&&y.dataset.ttRandomStart){const T=parseInt(y.dataset.ttRandomStart,10),R=parseInt(y.dataset.ttRandomEnd,10),O=document.createElement("span");O.innerHTML=y.dataset.ttOriginal;const q=O.textContent||"",l=ce(q.slice(0,T)),v=ce(q.slice(T,R)),g=ce(q.slice(R));y.innerHTML=`${l}<span style="color:${a.greenInk};font-weight:bold">${v}</span>${g}`;return}}if(b.role==="answer"&&Zt(b.text)===d){for(const y of b.spans)y.dataset.ttOriginal&&(y.innerHTML=`<span style="color:${a.greenInk};font-weight:bold">${y.dataset.ttOriginal}</span>`);return}}},showAnswers:()=>{for(const d of e.highlights){for(const h of d.underlinedWords)h.span.dataset.ttOriginal&&(h.span.innerHTML=h.span.dataset.ttOriginal,delete h.span.dataset.ttOriginal);for(const h of d.spans)h.dataset.ttOriginal&&(h.innerHTML=h.dataset.ttOriginal,delete h.dataset.ttOriginal,delete h.dataset.ttRandomStart,delete h.dataset.ttRandomEnd);delete d.randomPick}},destroy:()=>{for(const d of[...e.highlights])i(d.id);e.highlights=[],document.removeEventListener("mouseup",_,!0)}}}let nn=1;function on(e){return Array.from(e).filter(t=>/[\p{L}\p{M}'''\-\s]/u.test(t)).join("")}function V(){const e=window.getSelection();e&&(window.__tiptongClearing=!0,e.removeAllRanges(),window.__tiptongClearing=!1)}function D(e){try{return e.startContainer.isConnected&&e.endContainer.isConnected}catch{return!1}}function rn(e){let t=e.nodeType===Node.ELEMENT_NODE?e:e.parentElement;for(;t;){if(t.id||t.hasAttribute("data-page")||t.hasAttribute("data-chapter")||t.tagName==="ARTICLE"||t.tagName==="MAIN"||t.tagName==="SECTION")return t;t=t.parentElement}return document.body}function sn(e){if(e===document.body)return"body";if(e.id)return`#${CSS.escape(e.id)}`;const t=[];let n=e;for(;n&&n!==document.body;){if(n.id){t.unshift(`#${CSS.escape(n.id)}`);break}const o=n.parentElement;if(!o)break;const r=Array.from(o.children).indexOf(n);t.unshift(`${n.tagName.toLowerCase()}:nth-child(${r+1})`),n=o}return t.join(" > ")||"body"}function Xe(e,t,n){const o=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);let r=0,s;for(;s=o.nextNode();){if(s===t)return r+n;r+=(s.textContent||"").length}return r+n}function be(e){const t=rn(e.commonAncestorContainer);return{ancestorSelector:sn(t),charStart:Xe(t,e.startContainer,e.startOffset),charEnd:Xe(t,e.endContainer,e.endOffset),text:e.toString()}}function ve(e){const t=document.querySelector(e.ancestorSelector);if(!t)return null;const n=document.createTreeWalker(t,NodeFilter.SHOW_TEXT);let o=0,r=null,s=0,i=null,c=0,f;for(;f=n.nextNode();){const p=(f.textContent||"").length;if(!r&&o+p>e.charStart&&(r=f,s=e.charStart-o),!i&&o+p>=e.charEnd){i=f,c=e.charEnd-o;break}o+=p}if(!r||!i)return null;try{const p=document.createRange();return p.setStart(r,s),p.setEnd(i,c),e.text&&p.toString()!==e.text?(console.warn("[TipTong] Re-anchored range text mismatch, skipping"),null):p}catch{return null}}function an(e){const t=document.caretRangeFromPoint(e.clientX,e.clientY);if(!t||t.startContainer.nodeType!==Node.TEXT_NODE)return null;const n=t.startContainer,o=n.textContent||"",r=t.startOffset;if(r>=o.length||o[r]===" "||o[r]===`
`)return null;let s=r;for(;s>0&&o[s-1]!==" "&&o[s-1]!==`
`;)s--;let i=r;for(;i<o.length&&o[i]!==" "&&o[i]!==`
`;)i++;const c=document.createRange();return c.setStart(n,s),c.setEnd(n,i),c}function ln(e){if(e.startContainer.nodeType===Node.TEXT_NODE){const t=e.startContainer.textContent||"";let n=e.startOffset;for(;n>0&&t[n-1]!==" "&&t[n-1]!==`
`;)n--;e.setStart(e.startContainer,n)}if(e.endContainer.nodeType===Node.TEXT_NODE){const t=e.endContainer.textContent||"";let n=e.endOffset;for(;n<t.length&&t[n]!==" "&&t[n]!==`
`;)n++;e.setEnd(e.endContainer,n)}}function Ye(e,t,n){try{const o=document.createRange();return o.setStart(e,t),o.collapse(!0),n.compareBoundaryPoints(Range.START_TO_START,o)<=0&&n.compareBoundaryPoints(Range.END_TO_END,o)>=0}catch{return!1}}function Ve(e,t){try{return e.compareBoundaryPoints(Range.START_TO_END,t)>0&&e.compareBoundaryPoints(Range.END_TO_START,t)<0}catch{return!1}}function Te(e,t){try{return e.compareBoundaryPoints(Range.START_TO_START,t)}catch{return 0}}const _e="tt-css-overlay",Ge=4;function cn(e){if(e.length===0)return[];const t=Array.from(e).sort((r,s)=>r.top-s.top||r.left-s.left),n=[];let o=t[0];for(let r=1;r<t.length;r++){const s=t[r];if(Math.abs(s.top-o.top)<2){const i=Math.min(o.left,s.left),c=Math.max(o.right,s.right),f=Math.min(o.top,s.top),p=Math.max(o.bottom,s.bottom);o=new DOMRect(i,f,c-i,p-f)}else n.push(o),o=s}return n.push(o),n}let Ke=!1;function Je(){if(Ke)return;Ke=!0;let e=0;const t=()=>{e||(e=requestAnimationFrame(()=>{e=0,document.querySelectorAll(`.${_e}, .${xe}`).forEach(n=>{var o;(o=n.__ttRelayout)==null||o.call(n)})}))};document.addEventListener("scroll",t,!0),window.addEventListener("resize",t)}function Ze(e,t,n){const o=document.createElement("div");o.className=_e,o.style.cssText="position: absolute; top: 0; left: 0; pointer-events: none; z-index: 999;";const r=()=>{o.textContent="";const s=e.getClientRects();let i;if(s.length>0)i=cn(s);else{const p=e.getBoundingClientRect();i=p.width===0&&p.height===0?[]:[p]}if(i.length===0){o.style.display="none";return}o.style.display="";const c=window.scrollX,f=window.scrollY;for(let p=0;p<i.length;p++){const $=i[p];let L="8px";i.length>1&&(L=p===0?"8px 8px 0 0":p===i.length-1?"0 0 8px 8px":"0");const _=document.createElement("div");_.style.cssText=`
        position: absolute;
        top: ${$.top+f}px;
        left: ${$.left+c-Ge}px;
        width: ${$.width+Ge*2}px;
        height: ${$.height}px;
        ${n}
        border-radius: ${L};
        display: flex;
        align-items: center;
        justify-content: center;
        pointer-events: none;
      `,p===0&&(_.textContent=t),o.appendChild(_)}};return r(),o.__ttRelayout=r,Je(),document.body.appendChild(o),o}function dn(){document.querySelectorAll(`.${_e}`).forEach(e=>e.remove())}const xe="tt-css-badge";function et(){document.querySelectorAll(`.${xe}`).forEach(e=>e.remove())}function Le(e){if(et(),e.deleteMode)return;const t=e.highlights.filter(o=>o.role==="question"||o.role==="answer");for(const o of t){const r=o.ranges[0];if(!r||!D(r))continue;const s=r.getClientRects(),i=s.length>0?s[0]:r.getBoundingClientRect();if(i.width===0&&i.height===0)continue;const c=document.createElement("div");c.className=xe;const f=o.role==="answer";c.textContent=f?"A":"Q",c.style.cssText=`
      position: absolute;
      top: ${i.top+window.scrollY-8}px;
      left: ${i.left+window.scrollX-8}px;
      width: 18px;
      height: 18px;
      background: ${f?a.green:a.violet};
      color: ${f?a.dark:"white"};
      font-size: ${E.small};
      font-weight: bold;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      pointer-events: none;
      z-index: 1000;
      line-height: 1;
    `,c.__ttRelayout=()=>{const p=r.getClientRects(),$=p.length>0?p[0]:r.getBoundingClientRect();c.style.display=$.width===0&&$.height===0?"none":"flex",c.style.top=`${$.top+window.scrollY-8}px`,c.style.left=`${$.left+window.scrollX-8}px`},document.body.appendChild(c)}const n=[];for(const o of e.highlights){o.cue&&o.ranges[0]&&n.push({range:o.ranges[0],cue:o.cue});for(const r of o.underlinedWords)r.cue&&n.push({range:r.range,cue:r.cue})}for(const o of n){if(!D(o.range))continue;const r=document.createElement("div");r.className=xe,r.textContent="✎",r.title=`My cue: ${o.cue}`,r.style.cssText=`
      position: absolute;
      width: 16px;
      height: 16px;
      background: ${a.violet};
      color: white;
      font-size: 10px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      pointer-events: none;
      z-index: 1000;
      line-height: 1;
    `;const s=()=>{const i=o.range.getClientRects(),c=i.length>0?i[0]:o.range.getBoundingClientRect();r.style.display=c.width===0&&c.height===0?"none":"flex",r.style.top=`${c.top+window.scrollY-8}px`,r.style.left=`${c.right+window.scrollX-6}px`};s(),r.__ttRelayout=s,document.body.appendChild(r)}Je()}function K(e){if(typeof CSS>"u"||!("highlights"in CSS))return;const t=CSS.highlights,n=[],o=[],r=[],s=[],i=[];for(const c of e.highlights){const f=e.deleteMode?i:c.role==="answer"?o:c.role==="question"?n:r;for(const p of c.ranges)D(p)&&f.push(p);for(const p of c.underlinedWords)!e.deleteMode&&D(p.range)&&s.push(p.range)}t.delete("tt-question"),t.delete("tt-answer"),t.delete("tt-sentence"),t.delete("tt-underline"),t.delete("tt-delete");try{n.length>0&&t.set("tt-question",new window.Highlight(...n)),o.length>0&&t.set("tt-answer",new window.Highlight(...o)),r.length>0&&t.set("tt-sentence",new window.Highlight(...r)),s.length>0&&t.set("tt-underline",new window.Highlight(...s)),i.length>0&&t.set("tt-delete",new window.Highlight(...i))}catch(c){console.warn("[TipTong] CSS Highlight API error:",c)}Le(e)}function un(){ee(),xt();const e={mode:"hhh",highlights:[],deleteMode:!1},t=[];let n=[],o=null;function r(){let l=!1;for(const v of e.highlights){for(let g=0;g<v.ranges.length;g++)if(!D(v.ranges[g])&&v.anchors[g]){const x=ve(v.anchors[g]);x&&(v.ranges[g]=x,l=!0)}for(let g=0;g<v.underlinedWords.length;g++){const x=v.underlinedWords[g];if(!D(x.range)&&x.anchor){const w=ve(x.anchor);w&&(x.range=w,l=!0)}}}l&&K(e)}function s(){o&&clearTimeout(o),o=setTimeout(r,100)}const i=new MutationObserver(l=>{if(e.highlights.length===0)return;l.some(g=>g.type==="childList"&&(g.addedNodes.length>0||g.removedNodes.length>0))&&s()});i.observe(document.body,{childList:!0,subtree:!0});let c=null;document.addEventListener("mouseup",()=>{const l=window.getSelection();l&&!l.isCollapsed&&l.rangeCount>0?(c=l.getRangeAt(0).cloneRange(),V()):c=null},!0);function f(l,v){for(const g of e.highlights){for(const x of g.ranges)if(Ye(l,v,x))return g;for(const x of g.underlinedWords)if(Ye(l,v,x.range))return g}return null}function p(l){for(const v of e.highlights)for(const g of v.ranges)if(Ve(l,g))return v;return null}function $(){const l=c;if(c=null,!l)return;if(e.deleteMode)if(l.toString().trim().length>0)e.deleteMode=!1,K(e);else return;if(!l.toString().trim())return;const g=document.getElementById("tt-toolbar"),x=document.getElementById("tt-popup");if(g!=null&&g.contains(l.startContainer)){V();return}if(x!=null&&x.contains(l.startContainer)){V();return}ln(l);const w=l.toString().trim();if(!w){V();return}const m=f(l.startContainer,l.startOffset),C=f(l.endContainer,l.endOffset);if(m&&m===C){if(e.mode==="hhh"&&m.role==="sentence"){V();return}V();return}const A=m||C||p(l);if(A){L(A,l),V(),K(e);return}if(e.mode==="hhh"&&w.split(/\s+/).filter(Boolean).length<2){V();return}const I=e.highlights.filter(ue=>ue.role!=="sentence").length,U=e.mode==="qa"?I%2===0?"question":"answer":"sentence",Z=`tt-css-${nn++}`,oe=be(l),F={id:Z,text:w,role:U,ranges:[l],anchors:[oe],underlinedWords:[]};e.highlights.push(F),V(),K(e)}function L(l,v){try{const g=[...l.ranges,v];let x=g[0],w=g[0];for(const C of g)C.compareBoundaryPoints(Range.START_TO_START,x)<0&&(x=C),C.compareBoundaryPoints(Range.END_TO_END,w)>0&&(w=C);const m=document.createRange();m.setStart(x.startContainer,x.startOffset),m.setEnd(w.endContainer,w.endOffset),l.ranges=[m],l.anchors=[be(m)],l.text=m.toString().trim(),l.underlinedWords=[]}catch{}}function _(l,v){const g=an(v);if(!g)return;const x=g.toString().trim();if(!x)return;const w=l.underlinedWords.findIndex(m=>{try{return Ve(m.range,g)||m.text===x}catch{return m.text===x}});if(w>=0)l.underlinedWords.splice(w,1);else{const m=l.text.split(/\s+/).filter(Boolean).length,C=Math.floor(m/2);if(l.underlinedWords.length>=C)return;const A=g.cloneRange();l.underlinedWords.push({text:x,range:A,anchor:be(A)})}K(e)}function d(l){const v=e.highlights.find(x=>x.id===l);if(!v)return;const g=new Set([l]);if(v.role==="question"||v.role==="answer"){const x=e.highlights.filter(A=>A.role!=="sentence"),w=x.findIndex(A=>A.id===l),C=w%2===0?w+1:w-1;C>=0&&C<x.length&&g.add(x[C].id)}e.highlights=e.highlights.filter(x=>!g.has(x.id)),e.highlights.length===0&&(e.deleteMode=!1),K(e)}let h=0;function u(l){var oe;if(e.deleteMode)return;const v=document.getElementById("tt-toolbar"),g=document.getElementById("tt-popup");if(v!=null&&v.contains(l.target)||g!=null&&g.contains(l.target)||(oe=document.getElementById("tt-cue-overlay"))!=null&&oe.contains(l.target))return;const x=document.caretRangeFromPoint(l.clientX,l.clientY);if(!x)return;const w=f(x.startContainer,x.startOffset);if(!w)return;const m=w.underlinedWords.find(F=>{try{return D(F.range)&&F.range.comparePoint(x.startContainer,x.startOffset)===0}catch{return!1}}),C=l.clientX,A=l.clientY;let I=setTimeout(()=>{I=null,h=Date.now()+600,V(),Qe({context:m?m.text:w.text,scope:m?"word":"exercise",initial:(m?m.cue:w.cue)??"",onSave:F=>{m?m.cue=F:w.cue=F,Le(e)},onRemove:()=>{m?m.cue=void 0:w.cue=void 0,Le(e)}})},500);const U=()=>{I&&(clearTimeout(I),I=null),document.removeEventListener("pointermove",Z),document.removeEventListener("pointerup",U)},Z=F=>{Math.hypot(F.clientX-C,F.clientY-A)>8&&U()};document.addEventListener("pointermove",Z),document.addEventListener("pointerup",U)}function S(l){var C,A;if(Date.now()<h){l.preventDefault(),l.stopPropagation();return}const v=document.getElementById("tt-toolbar"),g=document.getElementById("tt-popup");if(v!=null&&v.contains(l.target)||g!=null&&g.contains(l.target))return;const x=document.caretRangeFromPoint(l.clientX,l.clientY);if(!x)return;const w=f(x.startContainer,x.startOffset);if(!w)return;if(e.deleteMode){if(l.preventDefault(),l.stopPropagation(),w.role==="sentence"){const I=w.underlinedWords.findIndex(U=>{try{return D(U.range)&&U.range.comparePoint(x.startContainer,x.startOffset)===0}catch{return!1}});if(I>=0){w.underlinedWords.splice(I,1),K(e);return}}d(w.id);return}if(e.mode==="hhh"&&w.role==="sentence"){const I=window.getSelection();if(I&&!I.isCollapsed)return;l.preventDefault(),l.stopPropagation(),_(w,l)}((A=(C=l.target).closest)==null?void 0:A.call(C,"a"))&&w&&(l.preventDefault(),l.stopPropagation())}const k=()=>setTimeout($,10);document.addEventListener("mouseup",k,!0),document.addEventListener("click",S,!0),document.addEventListener("pointerdown",u,!0);function b(l,v){const g="•".repeat(Math.min(v.length,12)),x=Ze(l,g,`background: white; color: ${a.violet}; font-weight: bold; letter-spacing: 2px; font-size: inherit; box-shadow: 0 1px 4px rgba(0,0,0,0.1);`);return t.push(x),x}function y(l,v){const g=Ze(l,v,`background: white; color: ${a.greenInk}; font-weight: bold; font-size: inherit; box-shadow: 0 1px 4px rgba(0,0,0,0.1);`);return t.push(g),g}function T(){for(const l of t)l.remove();t.length=0,dn()}function R(l){const v=l.ranges[0];if(!v||!D(v))return null;const g=[],x=O(v);let w=0;for(const Z of x){const oe=Z.textContent||"",F=Z===v.startContainer?v.startOffset:0,ue=Z===v.endContainer?v.endOffset:oe.length,ft=oe.slice(F,ue),Ln=/[\p{L}\p{M}'']+/gu;let ie;for(;(ie=Ln.exec(ft))!==null;)g.push({word:ie[0],node:Z,localStart:F+ie.index,localEnd:F+ie.index+ie[0].length,hlTextOffset:w+ie.index});w+=ft.length}if(g.length===0)return null;const m=g[Math.floor(Math.random()*g.length)],C=document.createRange();try{C.setStart(m.node,m.localStart),C.setEnd(m.node,m.localEnd)}catch{return null}const A=l.text.indexOf(m.word,m.hlTextOffset>0?m.hlTextOffset-1:0),I=A>=0?A:m.hlTextOffset,U=I+m.word.length;return{text:m.word,start:I,end:U,range:C}}function O(l){const v=l.commonAncestorContainer,g=[];if(v.nodeType===Node.TEXT_NODE)g.push(v);else{const x=document.createTreeWalker(v,NodeFilter.SHOW_TEXT);let w;for(;w=x.nextNode();){try{const m=document.createRange();if(m.selectNodeContents(w),l.compareBoundaryPoints(Range.START_TO_END,m)>0||l.compareBoundaryPoints(Range.END_TO_START,m)<0)continue}catch{continue}g.push(w)}}return g}function q(l,v){const g=O(l);for(const x of g){const m=(x.textContent||"").indexOf(v);if(m>=0)try{const C=document.createRange();return C.setStart(x,m),C.setEnd(x,m+v.length),C}catch{continue}}return null}return{getSelections:()=>e.highlights.map(l=>({id:l.id,text:l.text,role:l.role,underlinedCount:l.underlinedWords.length})),validate:()=>{const l=[];return e.highlights.filter(g=>g.role!=="sentence").length%2!==0&&l.push("Last question needs an answer"),l},getMode:()=>e.mode,setMode:l=>{e.mode=l,e.deleteMode&&(e.deleteMode=!1),K(e)},toggleDeleteMode:()=>(e.deleteMode=!e.deleteMode,K(e),e.deleteMode),isDeleteMode:()=>e.deleteMode,getQAPairs:()=>{const l=e.highlights.filter(g=>g.role!=="sentence"),v=[];for(let g=0;g+1<l.length;g+=2)v.push({question:l[g].text,answer:l[g+1].text});return v},getHHHData:()=>e.highlights.filter(v=>v.role==="sentence").map(v=>{const g=v.text,x=v.underlinedWords.map(w=>{const m=g.indexOf(w.text);return m>=0?{start:m,end:m+w.text.length}:null}).filter(w=>w!==null);return{sourceText:g,sentenceStart:0,sentenceEnd:g.length,underlinedWords:x}}),getOrderedExerciseData:()=>{const l=[];n=[];const v=[...e.highlights].sort((w,m)=>{const C=w.ranges[0],A=m.ranges[0];return!C||!A?0:Te(C,A)}),g=v.filter(w=>w.role!=="sentence"),x=new Set;for(const w of v)if(w.role==="question"){const m=g.indexOf(w),C=Math.floor(m/2);if(x.has(C))continue;const A=g[m+1];A&&(x.add(C),l.push({type:"qa",question:w.text,answer:A.text,cue:w.cue??A.cue}),n.push(A.id))}else{if(w.role==="answer")continue;{const m=w.text;let C=w.underlinedWords.map(A=>{const I=m.indexOf(A.text);return I>=0?{start:I,end:I+A.text.length,cue:A.cue}:null}).filter(A=>A!==null);C.length===0&&w.randomPick&&(C=[{start:w.randomPick.start,end:w.randomPick.end}]),l.push({type:"hhh",sourceText:m,sentenceStart:0,sentenceEnd:m.length,underlinedWords:C,cue:w.cue}),n.push(w.id)}}return l},hideAnswers:()=>{for(const l of e.highlights)if(l.role==="answer"){for(const v of l.ranges)if(D(v))try{b(v,l.text)}catch(g){console.warn("[TipTong] hideAnswers overlay error:",g)}}},hideUnderlinedWords:()=>{for(const l of e.highlights)if(l.role==="sentence")if(l.underlinedWords.length>0){const v=l.underlinedWords.filter(x=>D(x.range)).sort((x,w)=>Te(x.range,w.range)),g=[];for(const x of v){const w=g[g.length-1];if(w){const m=w.range.getBoundingClientRect(),C=x.range.getBoundingClientRect();if(Math.abs(m.top-C.top)<2&&C.left-m.right<m.height){const I=document.createRange();I.setStart(w.range.startContainer,w.range.startOffset),I.setEnd(x.range.endContainer,x.range.endOffset),w.range=I,w.text+=" "+x.text;continue}}g.push({range:x.range.cloneRange(),text:x.text})}for(const x of g)try{b(x.range,x.text)}catch(w){console.warn("[TipTong] hideUnderlinedWords overlay error:",w)}}else{const v=R(l);if(v){l.randomPick={text:v.text,start:v.start,end:v.end,range:v.range,anchor:be(v.range)};try{b(v.range,v.text)}catch(g){console.warn("[TipTong] hideRandom overlay error:",g)}}}},revealWord:(l,v)=>{var w;const g=v!=null?n[v]:void 0,x=g?e.highlights.filter(m=>m.id===g):e.highlights;for(const m of x){for(const C of m.underlinedWords)if(C.text.replace(/^[.,;:!?'"()\-–—\s]+|[.,;:!?'"()\-–—\s]+$/g,"")===l||C.text===l){D(C.range)&&y(C.range,C.text);return}if(m.underlinedWords.length>1&&m.role==="sentence"){const C=[...m.underlinedWords].filter(I=>D(I.range)).sort((I,U)=>Te(I.range,U.range)),A=C.map(I=>I.text.replace(/^[.,;:!?'"()\-–—\s]+|[.,;:!?'"()\-–—\s]+$/g,"")).join(" ");if(A===l||A.includes(l)){for(const I of C)D(I.range)&&y(I.range,I.text);return}}if(m.role==="sentence"&&((w=m.randomPick)==null?void 0:w.text)===l){let C=m.randomPick.range;if(C&&!D(C)&&m.randomPick.anchor&&(C=ve(m.randomPick.anchor)??void 0,C&&(m.randomPick.range=C)),C&&D(C)){y(C,l);return}const A=m.ranges[0];if(A&&D(A)){const I=q(A,l);if(I){y(I,l);return}}}if(m.role==="answer"&&on(m.text)===l){for(let C=0;C<m.ranges.length;C++){let A=m.ranges[C];if(!D(A)&&m.anchors[C]){const I=ve(m.anchors[C]);I&&(m.ranges[C]=I,A=I)}D(A)&&y(A,m.text)}return}}},showAnswers:()=>{T();for(const l of e.highlights)delete l.randomPick},destroy:()=>{if(T(),et(),i.disconnect(),o&&clearTimeout(o),e.highlights=[],e.deleteMode=!1,typeof CSS<"u"&&"highlights"in CSS){const l=CSS.highlights;l.delete("tt-question"),l.delete("tt-answer"),l.delete("tt-sentence"),l.delete("tt-underline"),l.delete("tt-delete")}document.removeEventListener("mouseup",k,!0),document.removeEventListener("click",S,!0),document.removeEventListener("pointerdown",u,!0)}}}function tt(e,t){return e.hintUsages.filter(n=>n.queryId===t&&n.type===W.SELF_AUTHORED).length}function nt(e,t,n){const o=e.hintUsages.some(r=>r.queryId===t.id&&re(r.type).autoRevealsLength);return Mt(n,t.answer,ae(t),{lengthAlreadyKnown:o,remainingCues:It(t.customCues,tt(e,t.id)).length})}function Re(e,t,n){const o=e.exercise.queries.find(i=>i.id===t);if(!o)return null;const r=new Set(e.hintUsages.filter(i=>i.queryId===t).map(i=>i.type)),s=$e.filter(i=>n!=null&&n.has(i.id)?!1:(!r.has(i.id)||i.repeatable)&&nt(e,o,i));return s.length===0?null:s[Math.floor(Math.random()*s.length)]}function pn(e,t){const n=t?e.hintUsages.filter(c=>c.queryId===t):[],o=Math.min(n.reduce((c,f)=>c+f.cost,0),100),r=e.exercise.queries.filter(c=>z(c).correct===z(c).total).map(c=>ke(e.hintUsages.filter(f=>f.queryId===c.id))),s=r.length>0?r.reduce((c,f)=>c+f,0)/r.length:0,i=o<30?a.green:o<60?a.yellow:a.orange;return`
    <div class="tt-help-bar" data-score="${o}">
      <div class="tt-help-bar__labels">
        <span class="tt-help-bar__label">Help used: ${Math.round(o)}%<span class="tt-help-bar__preview"></span></span>
        ${r.length>0?`<span class="tt-help-bar__avg">avg: ${Math.round(s)===0?"Perfect!":Math.round(s)+"%"}</span>`:""}
      </div>
      <div class="tt-help-bar__track">
        <div class="tt-help-bar__fill" style="width:${Math.min(o,100)}%;background:${i}"></div>
        <div class="tt-help-bar__ghost" style="left:${Math.min(o,100)}%"></div>
      </div>
    </div>
  `}const hn=(()=>{try{return localStorage.getItem("tiptong_app_url")??"https://maganino.github.io/TipTong-pilot"}catch{return"https://maganino.github.io/TipTong-pilot"}})();function ot(e,t){var r,s,i;(r=document.getElementById("tt-save-overlay"))==null||r.remove();const n=document.createElement("div");n.id="tt-save-overlay",n.className="tt-save-overlay";const o=e.length;n.innerHTML=`<div class="tt-save-card tt-save-card--invite">
    <div class="tt-save-wordmark">TipTong</div>
    <div class="tt-save-num">${o}</div>
    <div class="tt-save-what">exercise${o!==1?"s":""} ready</div>
    <div class="tt-save-line">Yours to keep — play anywhere, hints and scores included.</div>
    <button class="tt-save-go-btn" id="tt-save-go">▶&nbsp; Save &amp; play in the app</button>
    <div class="tt-save-cancel" id="tt-save-cancel">Not now</div>
  </div>`,document.body.appendChild(n),(s=n.querySelector("#tt-save-go"))==null||s.addEventListener("click",()=>{var L;const c=t&&t.length>0?{exercises:e,scores:t}:e,f=JSON.stringify(c),p=btoa(encodeURIComponent(f).replace(/%([0-9A-F]{2})/g,(_,d)=>String.fromCharCode(parseInt(d,16)))),$=`${hn}/?import=${p}`;typeof chrome<"u"&&((L=chrome.runtime)!=null&&L.sendMessage)?chrome.runtime.sendMessage({type:"tiptong:open-tab",url:$}):window.open($,"_blank"),n.querySelector(".tt-save-card").innerHTML=`
      <div class="tt-save-done-ring">&#10003;</div>
      <div class="tt-save-what">Off to the app</div>
      <div class="tt-save-line" style="margin-bottom:8px">Pick a playlist there to finish</div>
    `,setTimeout(()=>n.remove(),2e3)}),(i=n.querySelector("#tt-save-cancel"))==null||i.addEventListener("click",()=>n.remove()),n.addEventListener("click",c=>{c.target===n&&n.remove()})}function gn(e,t){var i,c;const n=new Array(e.blanks.length).fill(null),o=new Set;for(let f=0;f<e.blanks.length;f++){const p=e.blanks[f];if(p.revealed||p.actual!==""&&p.actual.toLowerCase()===p.expected.toLowerCase()){if(!o.has(f)&&((i=t[f])==null?void 0:i.toLowerCase())===p.expected.toLowerCase())o.add(f);else for(let $=0;$<t.length;$++)if(!o.has($)&&((c=t[$])==null?void 0:c.toLowerCase())===p.expected.toLowerCase()){o.add($);break}}}const r=[];for(let f=0;f<t.length;f++)!o.has(f)&&t[f]!==" "&&r.push(t[f]);let s=0;for(let f=0;f<e.blanks.length;f++){const p=e.blanks[f];p.expected===" "||p.revealed||p.actual!==""&&p.actual.toLowerCase()===p.expected.toLowerCase()||p.actual===""&&s<r.length&&(n[f]=r[s],s++)}return n}function rt(e,t){return t.some(n=>n.queryId!==e?!1:re(n.type).autoRevealsLength)}function st(e,t){if(!e.blanks.some(i=>i.actual!==""||i.revealed))return`<span class="tt-inline-blank ${t?"tt-inline-blank--active":""}" data-query="${e.id}">···</span>`;let o=-1;for(let i=e.blanks.length-1;i>=0;i--){const c=e.blanks[i];if(c.revealed||c.actual!==""){o=i;break}}const r=o<e.blanks.length-1;let s=`<span class="tt-inline-blank" data-query="${e.id}">`;for(let i=0;i<=o;i++){const c=e.blanks[i];if(c.expected===" ")s+=" ";else if(c.revealed)s+=`<span class="tt-inline-char tt-inline-char--revealed">${c.expected}</span>`;else if(c.actual==="")s+='<span class="tt-inline-char tt-inline-char--empty">·</span>';else{const f=c.actual.toLowerCase()===c.expected.toLowerCase();s+=`<span class="tt-inline-char ${f?"tt-inline-char--correct":"tt-inline-char--wrong"}">${c.actual}</span>`}}return r&&(s+='<span class="tt-inline-char tt-inline-char--empty">...</span>'),s+="</span>",s}function it(e,t,n){const o=n?gn(e,n):null;let r='<div class="tt-blanks">';for(let s=0;s<e.blanks.length;s++){const i=e.blanks[s];if(i.expected===" "){r+='<div class="tt-blank-word-gap"></div>';continue}const c=i.actual!=="",f=i.revealed,p=c&&i.actual.toLowerCase()===i.expected.toLowerCase(),$=c&&!p&&!f,L=o==null?void 0:o[s],_=!f&&!c&&!!L;let d="tt-blank";f?d+=" tt-blank--revealed":p?d+=" tt-blank--correct":$?d+=" tt-blank--wrong":_&&(d+=" tt-blank--shuffled"),t&&(d+=" tt-blank--active");const h=f?i.expected:c?i.actual:_?L:" ";r+=`<div class="${d}" data-reveal-char="${s}" data-reveal-query="${e.id}" style="cursor:pointer">${h}</div>`}return r+="</div>",r}function fn(e){const t=e.state,{exercise:n}=t,{originalSentence:o,queries:r}=n;let s="",i=0;for(const c of r){c.startIndex>i&&(s+=`<span class="tt-sentence-text">${ne(o.slice(i,c.startIndex))}</span>`);const f=z(c),p=f.correct===f.total,$=rt(c.id,t.hintUsages),L=e.activeQueryId===c.id,_=t.shuffledLettersMap[c.id];p?s+=`<span class="tt-solved">${ne(c.answer)}</span>`:$?s+=`<span data-query="${c.id}">${it(c,L,_)}</span>`:s+=st(c,L),i=c.endIndex}return i<o.length&&(s+=`<span class="tt-sentence-text">${ne(o.slice(i))}</span>`),s}function mn(e){const t=e.state.exercise.queries;if(t.length<=1)return"";let n='<div class="tt-word-progress">';for(let o=0;o<t.length;o++){const r=t[o],s=z(r).correct===z(r).total,i=e.activeQueryId===r.id;let c="tt-word-dot";s&&(c+=" tt-word-dot--done"),i&&(c+=" tt-word-dot--active"),n+=`<span class="${c}" data-query-dot="${r.id}">${s?"✓":o+1}</span>`}return n+="</div>",n}function bn(e,t){const n=e.exercise.queries.find(s=>s.id===t);if(!n)return"";const o=new Set(e.hintUsages.filter(s=>s.queryId===t).map(s=>s.type));let r='<div class="tt-hints">';for(const s of $e){const c=o.has(s.id)&&!s.repeatable||!nt(e,n,s),f=`tt-hint-chip${c?" tt-hint-chip--disabled":""}`,p=c?0:qe(s,n.answer,ae(n)),$=p>0?`${s.description} — costs ${p}% help`:s.description;r+=`<button class="${f}" data-hint="${s.id}" data-cost="${p}" title="${$}"${c?" disabled":""}>${s.icon} ${s.label.split(" ")[0]}</button>`}return r+="</div>",r}function vn(e,t){const n=Math.round(t)===0?"Perfect!":`Help: ${Math.round(t)}%`,o=t<30?a.green:t<60?a.yellow:a.orange,r=document.createElement("div");r.className="tt-query-score",r.style.cssText=`
    text-align:center;padding:6px 12px;margin:4px 0;
    border-radius: ${N.sm};font-size: ${E.small};font-weight:700;
    color:${o};background:${o}15;
    animation:tt-fade-in 0.2s ease;
  `,r.textContent=n;const s=e.querySelector(".tt-answer-box");s?s.parentNode.insertBefore(r,s):e.appendChild(r)}function P(e){var h;if(!e.state||!e.popup)return;const{exercise:t}=e.state,n=e.popup.querySelector(".tt-popup__body");if(!n)return;if(e.minimized){n.style.display="none";return}n.style.display="block",t.type;const o=t.type==="hhh";if(!e.activeQueryId){const u=t.queries.find(S=>z(S).correct!==z(S).total);u&&(e.activeQueryId=u.id)}if(t.queries.every(u=>z(u).correct===z(u).total)){const u=e.currentIndex>=e.exercises.length-1,S=ke(e.state.hintUsages),k=Math.round(S)===0?"Perfect!":`Help needed: ${Math.round(S)}%`;n.innerHTML=`
      <div class="tt-complete">
        <div class="tt-complete__check">&#10003;</div>
        <p style="font-size: ${E.body};margin:8px 0">${ne(t.originalSentence)}</p>
        <p style="font-size: ${E.small};color:${S<30?a.green:S<60?a.yellow:a.orange};font-weight:600;margin:4px 0">${k}</p>
        ${u?`<button class="tt-hint-chip" style="margin-top:16px;font-size:${E.small}" data-action="close">Done</button>`:`<button class="tt-hint-chip" style="margin-top:16px;font-size:${E.small}" data-action="next">Next &rarr;</button>`}
        ${u?`<button class="tt-hint-chip" style="margin-top:8px;font-size:${E.small};border:1px solid ${a.yellow};color:${a.yellow}" data-action="save">Save to playlist</button>`:""}
      </div>
    `,at(e);return}const s=t.queries.find(u=>u.id===e.activeQueryId)??null,i=s?t.queries.indexOf(s):-1;let c="";if(o)c+=`<div class="tt-sentence">${fn(e)}</div>`,c+=mn(e);else if(c+=`<div class="tt-popup__question">${ne(t.originalSentence)} ?</div>`,s){const u=rt(s.id,e.state.hintUsages),S=e.state.shuffledLettersMap[s.id];u?c+=it(s,!0,S):c+=st(s,!0)}if(s){const u=Ot(s),S=o?`${i+1}/${t.queries.length}`:"Type the answer",k=e.flashHint?`<span class="tt-hint-flash-inline">${e.flashHint.icon} ${e.flashHint.label}</span>`:"",b=e.suggestedFor===s.id?e.suggested:null,y=!e.showHints&&!e.flashHint&&b?`<button class="tt-hint-flash-inline tt-hint-chip--suggested" id="tt-suggested">${b.icon} ${b.label.split(" ")[0]} · ${qe(b,s.answer,ae(s))}%</button>`:"",T=e.showHints?`<div class="tt-hints-inline">${bn(e.state,s.id)}</div>`:"",O=(s.customCues??[]).slice(0,tt(e.state,s.id)),q=O.length>0?`<div class="tt-cue-reveal">${O.map(l=>`<div>✎ ${ne(l)}</div>`).join("")}</div>`:"";c+=`
      <div class="tt-answer-box">
        <div class="tt-answer-header">
          <span class="tt-answer-label">${S}</span>
          ${T}
          <div style="display:flex;align-items:center;margin-left:auto;gap:4px">
            ${k}${y}
            <button class="tt-bulb ${e.showHints?"tt-bulb--active":""}" id="tt-bulb">💡</button>
          </div>
        </div>
        ${q}
        <input class="tt-input" value="${ne(u)}" placeholder="Type here..." autocomplete="off" autocorrect="off" autocapitalize="off" />
      </div>
    `}c+=pn(e.state,e.activeQueryId),c+=`<div class="tt-score">Exercise ${e.currentIndex+1} of ${e.exercises.length}</div>`,n.innerHTML=c;const f=u=>{!e.state||!s||(e.state=Wt(e.state,s.id,u.id),e.flashHint=u,e.suggested=null,e.suggestedFor=null,e.showHints=!1,P(e),setTimeout(()=>{e.flashHint===u&&(e.flashHint=null,P(e))},2e3))},p=n.querySelector("#tt-bulb");if(p&&s){let k=null,b=!1,y=!1,T=0,R=0,O=null;const q=()=>{O==null||O.classList.remove("tt-hint-chip--tracked"),O=null},l=(g,x)=>{var m,C;const w=(C=(m=document.elementFromPoint(g,x))==null?void 0:m.closest)==null?void 0:C.call(m,"[data-hint]");w!==O&&(q(),w&&!w.hasAttribute("disabled")&&(O=w,w.classList.add("tt-hint-chip--tracked")))},v=()=>{if(!e.state)return;const g=new Set;e.suggested&&g.add(e.suggested.id),e.lastSuggestion&&g.add(e.lastSuggestion);const x=e.suggested?new Set([e.suggested.id]):void 0,w=Re(e.state,s.id,g)??Re(e.state,s.id,x)??Re(e.state,s.id);w&&(e.lastSuggestion=w.id,e.suggested=w,e.suggestedFor=s.id,e.flashHint=null,P(e))};p.addEventListener("pointerdown",g=>{g.preventDefault(),b=!1,y=!1,T=g.clientX,R=g.clientY,e.showHints||(k=setTimeout(()=>{k=null,y=!0,e.suggested=null,e.suggestedFor=null,e.flashHint=null,e.showHints=!0,P(e)},300));const x=m=>{!b&&Math.hypot(m.clientX-T,m.clientY-R)>10&&(b=!0),e.showHints&&l(m.clientX,m.clientY)},w=()=>{if(document.removeEventListener("pointermove",x),k&&(clearTimeout(k),k=null),e.showHints){const m=O;q(),m?f(re(m.dataset.hint)):!y&&!b&&(e.showHints=!1,P(e))}else b||v()};document.addEventListener("pointermove",x),document.addEventListener("pointerup",w,{once:!0})}),p.addEventListener("contextmenu",g=>g.preventDefault())}(h=n.querySelector("#tt-suggested"))==null||h.addEventListener("click",()=>{const u=e.suggestedFor===(s==null?void 0:s.id)?e.suggested:null;u&&f(u)});const $=n.querySelector(".tt-input");$&&s&&($.focus(),$.setSelectionRange($.value.length,$.value.length),$.addEventListener("input",()=>{var k;if(!e.state||!s)return;e.flashHint=null,e.state=qt(e.state,s.id,$.value);const u=e.state.exercise.queries.find(b=>b.id===s.id),S=z(u);if(S.correct===S.total){(k=e.onWordComplete)==null||k.call(e,u.answer,e.currentIndex);const b=e.state.hintUsages.filter(R=>R.queryId===s.id),y=ke(b);e.completedScores.push({exerciseId:e.state.exercise.id,queryId:s.id,score:y,hintUsages:b.map(R=>({type:R.type,cost:R.cost}))});const T=e.state.exercise.queries.find(R=>R.id!==s.id&&z(R).correct!==z(R).total);if(T){vn(n,y),setTimeout(()=>{e.activeQueryId=T.id,P(e)},1200);return}}P(e)}));const L=n.querySelector(".tt-help-bar"),_=n.querySelector(".tt-help-bar__ghost"),d=n.querySelector(".tt-help-bar__preview");n.querySelectorAll("[data-hint]").forEach(u=>{u.addEventListener("click",()=>{!e.state||!s||f(re(u.dataset.hint))}),u.addEventListener("mouseenter",()=>{const S=Number(u.dataset.cost??0);if(!L||!_||S<=0)return;const k=Number(L.dataset.score??0);_.style.width=`${Math.max(0,Math.min(S,100-k))}%`,d&&(d.textContent=` → ${Math.min(Math.round(k+S),100)}%`)}),u.addEventListener("mouseleave",()=>{_&&(_.style.width="0%"),d&&(d.textContent="")})}),n.querySelectorAll("[data-reveal-char]").forEach(u=>{u.addEventListener("click",S=>{var T;if(S.stopPropagation(),!e.state)return;const k=parseInt(u.dataset.revealChar,10),b=u.dataset.revealQuery;e.activeQueryId!==b&&(e.activeQueryId=b),e.state=Dt(e.state,b,k);const y=e.state.exercise.queries.find(R=>R.id===b);if(y){const R=z(y);R.correct===R.total&&((T=e.onWordComplete)==null||T.call(e,y.answer,e.currentIndex))}P(e)})}),n.querySelectorAll("[data-query]").forEach(u=>{u.addEventListener("click",()=>{const S=u.dataset.query;e.activeQueryId!==S&&(e.activeQueryId=S,P(e))})}),n.querySelectorAll("[data-query-dot]").forEach(u=>{u.addEventListener("click",()=>{const S=u.dataset.queryDot;e.activeQueryId=S,e.showHints=!1,e.flashHint=null,P(e)})}),at(e)}function at(e){var t,n;e.popup&&(e.popup.querySelectorAll("[data-action]").forEach(o=>{o.addEventListener("click",()=>{const r=o.dataset.action;r==="next"?(e.currentIndex++,e.activeQueryId=null,e.showHints=!1,e.flashHint=null,e.currentIndex<e.exercises.length&&(e.state=ze(e.exercises[e.currentIndex]),P(e))):r==="close"?lt(e):r==="save"&&ot(e.exercises,e.completedScores)})}),(t=e.popup.querySelector(".tt-popup__close"))==null||t.addEventListener("click",()=>{lt(e)}),(n=e.popup.querySelector(".tt-popup__minimize"))==null||n.addEventListener("click",()=>{e.minimized=!e.minimized;const o=e.popup.querySelector(".tt-popup__minimize");o&&(o.textContent=e.minimized?"▲":"▼"),P(e)}))}function lt(e){var t,n;e._keyHandler&&document.removeEventListener("keydown",e._keyHandler),(t=e.popup)==null||t.remove(),e.popup=null,(n=e.onClose)==null||n.call(e)}function ne(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function xn(e,t){var s;ee(),(s=document.getElementById("tt-popup"))==null||s.remove();const n=document.createElement("div");n.id="tt-popup",n.className="tt-popup",n.innerHTML=`
    <div class="tt-popup__header">
      <span class="tt-popup__title">TipTong</span>
      <div style="display:flex;gap:8px">
        <button class="tt-popup__minimize" title="Minimize">▼</button>
        <button class="tt-popup__close" title="Close">&times;</button>
      </div>
    </div>
    <div class="tt-popup__body"></div>
  `,document.body.appendChild(n);const o={exercises:e,currentIndex:0,state:e.length>0?ze(e[0]):null,activeQueryId:null,showHints:!1,flashHint:null,minimized:!1,popup:n,suggested:null,suggestedFor:null,lastSuggestion:null,completedScores:[],onClose:t==null?void 0:t.onClose,onWordComplete:t==null?void 0:t.onWordComplete},r=i=>{if(i.key!=="Enter"||!o.popup)return;const c=o.popup.querySelector("[data-action='next']"),f=o.popup.querySelector("[data-action='close']");c?(i.preventDefault(),c.click()):f&&(i.preventDefault(),f.click())};document.addEventListener("keydown",r),o._keyHandler=r,P(o)}function wn(e,t,n){const o=e.slice(t,n),r=[],s=/[\p{L}\p{M}'']+/gu;let i;for(;(i=s.exec(o))!==null;)r.push({start:t+i.index,end:t+i.index+i[0].length});return r.length===0?{start:t,end:n}:r[Math.floor(Math.random()*r.length)]}function ct(e,t){if(t.cue&&(e.queries=e.queries.map(n=>({...n,customCues:[t.cue]}))),t.type==="hhh")for(const n of t.underlinedWords){if(!n.cue)continue;const o=n.start-t.sentenceStart,r=n.end-t.sentenceStart,s=e.queries.find(i=>i.startIndex<r&&i.endIndex>o);s&&(s.customCues=[...s.customCues??[],n.cue])}return e}function dt(e){const t=[];for(const n of e)if(n.type==="qa"){const o=n.question+" "+n.answer,r=Xt(o,{question:{start:0,end:n.question.length},answer:{start:n.question.length+1,end:o.length}});r&&t.push(ct(r,n))}else{let o=n.underlinedWords;o.length===0&&(o=[wn(n.sourceText,n.sentenceStart,n.sentenceEnd)]);const r=jt({sourceText:n.sourceText,sentenceSelection:{start:n.sentenceStart,end:n.sentenceEnd},wordSelections:o});r&&t.push(ct(r,n))}return t}function yn(e,t){xn(dt(e),t)}function $n(e){const t=dt(e);return t.length===0?!1:(ee(),ot(t),!0)}function ut(e){var o,r;ee(),(o=document.getElementById("tt-guide-overlay"))==null||o.remove();const t=document.createElement("div");t.id="tt-guide-overlay",t.className="tt-save-overlay",t.innerHTML=`<div class="tt-save-card tt-cue-card">
    <div class="tt-brand-row">
      ${pe(38)}
      <div>
        <h3 class="tt-brand-title" style="color:#FFFFFF !important">Turn this page into exercises</h3>
        <p class="tt-brand-kicker" style="color:#B6A6EB !important">Four steps, right on the text</p>
      </div>
    </div>
    <div class="tt-guide-steps">
      <div class="tt-guide-step"><span class="tt-guide-num">1</span>
        <div><b>Choose a mode</b>
          <p><span class="tt-guide-chip">HHH</span> fill-in-the-blanks from a sentence ·
             <span class="tt-guide-chip">Q&amp;A</span> question-and-answer pair</p>
        </div>
      </div>
      <div class="tt-guide-step"><span class="tt-guide-num">2</span>
        <div><b>Highlight 🖍</b>
          <p>Select text on the page — it becomes the exercise sentence
             (in Q&amp;A: first the question, then the answer).</p>
        </div>
      </div>
      <div class="tt-guide-step"><span class="tt-guide-num">3</span>
        <div><b>Hide 🙈</b>
          <p>Select words <i>inside</i> a highlight to underline them — those are
             what you’ll type during play. No underline? TipTong picks a word for you.</p>
        </div>
      </div>
      <div class="tt-guide-step"><span class="tt-guide-num">4</span>
        <div><b>Add a cue ✎</b>
          <p>Long-press a highlight or an underlined word and write a hint in
             your own words — it’s offered during play under “My cue”.</p>
        </div>
      </div>
    </div>
    <button class="tt-save-go-btn" id="tt-guide-go">Got it — let’s go</button>
    <p class="tt-brand-kicker" style="text-align:center;margin-top:10px !important">
      Reopen this guide anytime with the ? button in the toolbar</p>
  </div>`,document.body.appendChild(t);const n=()=>{t.remove()};(r=t.querySelector("#tt-guide-go"))==null||r.addEventListener("click",n),t.addEventListener("click",s=>{s.target===t&&n()}),document.addEventListener("keydown",function s(i){i.key==="Escape"&&(n(),document.removeEventListener("keydown",s))})}function kn(e){var s,i,c;ee(),(s=document.getElementById("tt-params-overlay"))==null||s.remove();const t=document.createElement("div");t.id="tt-params-overlay",t.className="tt-save-overlay",t.innerHTML=`<div class="tt-save-card tt-cue-card">
    <div class="tt-brand-row">
      ${pe(34)}
      <div>
        <h3 class="tt-brand-title" style="color:#FFFFFF !important">⚙ Parameters</h3>
        <p class="tt-brand-kicker" style="color:#B6A6EB !important">Apply everywhere TipTong runs in this browser</p>
      </div>
    </div>
    <label class="tt-param-label" for="tt-param-cuemax">✎ Cue length limit (characters)</label>
    <input class="tt-cue-input" id="tt-param-cuemax" type="number" inputmode="numeric"
           min="10" max="200" step="5" value="${e.values.cueMaxChars}" />
    <p class="tt-param-hint">Longest “My cue” you can write. A cue works best as a nudge — raise this if you prepare richer hints. 10–200, default 50.</p>
    <div class="tt-cue-actions">
      <span class="tt-save-cancel" style="margin-left:auto" id="tt-params-cancel">Cancel</span>
      <button class="tt-save-create-btn" id="tt-params-save">✓ Save</button>
    </div>
  </div>`,document.body.appendChild(t);const n=t.querySelector("#tt-param-cuemax");setTimeout(()=>n.focus(),50);const o=()=>t.remove(),r=()=>{const f=parseInt(n.value,10),p=Number.isFinite(f)?Math.min(Math.max(f,10),200):e.values.cueMaxChars;e.onSave({cueMaxChars:p}),o()};(i=t.querySelector("#tt-params-save"))==null||i.addEventListener("click",r),(c=t.querySelector("#tt-params-cancel"))==null||c.addEventListener("click",o),n.addEventListener("keydown",f=>{f.key==="Enter"&&r(),f.key==="Escape"&&o(),f.stopPropagation()}),t.addEventListener("click",f=>{f.target===t&&o()})}const X={green:Y.brandEnergeticGreen,orange:Y.brandBrightOrange,dark:Y.brandDarkViolet},j={display:B.familyDisplay,sans:B.familySans,label:B.sizeLabel,body:B.sizeBody,small:B.sizeSmall},se={lg:te.lg},Ae={cueMaxChars:Me},de="tt_settings";function He(e){try{chrome.storage.local.get(de,t=>e({...Ae,...(t==null?void 0:t[de])??{}}))}catch{e({...Ae})}}function Sn(e){He(t=>{try{chrome.storage.local.set({[de]:{...t,...e}})}catch{}})}function En(e){try{chrome.storage.onChanged.addListener((t,n)=>{n==="local"&&t[de]&&e({...Ae,...t[de].newValue??{}})})}catch{}}const pt=window===window.top;He(e=>Ue(e.cueMaxChars)),En(e=>Ue(e.cueMaxChars));function Cn(){return typeof CSS>"u"||!("highlights"in CSS)||typeof window.Highlight!="function"?!1:[()=>!!window.__NEXT_DATA__,()=>!!document.querySelector("[data-reactroot]"),()=>!!document.querySelector("#__next"),()=>{const t=document.body;return t?Object.keys(t).some(n=>n.startsWith("__reactFiber")||n.startsWith("__reactInternalInstance")):!1},()=>{const t=document.getElementById("root")||document.getElementById("app");return t?t._reactRootContainer?!0:Object.keys(t).some(n=>n.startsWith("__reactFiber")||n.startsWith("__reactContainer")):!1},()=>!!document.getElementById("___gatsby"),()=>window.location.hostname.includes("perlego"),()=>/(^|\.)(chatgpt\.com|openai\.com|claude\.ai)$/.test(window.location.hostname),()=>{const t=document.querySelectorAll("body > *, body > * > *");for(const n of t)if(Object.keys(n).some(o=>o.startsWith("__reactFiber")||o.startsWith("__reactContainer")))return!0;return!1}].some(t=>{try{return t()}catch{return!1}})}function ht(){if(window.__tiptong){we();return}ee();const e=document.createElement("style");e.id="tt-suppress-host",e.textContent=`
    *, *::before, *::after {
      -webkit-user-select: text !important;
      user-select: text !important;
    }
    [class*="overlay"]:not([class*="tt-"]), [class*="Overlay"]:not([class*="tt-"]),
    [class*="mask"]:not([class*="tt-"]), [class*="Mask"]:not([class*="tt-"]),
    [class*="selection-layer"], [class*="SelectionLayer"] {
      pointer-events: none !important;
    }
    .highlighter-context, .highlighter-context * {
      pointer-events: auto !important;
      -webkit-user-select: text !important;
      user-select: text !important;
    }
    [class*="AnnotationToolbar"], [class*="annotationToolbar"],
    [class*="SelectionToolbar"], [class*="selectionToolbar"],
    [data-testid*="annotation"], [data-testid*="highlight"],
    [class*="Popover"], [class*="popover"],
    [class*="highlightMenu"], [class*="selectionPopover"],
    [class*="SelectionPopover"], [class*="tooltip-selection"] {
      display: none !important;
      visibility: hidden !important;
      pointer-events: none !important;
    }
  `,document.head.appendChild(e);const t=Selection.prototype.removeAllRanges,n=Selection.prototype.empty;Selection.prototype.removeAllRanges=function(){if(!(window.__tiptong&&!window.__tiptongClearing))return t.call(this)},Selection.prototype.empty=function(){if(!(window.__tiptong&&!window.__tiptongClearing))return n.call(this)},window.__tiptongSelectionRestore={origRemoveAllRanges:t,origEmpty:n};const o=Cn();o&&console.log("[TipTong] Using CSS Highlight API (React site detected)");const r=o?un():tn();window.__tiptong=r,pt?Tn(r):_n(r)}function Tn(e){const t=document.createElement("div");t.id="tt-toolbar",t.style.cssText=`
    position: fixed; top: 0; left: 0; right: 0; z-index: 999998;
    background: ${Q.gradient}; padding: 10px 16px;
    display: flex; align-items: center; gap: 10px;
    border-bottom: ${Q.cardBorder};
    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    font-family: ${j.sans};
  `,t.innerHTML=`
    <span style="color:${X.green};font-family:${j.display};font-weight:800;font-size: ${j.body};margin-right:auto">TipTong</span>
    <div style="display:flex;background:rgba(255,255,255,0.15);border-radius: ${se.lg};overflow:hidden">
      <button data-tt-mode="hhh" style="background:white;border:none;color:${X.dark};padding:6px 12px;font-size: ${j.small};font-weight:600;cursor:pointer;border-radius: ${se.lg}">HHH</button>
      <button data-tt-mode="qa" style="background:transparent;border:none;color:rgba(255,255,255,0.7);padding:6px 12px;font-size: ${j.small};font-weight:600;cursor:pointer;border-radius: ${se.lg}">Q&A</button>
    </div>
    <button id="tt-delete-btn" style="background:transparent;border:1px solid rgba(255,138,0,0.5);color:${X.orange};padding:6px 12px;font-size: ${j.small};font-weight:600;cursor:pointer;border-radius: ${se.lg}">Delete</button>
    <span id="tt-status" style="color:rgba(255,255,255,0.7);font-size: ${j.small}">Select text to highlight</span>
    <button id="tt-save-btn" style="background:transparent;border:1px solid ${X.green};color:${X.green};padding:6px 14px;font-size: ${j.small};font-weight:bold;cursor:pointer;border-radius: ${se.lg}">Save</button>
    <button id="tt-play-btn" style="background:${X.green};border:none;color:${X.dark};padding:6px 16px;font-size: ${j.small};font-weight:bold;cursor:pointer;border-radius: ${se.lg}">Play</button>
    <button id="tt-guide-btn" title="How it works" style="background:none;border:1px solid rgba(255,255,255,0.3);color:white;font-size: ${j.small};font-weight:700;cursor:pointer;opacity:0.7;width:24px;height:24px;border-radius:50%;padding:0">?</button>
    <button id="tt-params-btn" title="Parameters" style="background:none;border:1px solid rgba(255,255,255,0.3);color:white;font-size: ${j.small};cursor:pointer;opacity:0.7;width:24px;height:24px;border-radius:50%;padding:0">⚙</button>
    <button id="tt-close-btn" style="background:none;border:none;color:white;font-size: ${j.label};cursor:pointer;opacity:0.6;padding:4px">&times;</button>
    <span style="display:flex;align-items:center" aria-hidden="true">${pe(22)}</span>
  `,document.body.appendChild(t),document.body.style.marginTop=t.offsetHeight+"px",t.querySelector("#tt-guide-btn").addEventListener("click",()=>ut()),t.querySelector("#tt-params-btn").addEventListener("click",()=>{He(p=>kn({values:p,onSave:$=>Sn($)}))});try{chrome.storage.local.get("tt_guide_seen",p=>{p!=null&&p.tt_guide_seen||(ut(),chrome.storage.local.set({tt_guide_seen:!0}))})}catch{}const n=t.querySelector("#tt-status"),o=t.querySelector("#tt-delete-btn");t.querySelectorAll("[data-tt-mode]").forEach(p=>{p.addEventListener("click",()=>{t.querySelectorAll("[data-tt-mode]").forEach(L=>{L.style.background="transparent",L.style.color="rgba(255,255,255,0.7)"}),p.style.background="white",p.style.color=X.dark;const $=p.dataset.ttMode;e.setMode($),J({type:"tt:set-mode",mode:$}),r()})}),o.addEventListener("click",()=>{const p=e.toggleDeleteMode();o.style.background=p?X.orange:"transparent",o.style.color=p?"white":X.orange,o.textContent=p?"Done":"Delete",J({type:"tt:toggle-delete"})}),t.querySelector("#tt-play-btn").addEventListener("click",()=>{const p=e.getSelections();gt("tt:get-exercises",$=>{if(p.length===0&&$.length===0){n.textContent="No highlights yet";return}const L=e.validate();if(L.length>0){f(L[0]);return}e.isDeleteMode()&&e.toggleDeleteMode(),o.style.display="none",e.showAnswers(),e.hideAnswers(),e.hideUnderlinedWords(),J({type:"tt:prepare-play"});let _=e.getOrderedExerciseData();if($.length>0&&(_=_.concat($)),_.length===0){n.textContent="No complete exercises";return}yn(_,{onClose:()=>{e.showAnswers(),o.style.display="",J({type:"tt:end-play"})},onWordComplete:(d,h)=>{e.revealWord(d,h),J({type:"tt:reveal-word",word:d,exerciseIndex:h})}})})}),t.querySelector("#tt-save-btn").addEventListener("click",()=>{const p=e.validate();if(p.length>0){f(p[0]);return}gt("tt:get-exercises-data",$=>{const L=e.getOrderedExerciseData().concat($);if(L.length===0){n.textContent="No highlights yet";return}$n(L)||(n.textContent="No complete exercises")})}),window.addEventListener("message",p=>{var $;(($=p.data)==null?void 0:$.type)==="tt:status-update"&&i(p.data)});function r(){e.isDeleteMode()||(o.style.background="transparent",o.style.color=X.orange,o.textContent="Delete"),J({type:"tt:request-status"}),s()}function s(){const p=e.getSelections();if(p.length===0){n.textContent="Select text to highlight";return}const $=p.filter(d=>d.role!=="sentence"),L=p.filter(d=>d.role==="sentence"),_=[];if($.length>0){const d=Math.floor($.length/2);_.push(`${d} Q&A${$.length%2!==0?" · answer next":""}`)}L.length>0&&_.push(`${L.length} HHH`),n.textContent=_.join(" + ")}function i(p){const $=e.getSelections(),L=$.filter(h=>h.role!=="sentence").length+p.qaCount,_=$.filter(h=>h.role==="sentence").length+p.hhhCount;if(L===0&&_===0){n.textContent="Select text to highlight";return}const d=[];if(L>0){const h=Math.floor(L/2);d.push(`${h} Q&A${L%2!==0?" · answer next":""}`)}_>0&&d.push(`${_} HHH`),n.textContent=d.join(" + ")}const c=()=>setTimeout(r,50);document.addEventListener("mouseup",c),t.querySelector("#tt-close-btn").addEventListener("click",()=>{J({type:"tt:teardown"}),we()}),window.__tiptongCleanup={hl:e,onStatusUpdate:c},chrome.runtime.onMessage.addListener(p=>{p.type==="tiptong:toggle"&&(J({type:"tt:teardown"}),we())});function f(p){var L;(L=document.querySelector(".tt-toast"))==null||L.remove();const $=document.createElement("div");$.className="tt-toast",$.textContent="⚠ "+p,document.body.appendChild($),setTimeout(()=>$.remove(),3e3)}}function _n(e){window.addEventListener("message",n=>{var o,r;if((r=(o=n.data)==null?void 0:o.type)!=null&&r.startsWith("tt:"))switch(n.data.type){case"tt:set-mode":e.setMode(n.data.mode);break;case"tt:toggle-delete":e.toggleDeleteMode();break;case"tt:request-status":{const s=e.getSelections();window.parent.postMessage({type:"tt:status-update",qaCount:s.filter(i=>i.role!=="sentence").length,hhhCount:s.filter(i=>i.role==="sentence").length},"*");break}case"tt:get-exercises":{e.showAnswers(),e.hideAnswers(),e.hideUnderlinedWords();const s=e.getOrderedExerciseData();window.parent.postMessage({type:"tt:exercises-response",data:s},"*");break}case"tt:get-exercises-data":{const s=e.getOrderedExerciseData();window.parent.postMessage({type:"tt:exercises-response",data:s},"*");break}case"tt:prepare-play":e.showAnswers(),e.hideAnswers(),e.hideUnderlinedWords();break;case"tt:end-play":e.showAnswers();break;case"tt:reveal-word":e.revealWord(n.data.word,n.data.exerciseIndex);break;case"tt:teardown":we();break}});const t=()=>{setTimeout(()=>{const n=e.getSelections();window.parent.postMessage({type:"tt:status-update",qaCount:n.filter(o=>o.role!=="sentence").length,hhhCount:n.filter(o=>o.role==="sentence").length},"*")},50)};document.addEventListener("mouseup",t),window.__tiptongCleanup={hl:e,onStatusUpdate:t}}function J(e){var n;const t=document.querySelectorAll("iframe");for(const o of t)try{(n=o.contentWindow)==null||n.postMessage(e,"*")}catch{}}function gt(e,t){const n=document.querySelectorAll("iframe");if(n.length===0){t([]);return}const o=[];let r=0;const s=setTimeout(()=>t(o),500),i=c=>{var f;((f=c.data)==null?void 0:f.type)==="tt:exercises-response"&&(o.push(...c.data.data||[]),r++,r>=n.length&&(clearTimeout(s),window.removeEventListener("message",i),t(o)))};window.addEventListener("message",i),J({type:e})}function we(){var o,r,s,i;const e=window.__tiptongCleanup;e&&(e.hl.showAnswers(),e.hl.destroy(),document.removeEventListener("mouseup",e.onStatusUpdate),delete window.__tiptongCleanup);const t=document.getElementById("tt-toolbar");t&&t.remove(),pt&&(document.body.style.marginTop=""),(o=document.getElementById("tt-styles"))==null||o.remove(),(r=document.getElementById("tt-css-highlight-styles"))==null||r.remove(),(s=document.getElementById("tt-popup"))==null||s.remove(),(i=document.getElementById("tt-suppress-host"))==null||i.remove();const n=window.__tiptongSelectionRestore;n&&(Selection.prototype.removeAllRanges=n.origRemoveAllRanges,Selection.prototype.empty=n.origEmpty,delete window.__tiptongSelectionRestore),delete window.__tiptong}ht(),window.__tiptongInit=ht})();
