import * as u from "./pdf.min.mjs";
/*! TipTong Extension — © 2026 TipTong. All rights reserved.
 * Proprietary software. No license is granted to copy, modify, or redistribute. */
const s = {
  /** Primary. Body panels, primary text emphasis, selected states. */
  brandElectricViolet: "#4E15FF",
  /** Accent. CTAs, active nav, correct answers, hint affordance. */
  brandEnergeticGreen: "#0FFFB9",
  /** App chrome, headers, tab bars, body text on light. */
  brandDarkViolet: "#160751",
  /** Alerts and warnings. */
  brandBrightOrange: "#FF5400",
  /** Progress indicators, donut segments, hint bulb. */
  brandBrightYellow: "#FFDE00",
  /** Cards, text on dark surfaces. */
  brandWhite: "#FFFFFF",
  /** Muted text on dark, disabled labels, revealed/hinted letter tiles. */
  supportLavender: "#B6A6EB"
}, o = {
  /** Headings 24px and up. Bryant Bold is the real family (commercial, Process Type Foundry) - licence it for production. Nunito is the closest free fallback. */
  familyDisplay: "Bryant, Nunito, Montserrat, system-ui, sans-serif",
  /** Body and UI, 20px and below. Montserrat is on Google Fonts, so no licensing step. */
  familySans: 'Montserrat, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif',
  sizeHero: "48px",
  sizeH1: "32px",
  sizeH2: "24px",
  sizeH3: "20px",
  /** The most-used UI size in the file. */
  sizeLabel: "18px",
  sizeBody: "16px",
  sizeSmall: "14px"
}, r = {
  /** Letter tiles and blank placeholders - the most-used radius in the file. */
  tile: "2px",
  /** Word chips in the HHH picker. */
  sm: "5px",
  /** Text inputs. */
  md: "12px",
  /** Course and chapter cards (TipTemplate, CourseTile). */
  lg: "16px",
  /** Hint panel, top corners only. */
  tips: "20px",
  /** Modals and large card shapes. */
  xl: "24px",
  /** Buttons, counters, FABs. Figma uses 100, not 9999. */
  pill: "100px"
}, w = {
  violet: s.brandElectricViolet,
  green: s.brandEnergeticGreen,
  orange: s.brandBrightOrange,
  yellow: s.brandBrightYellow,
  dark: s.brandDarkViolet,
  white: s.brandWhite,
  lavender: s.supportLavender
}, p = {
  display: o.familyDisplay,
  sans: o.familySans,
  hero: o.sizeHero,
  h1: o.sizeH1,
  h2: o.sizeH2,
  h3: o.sizeH3,
  label: o.sizeLabel,
  body: o.sizeBody,
  small: o.sizeSmall
}, P = {
  tile: r.tile,
  sm: r.sm,
  md: r.md,
  lg: r.lg,
  tips: r.tips,
  xl: r.xl,
  pill: r.pill
};
u.GlobalWorkerOptions.workerSrc = "./pdf.worker.min.mjs";
const v = new URLSearchParams(window.location.search), C = v.get("file"), k = v.get("source"), B = v.get("error"), m = document.getElementById("loading"), y = document.getElementById("error"), x = document.getElementById("pdf-container");
B === "noaccess" ? b(
  "Cannot access local files",
  'Enable "Allow access to file URLs" in the TipTong extension settings (chrome://extensions → TipTong → Details)',
  ""
) : k === "local" ? T() : C ? F({ url: C }) : b("No PDF URL provided", "", "");
async function T() {
  m.textContent = "Loading local PDF...", chrome.runtime.sendMessage({ type: "tiptong:get-pdf-data" }, (t) => {
    if (!(t != null && t.data)) {
      R();
      return;
    }
    const e = atob(t.data), n = new Uint8Array(e.length);
    for (let i = 0; i < e.length; i++)
      n[i] = e.charCodeAt(i);
    document.title = `TipTong — ${t.name || "PDF"}`, F({ data: n });
  });
}
function R() {
  m.style.display = "none", y.style.display = "block", y.innerHTML = `
    <div style="margin-bottom:16px;color:white;font-size: ${p.body}">Select your PDF file</div>
    <div style="font-size: ${p.small};opacity:0.7;margin-bottom:16px">
      Chrome requires manual file selection for local PDFs.
    </div>
    <label style="display:inline-block;background:${w.green};color:${w.dark};padding:12px 24px;border-radius: ${P.pill};font-weight:bold;cursor:pointer;font-size: ${p.small}">
      Choose PDF
      <input type="file" accept=".pdf" style="display:none" id="pdf-file-input">
    </label>
  `;
  const t = document.getElementById("pdf-file-input");
  t.addEventListener("change", () => {
    var i;
    const e = (i = t.files) == null ? void 0 : i[0];
    if (!e) return;
    y.style.display = "none", m.style.display = "block", m.textContent = `Loading ${e.name}...`, document.title = `TipTong — ${e.name}`;
    const n = new FileReader();
    n.onload = () => {
      F({ data: new Uint8Array(n.result) });
    }, n.readAsArrayBuffer(e);
  });
}
async function F(t) {
  try {
    const e = await u.getDocument(t).promise;
    m.style.display = "none";
    const i = (await e.getPage(1)).getViewport({ scale: 1 }).width, D = x.clientWidth - 48, E = Math.min(Math.max(D / i, 1), 3);
    x.style.setProperty("--scale-factor", String(E));
    const g = window.devicePixelRatio || 1;
    let z = 0;
    for (let l = 1; l <= e.numPages; l++) {
      const h = await e.getPage(l), a = h.getViewport({ scale: E }), d = document.createElement("div");
      d.className = "page-wrapper", d.style.width = a.width + "px", d.style.height = a.height + "px";
      const c = document.createElement("canvas");
      c.width = Math.floor(a.width * g), c.height = Math.floor(a.height * g), c.style.width = a.width + "px", c.style.height = a.height + "px", d.appendChild(c);
      const $ = c.getContext("2d");
      await h.render({
        canvasContext: $,
        viewport: a,
        transform: g !== 1 ? [g, 0, 0, g, 0, 0] : void 0
      }).promise;
      const f = document.createElement("div");
      f.className = "textLayer", d.appendChild(f);
      const L = await h.getTextContent();
      z += L.items.length, await new u.TextLayer({
        textContentSource: L,
        container: f,
        viewport: a
      }).render(), x.appendChild(d);
    }
    if (z === 0) {
      const l = document.createElement("div");
      l.style.cssText = `
        position: fixed; top: 64px; left: 50%; transform: translateX(-50%);
        background: ${w.orange}; color: white; z-index: 999999;
        padding: 10px 18px; border-radius: ${P.pill};
        font-size: ${p.small}; font-weight: 600; max-width: 480px; text-align: center;
        box-shadow: 0 4px 12px rgba(0,0,0,0.4);
      `, l.textContent = "This PDF has no selectable text (it looks scanned) — highlighting needs real text. OCR support is on the roadmap.", document.body.appendChild(l);
    }
    window.__pdfReady = !0, document.dispatchEvent(new CustomEvent("tiptong:pdf-ready"));
  } catch (e) {
    b("Failed to load PDF", e.message, t.url || "local file");
  }
}
function b(t, e, n) {
  m.style.display = "none", y.style.display = "block", y.innerHTML = `<div style="margin-bottom:12px">${t}</div>` + (e ? `<div style="font-size: ${p.small};opacity:0.8">${e}</div>` : "") + (n ? `<div style="font-size: ${p.small};opacity:0.6;margin-top:8px">URL: ${n}</div>` : "");
}
