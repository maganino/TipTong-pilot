/*! TipTong Extension — © 2026 TipTong. All rights reserved.
 * Proprietary software. No license is granted to copy, modify, or redistribute. */(function(){"use strict";const X={brandElectricViolet:"#4E15FF",brandEnergeticGreen:"#0FFFB9",brandDarkViolet:"#160751",brandBrightOrange:"#FF5400",brandBrightYellow:"#FFDE00",brandWhite:"#FFFFFF",supportLavender:"#B6A6EB"},B={familyDisplay:"Bryant, Nunito, Montserrat, system-ui, sans-serif",familySans:'Montserrat, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif',sizeHero:"48px",sizeH1:"32px",sizeH2:"24px",sizeLabel:"18px",sizeBody:"16px",sizeSmall:"14px"},ee={tile:"2px",sm:"5px",md:"12px",lg:"16px",xl:"24px",pill:"100px"},_={display:B.familyDisplay,sans:B.familySans,hero:B.sizeHero,h1:B.sizeH1,h2:B.sizeH2,label:B.sizeLabel,body:B.sizeBody,small:B.sizeSmall},N={tile:ee.tile,sm:ee.sm,md:ee.md,lg:ee.lg,xl:ee.xl,pill:ee.pill},l={violet:X.brandElectricViolet,green:X.brandEnergeticGreen,orange:X.brandBrightOrange,yellow:X.brandBrightYellow,dark:X.brandDarkViolet,white:X.brandWhite,lavender:X.supportLavender,greenInk:"#0A9E74"},U={gradient:`linear-gradient(170deg, #14406B 0%, #16265C 55%, ${l.dark} 100%)`,card:"rgba(255,255,255,0.06)",cardBorder:"1px solid rgba(255,255,255,0.12)"},lt=`
.tt-highlight {
  background-color: ${l.violet}20 !important;
  border-bottom: 2px solid ${l.violet}60 !important;
  border-radius: ${N.tile} !important;
  cursor: pointer !important;
  transition: background-color 0.15s !important;
  position: relative !important;
  display: inline !important;
}
.tt-highlight:hover {
  background-color: ${l.violet}35 !important;
}
.tt-highlight--answer {
  background-color: ${l.green}20 !important;
  border-bottom-color: ${l.green}60 !important;
}
.tt-highlight--answer:hover {
  background-color: ${l.green}35 !important;
}
.tt-highlight--delete {
  background-color: ${l.orange}20 !important;
  border-bottom-color: ${l.orange} !important;
  text-decoration: line-through !important;
  cursor: pointer !important;
}
.tt-underline {
  border-bottom: 2px dotted ${l.green} !important;
  font-weight: bold !important;
  background-color: ${l.green}20 !important;
  border-radius: ${N.tile} !important;
  cursor: pointer !important;
}
.tt-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  border-radius: ${N.sm};
  color: white;
  font-size: ${_.small};
  font-weight: bold;
  margin-right: 3px;
  vertical-align: middle;
  line-height: 16px;
}
.tt-badge--q { background-color: ${l.violet}; }
.tt-badge--a { background-color: ${l.green}; }

/* Interactive sentence (HHH inline blanks) */
.tt-sentence {
  font-size: ${_.body};
  line-height: 2;
  background: ${U.card};
  border: ${U.cardBorder};
  border-radius: ${N.md};
  padding: 12px 16px;
  margin-bottom: 12px;
  color: ${l.white};
}
.tt-sentence-text { color: ${l.white}; }
.tt-inline-blank {
  font-weight: bold;
  color: ${l.lavender};
  background: ${l.white}10;
  border-radius: ${N.sm};
  padding: 2px 6px;
  cursor: pointer;
}
.tt-inline-blank--active {
  background: ${l.green}20;
  color: ${l.green};
}
.tt-inline-char { font-size: ${_.body}; }
.tt-inline-char--revealed { color: ${l.white}; background: ${l.green}; border-radius: ${N.tile}; padding: 0 1px; }
.tt-inline-char--correct { color: ${l.green}; font-weight: bold; }
.tt-inline-char--wrong { color: ${l.orange}; font-weight: bold; }
.tt-inline-char--empty { color: ${l.white}30; }
.tt-solved {
  font-weight: bold;
  color: ${l.green};
  background: ${l.green}10;
  border-radius: ${N.sm};
  padding: 2px 4px;
}

/* Word progress dots */
.tt-word-progress {
  display: flex;
  gap: 12px;
  justify-content: center;
  margin-bottom: 12px;
}
.tt-word-dot {
  width: 24px;
  height: 24px;
  border-radius: ${N.md};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: ${_.small};
  font-weight: 600;
  cursor: pointer;
  background: ${l.white}20;
  color: ${l.white};
  opacity: 0.6;
}
.tt-word-dot--done { background: ${l.green}; opacity: 1; }
.tt-word-dot--active { background: ${l.white}; color: ${l.green}; border: 2px solid ${l.green}; opacity: 1; }

/* Answer box */
.tt-answer-box {
  background: ${l.white}10;
  border-radius: ${N.md};
  padding: 12px;
  margin-top: 8px;
  border: 1px solid ${l.green}40;
}
.tt-answer-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}
.tt-answer-label {
  font-size: ${_.small};
  color: ${l.white};
  opacity: 0.6;
  text-transform: uppercase;
  letter-spacing: 1px;
}
.tt-bulb {
  /* The browser must not turn the fan drag into a scroll or text selection. */
  touch-action: none;
  user-select: none;
  background: ${l.white}15;
  border: none;
  border-radius: ${N.lg};
  width: 32px;
  height: 32px;
  font-size: ${_.body};
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
}
.tt-bulb:hover, .tt-bulb--active { background: ${l.yellow}40; }
.tt-hint-container { margin-bottom: 8px; }
.tt-blank--active { border-bottom-color: ${l.green}; }

/* Player popup */
.tt-popup {
  position: fixed;
  bottom: 20px;
  right: 20px;
  width: 380px;
  max-width: calc(100vw - 40px);
  background: ${U.gradient};
  border: ${U.cardBorder};
  border-radius: ${N.xl};
  box-shadow: 0 8px 32px rgba(0,0,0,0.4);
  z-index: 999999;
  font-family: ${_.sans};
  color: ${l.white};
  overflow: hidden;
}
.tt-popup__header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px;
  background: ${U.card};
  border-bottom: ${U.cardBorder};
}
.tt-popup__title {
  font-family: ${_.display};
  font-size: ${_.small};
  font-weight: 800;
  letter-spacing: 0.02em;
  color: ${l.green};
}
.tt-popup__close {
  background: none;
  border: none;
  color: ${l.white};
  font-size: ${_.label};
  cursor: pointer;
  opacity: 0.7;
  padding: 4px;
}
.tt-popup__minimize {
  background: none;
  border: none;
  color: ${l.white};
  font-size: ${_.small};
  cursor: pointer;
  opacity: 0.7;
  padding: 4px;
}
.tt-popup__close:hover, .tt-popup__minimize:hover { opacity: 1; }
.tt-popup__body {
  padding: 16px;
}
.tt-popup__question {
  font-size: ${_.body};
  line-height: 1.5;
  margin-bottom: 16px;
  color: ${l.white};
}

/* Blank boxes */
.tt-blanks {
  display: flex;
  flex-wrap: wrap;
  gap: 3px;
  margin-bottom: 12px;
}
.tt-blank-word-gap { width: 12px; }
.tt-blank {
  width: 22px;
  height: 28px;
  border-radius: ${N.sm};
  background: ${l.white}15;
  border-bottom: 2px solid ${l.violet}40;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: ${_.small};
  font-weight: bold;
  color: ${l.white}50;
}
.tt-blank--correct {
  color: ${l.green};
  background: ${l.green}15;
  border-bottom-color: ${l.green};
}
.tt-blank--wrong {
  color: ${l.orange};
  background: ${l.orange}15;
  border-bottom-color: ${l.orange};
}
.tt-blank--revealed {
  color: ${l.white};
  background: ${l.green};
  border-bottom-color: ${l.green};
}
.tt-blank--shuffled {
  color: ${l.yellow};
  background: ${l.yellow}15;
  border-bottom-color: ${l.yellow}40;
}

/* Input */
.tt-input {
  width: 100%;
  height: 40px;
  background: ${l.white}15;
  border: none;
  border-radius: ${N.sm};
  color: ${l.white};
  font-size: ${_.body};
  text-align: center;
  font-weight: 600;
  outline: none;
  box-sizing: border-box;
  padding: 0 12px;
}
.tt-input::placeholder { color: ${l.white}40; }
.tt-input:focus { box-shadow: 0 0 0 2px ${l.green}60; }

/* Hint bar */
.tt-hints {
  display: flex;
  gap: 6px;
  overflow-x: auto;
  padding: 8px 0;
  scrollbar-width: none;
}
.tt-hints::-webkit-scrollbar { display: none; }
.tt-hint-chip {
  display: flex;
  align-items: center;
  gap: 4px;
  background: ${l.white}15;
  border: none;
  border-radius: ${N.lg};
  padding: 6px 10px;
  color: ${l.white};
  font-size: ${_.small};
  font-weight: 600;
  cursor: pointer;
  white-space: nowrap;
  transition: background 0.15s;
}
.tt-hint-chip:hover { background: ${l.white}25; }
.tt-hint-chip--disabled { opacity: 0.3; pointer-events: none; }
/* Chip under the finger during a fan drag — dock magnification */
.tt-hint-chip--tracked {
  background: ${l.green}30;
  outline: 1px solid ${l.green};
  transform: scale(1.12);
}
/* Pending bulb suggestion, glowing for its confirming tap */
.tt-hint-chip--suggested {
  border: 1px solid ${l.green};
  background: ${l.green}15;
  cursor: pointer;
  box-shadow: 0 0 8px ${l.green}60;
}
/* Help progress bar */
.tt-help-bar {
  padding: 8px 12px;
}
.tt-help-bar__labels {
  display: flex;
  justify-content: space-between;
  margin-bottom: 4px;
}
.tt-help-bar__label {
  font-size: ${_.small};
  font-weight: 600;
  color: ${l.white};
}
.tt-help-bar__avg {
  font-size: ${_.small};
  color: ${l.white};
  opacity: 0.5;
}
.tt-help-bar__track {
  position: relative;
  height: 6px;
  border-radius: ${N.tile};
  background: ${l.white}15;
  overflow: hidden;
}
.tt-help-bar__fill {
  height: 100%;
  border-radius: ${N.tile};
  transition: width 0.3s ease, background-color 0.3s ease;
}
/* Hover price preview: grows out of the fill while a hint chip is hovered */
.tt-help-bar__ghost {
  position: absolute;
  top: 0;
  height: 100%;
  width: 0;
  background: ${l.white}55;
  border-radius: ${N.tile};
  transition: width 0.15s ease;
  pointer-events: none;
}
.tt-help-bar__preview {
  color: ${l.yellow};
  font-weight: 600;
}

/* Hint flash pill — inline to left of bulb */
.tt-hint-flash-inline {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  background: ${l.white}10;
  border: 1px solid ${l.green}40;
  border-radius: ${N.md};
  padding: 3px 8px;
  font-size: ${_.small};
  color: ${l.white};
  white-space: nowrap;
}

/* Hints bar inline in header */
.tt-hints-inline {
  flex: 1;
  overflow-x: auto;
  margin: 0 4px;
}
.tt-hints-inline::-webkit-scrollbar { display: none; }
.tt-hints-inline .tt-hints {
  flex-wrap: nowrap;
  gap: 4px;
}
.tt-hints-inline .tt-hint-chip {
  padding: 4px 8px;
  font-size: ${_.small};
}

/* Revealed "My cue" lines above the input */
.tt-cue-reveal {
  margin-bottom: 8px;
  display: grid;
  gap: 4px;
}
.tt-cue-reveal div {
  font-size: ${_.small};
  color: ${l.yellow};
  background: ${l.yellow}12;
  border-radius: ${N.sm};
  padding: 4px 8px;
}

/* ✎ marker on highlights that carry an authored cue */
.tt-has-cue::after {
  content: "✎";
  font-size: 10px;
  vertical-align: super;
  color: ${l.violet};
  opacity: 0.8;
  margin-left: 1px;
}

/* Cue editor (long-press on a highlight or underline) */
.tt-cue-context {
  font-size: ${_.small};
  color: ${l.lavender};
  font-style: italic;
  margin-bottom: 10px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.tt-cue-input {
  width: 100%;
  box-sizing: border-box;
  height: 36px;
  background: ${l.white}10;
  border: 1px solid ${l.white}20;
  border-radius: ${N.sm};
  padding: 0 10px;
  font-size: ${_.small};
  color: ${l.white};
  outline: none;
}
.tt-cue-input:focus { box-shadow: 0 0 0 2px ${l.green}60; }
.tt-cue-actions {
  display: flex;
  gap: 8px;
  margin-top: 14px;
  align-items: center;
}
.tt-cue-remove {
  font-size: ${_.small};
  color: ${l.orange};
  cursor: pointer;
  margin-right: auto;
}

/* Save modal */
.tt-save-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999999;
  padding: 24px;
}
.tt-save-card {
  background: ${U.gradient};
  border: ${U.cardBorder};
  border-radius: ${N.lg};
  padding: 20px;
  width: 100%;
  max-width: 360px;
  color: ${l.white};
}
.tt-save-card h3 {
  margin: 0;
  font-family: ${_.display};
  font-weight: 800;
  font-size: ${_.label};
}
.tt-save-card .tt-save-sub {
  font-size: ${_.small};
  opacity: 0.6;
  margin-top: 2px;
}

/* The invite: a centered hand-off card — the app surface in miniature,
   one number, one line, one glowing way forward. */
@keyframes tt-pop {
  from { opacity: 0; transform: scale(0.94) translateY(10px); }
  to   { opacity: 1; transform: scale(1) translateY(0); }
}
.tt-save-card--invite {
  text-align: center;
  padding: 26px 24px 18px;
  /* A green dawn over the app gradient — the moment feels like a win */
  background:
    radial-gradient(420px 220px at 50% -40%, ${l.green}2E, transparent 65%),
    ${U.gradient};
  animation: tt-pop 0.25s ease-out;
}
.tt-save-wordmark {
  font-family: ${_.display};
  font-weight: 800;
  font-size: ${_.small};
  letter-spacing: 0.04em;
  color: ${l.green};
}
.tt-save-num {
  font-family: ${_.display};
  font-weight: 800;
  font-size: 46px;
  line-height: 1.1;
  color: ${l.yellow};
  margin-top: 8px;
}
.tt-save-what {
  font-size: ${_.body};
  font-weight: 700;
  color: ${l.white};
  margin-bottom: 8px;
}
.tt-save-line {
  font-size: ${_.small};
  color: ${l.lavender};
  line-height: 1.5;
  max-width: 30ch;
  margin: 0 auto 18px;
}
.tt-save-go-btn {
  width: 100%;
  box-sizing: border-box;
  background: ${l.green};
  color: ${l.dark};
  border: none;
  border-radius: ${N.pill};
  padding: 13px 16px;
  font-family: ${_.display};
  font-size: ${_.body};
  font-weight: 800;
  cursor: pointer;
  box-shadow: 0 6px 20px ${l.green}40;
  transition: transform 0.12s ease, box-shadow 0.12s ease;
}
.tt-save-go-btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 8px 24px ${l.green}55;
}
.tt-save-done-ring {
  width: 56px;
  height: 56px;
  margin: 8px auto 12px;
  border-radius: ${N.pill};
  background: ${l.green};
  color: ${l.dark};
  font-size: ${_.h2};
  font-weight: 800;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 6px 20px ${l.green}40;
}
.tt-save-row {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 8px;
  border-bottom: 1px solid ${l.white}10;
  cursor: pointer;
  border-radius: ${N.sm};
}
.tt-save-row:hover {
  background: ${l.white}10;
}
.tt-save-input {
  flex: 1;
  height: 32px;
  background: ${l.white}10;
  border: 1px solid ${l.white}20;
  border-radius: ${N.sm};
  padding: 0 8px;
  font-size: ${_.small};
  color: ${l.white};
}
.tt-save-input::placeholder { color: ${l.white}40; }
.tt-save-create-btn {
  background: ${l.green};
  border: none;
  border-radius: ${N.pill};
  padding: 6px 14px;
  font-weight: bold;
  color: ${l.dark};
  cursor: pointer;
  font-size: ${_.small};
}
.tt-save-cancel {
  text-align: center;
  margin-top: 12px;
  font-size: ${_.small};
  opacity: 0.5;
  cursor: pointer;
}
.tt-save-check {
  text-align: center;
  font-size: ${_.h1};
  color: ${l.green};
}
.tt-save-msg {
  text-align: center;
  font-size: ${_.small};
  font-weight: 600;
  margin-top: 8px;
}

/* Toast animations */
@keyframes tt-fade-in {
  from { opacity: 0; transform: translateY(-4px); }
  to { opacity: 1; transform: translateY(0); }
}
@keyframes tt-toast-fade {
  0% { opacity: 0; transform: translateY(-10px); }
  10% { opacity: 1; transform: translateY(0); }
  80% { opacity: 1; transform: translateY(0); }
  100% { opacity: 0; transform: translateY(-10px); }
}
.tt-toast {
  position: fixed;
  top: 52px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 999999;
  background: ${l.orange};
  color: white;
  padding: 10px 20px;
  border-radius: ${N.sm};
  font-family: ${_.sans};
  font-size: ${_.small};
  font-weight: 600;
  box-shadow: 0 4px 12px rgba(0,0,0,0.3);
  animation: tt-toast-fade 3s ease forwards;
  pointer-events: none;
}

/* Score */
.tt-score {
  text-align: center;
  padding: 8px;
  font-size: ${_.small};
  color: ${l.white};
  opacity: 0.6;
}

/* Complete state */
.tt-complete {
  text-align: center;
  padding: 20px;
}
.tt-complete__check {
  font-size: ${_.hero};
  color: ${l.green};
  margin-bottom: 8px;
}
.tt-complete__score {
  font-size: ${_.h1};
  font-weight: bold;
  /* Not electric violet: on the dark surface it reads as a gap (see HelpDonut). */
  color: ${l.yellow};
}
`;function oe(){if(document.getElementById("tt-styles"))return;ct();const e=document.createElement("style");e.id="tt-styles",e.textContent=lt,document.head.appendChild(e)}function ct(){if(!document.getElementById("tt-fonts"))try{const e=document.createElement("link");e.id="tt-fonts",e.rel="stylesheet",e.href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Nunito:wght@700&display=swap",document.head.appendChild(e)}catch{}}const dt=`
::highlight(tt-question) {
  background-color: ${l.violet}20;
  color: inherit;
}
::highlight(tt-answer) {
  background-color: ${l.green}20;
  color: inherit;
}
::highlight(tt-sentence) {
  background-color: ${l.violet}20;
  color: inherit;
}
::highlight(tt-underline) {
  background-color: ${l.green}20;
  text-decoration: underline dotted ${l.green};
  text-decoration-thickness: 2px;
  color: inherit;
}
::highlight(tt-delete) {
  background-color: ${l.orange}20;
  text-decoration: line-through;
  color: inherit;
}
`;function ut(){if(document.getElementById("tt-css-highlight-styles"))return;const e=document.createElement("style");e.id="tt-css-highlight-styles",e.textContent=dt,document.head.appendChild(e)}function _e(e){var s,i,d,b;oe(),(s=document.getElementById("tt-cue-overlay"))==null||s.remove();const t=document.createElement("div");t.id="tt-cue-overlay",t.className="tt-save-overlay",t.innerHTML=`<div class="tt-save-card">
    <h3>My cue — this ${e.scope}</h3>
    <div class="tt-save-sub" style="margin-bottom:10px">A hint in your own words, offered in play under ✎ My cue</div>
    <div class="tt-cue-context">“${ht(e.context)}”</div>
    <input class="tt-cue-input" id="tt-cue-input" placeholder="e.g. where you sit · 6 letters" maxlength="120" />
    <div class="tt-cue-actions">
      ${e.initial?'<span class="tt-cue-remove" id="tt-cue-remove">Remove</span>':""}
      <span class="tt-save-cancel" style="margin:0" id="tt-cue-cancel">Cancel</span>
      <button class="tt-save-create-btn" id="tt-cue-save">Save cue</button>
    </div>
  </div>`,document.body.appendChild(t);const n=t.querySelector("#tt-cue-input");n.value=e.initial,setTimeout(()=>n.focus(),50);const o=()=>t.remove(),r=()=>{const h=n.value.trim();h?e.onSave(h):e.initial&&e.onRemove(),o()};(i=t.querySelector("#tt-cue-save"))==null||i.addEventListener("click",r),n.addEventListener("keydown",h=>{h.key==="Enter"&&r(),h.key==="Escape"&&o(),h.stopPropagation()}),(d=t.querySelector("#tt-cue-cancel"))==null||d.addEventListener("click",o),(b=t.querySelector("#tt-cue-remove"))==null||b.addEventListener("click",()=>{e.onRemove(),o()}),t.addEventListener("click",h=>{h.target===t&&o()})}function ht(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}let gt=1;function G(){const e=window.getSelection();e&&(window.__tiptongClearing=!0,e.removeAllRanges(),window.__tiptongClearing=!1)}function xe(e,t,n){const o=[];if(e.startContainer===e.endContainer&&e.startContainer.nodeType===Node.TEXT_NODE){const b=document.createElement("span");return b.className=t,b.dataset.ttId=n,e.surroundContents(b),o.push(b),o}const r=[],s=document.createTreeWalker(e.commonAncestorContainer,NodeFilter.SHOW_TEXT);let i,d=!1;for(;i=s.nextNode();)if(i===e.startContainer)d=!0,r.push({node:i,start:e.startOffset,end:i.textContent.length});else if(i===e.endContainer){r.push({node:i,start:0,end:e.endOffset});break}else d&&r.push({node:i,start:0,end:i.textContent.length});for(let b=r.length-1;b>=0;b--){const{node:h,start:$,end:T}=r[b];if($===T)continue;const L=document.createRange();L.setStart(h,$),L.setEnd(h,T);const c=document.createElement("span");c.className=t,c.dataset.ttId=n,L.surroundContents(c),o.push(c)}return o.reverse(),o}function pt(e){const t=document.caretRangeFromPoint(e.clientX,e.clientY);if(!t||t.startContainer.nodeType!==Node.TEXT_NODE)return null;const n=t.startContainer,o=n.textContent||"",r=t.startOffset;if(r>=o.length||o[r]===" "||o[r]===`
`)return null;let s=r;for(;s>0&&o[s-1]!==" "&&o[s-1]!==`
`;)s--;let i=r;for(;i<o.length&&o[i]!==" "&&o[i]!==`
`;)i++;const d=document.createRange();return d.setStart(n,s),d.setEnd(n,i),d}function ft(e,t,n){if(n!=="qa")return;const o=document.createElement("span");o.className=`tt-badge ${t==="answer"?"tt-badge--a":"tt-badge--q"}`,o.setAttribute("data-tt-badge",""),o.textContent=t==="answer"?"A":"Q",e.insertBefore(o,e.firstChild)}function mt(e){return Array.from(e).filter(t=>/[\p{L}\p{M}'''\-\s]/u.test(t)).join("")}function ae(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function we(e){let t="";for(const n of e.childNodes)if(n.nodeType===Node.TEXT_NODE)t+=n.textContent;else if(n.nodeType===Node.ELEMENT_NODE){const o=n;if(o.dataset.ttHandle||o.hasAttribute("data-tt-badge"))continue;t+=we(o)}return t}function bt(e){if(e.startContainer.nodeType===Node.TEXT_NODE){const t=e.startContainer.textContent||"";let n=e.startOffset;for(;n>0&&t[n-1]!==" "&&t[n-1]!==`
`;)n--;e.setStart(e.startContainer,n)}if(e.endContainer.nodeType===Node.TEXT_NODE){const t=e.endContainer.textContent||"";let n=e.endOffset;for(;n<t.length&&t[n]!==" "&&t[n]!==`
`;)n++;e.setEnd(e.endContainer,n)}}function xt(){oe();const e={mode:"hhh",highlights:[],deleteMode:!1};let t=[];function n(c){var u,S,k,m;let g=c.nodeType===Node.TEXT_NODE?c.parentElement:c;for(;g;){if((u=g.dataset)!=null&&u.ttId)return e.highlights.find(y=>y.id===g.dataset.ttId)??null;if((S=g.classList)!=null&&S.contains("tt-underline")&&((m=(k=g.parentElement)==null?void 0:k.dataset)!=null&&m.ttId))return e.highlights.find(y=>y.id===g.parentElement.dataset.ttId)??null;g=g.parentElement}return null}function o(){if(e.deleteMode){const w=window.getSelection();if(w&&!w.isCollapsed&&w.toString().trim().length>0){e.deleteMode=!1;for(const v of e.highlights)for(const f of v.spans)f.classList.remove("tt-highlight--delete")}else return}const c=window.getSelection();if(!c||c.isCollapsed||!c.rangeCount||!c.toString().trim())return;const u=c.getRangeAt(0),S=document.getElementById("tt-toolbar"),k=document.getElementById("tt-popup");if(S!=null&&S.contains(u.startContainer)){G();return}if(k!=null&&k.contains(u.startContainer)){G();return}bt(u);const m=u.toString().trim();if(!m){G();return}const y=n(u.startContainer),C=n(u.endContainer);if(y&&y===C){if(e.mode==="hhh"&&y.role==="sentence"){G();return}G();return}const R=y||C;if(R){d(R,u),G();return}if(e.mode==="hhh"&&m.split(/\s+/).filter(Boolean).length<2){G();return}const O=e.highlights.filter(w=>w.role!=="sentence").length,q=e.mode==="qa"?O%2===0?"question":"answer":"sentence",a=`tt-${gt++}`,p=xe(u,q==="answer"?"tt-highlight tt-highlight--answer":"tt-highlight",a);if(p.length>0){ft(p[0],q,e.mode);const w={id:a,text:m,role:q,spans:p,underlinedWords:[]};e.highlights.push(w),p.forEach(v=>T(v,w))}G()}function r(c,g){const u=c.underlinedWords[g];if(!u)return;const S=u.span.parentNode;if(S){for(;u.span.firstChild;)S.insertBefore(u.span.firstChild,u.span);S.removeChild(u.span),S.normalize()}c.underlinedWords.splice(g,1)}function s(c,g){var m,y;const u=pt(g);if(!u)return;const S=u.toString().trim();if(!S)return;const k=c.underlinedWords.findIndex(C=>C.span.contains(u.startContainer)||C.text===S);if(k>=0)r(c,k);else{const C=g.target;if((m=C.classList)!=null&&m.contains("tt-underline")||(y=C.closest)!=null&&y.call(C,".tt-underline")){const a=C.classList.contains("tt-underline")?C:C.closest(".tt-underline"),x=c.underlinedWords.findIndex(p=>p.span===a);if(x>=0){r(c,x);return}}const R=c.text.split(/\s+/).filter(Boolean).length,O=Math.floor(R/2);if(c.underlinedWords.length>=O)return;const q=document.createElement("span");q.className="tt-underline";try{u.surroundContents(q),c.underlinedWords.push({text:S,span:q})}catch{}}}function i(c){const g=e.highlights.find(S=>S.id===c);if(!g)return;const u=new Set([c]);if(g.role==="question"||g.role==="answer"){const S=e.highlights.filter(C=>C.role!=="sentence"),k=S.findIndex(C=>C.id===c),y=k%2===0?k+1:k-1;y>=0&&y<S.length&&u.add(S[y].id)}for(const S of u){const k=e.highlights.find(m=>m.id===S);if(k){for(const m of k.underlinedWords){const y=m.span.parentNode;if(y){for(;m.span.firstChild;)y.insertBefore(m.span.firstChild,m.span);y.removeChild(m.span)}}for(const m of k.spans)m.querySelectorAll("[data-tt-badge]").forEach(y=>y.remove());for(const m of k.spans){const y=m.parentNode;if(y){for(;m.firstChild;)y.insertBefore(m.firstChild,m);y.removeChild(m),y.normalize()}}}}e.highlights=e.highlights.filter(S=>!u.has(S.id)),e.highlights.length===0&&(e.deleteMode=!1)}function d(c,g){try{const u=n(g.startContainer)===c,S=n(g.endContainer)===c;if(!u){const k=c.spans[0],m=document.createRange();if(m.setStart(g.startContainer,g.startOffset),m.setEndBefore(k),m.toString().length>0)try{const y=xe(m,k.className,c.id);c.spans.unshift(...y);const C=k.querySelector("[data-tt-badge]");C&&y[0]&&y[0].insertBefore(C,y[0].firstChild),y.forEach(R=>T(R,c))}catch{}}if(!S){const k=c.spans[c.spans.length-1],m=document.createRange();if(m.setStartAfter(k),m.setEnd(g.endContainer,g.endOffset),m.toString().length>0)try{const y=xe(m,k.className,c.id);c.spans.push(...y),y.forEach(C=>T(C,c))}catch{}}for(c.text=c.spans.map(k=>we(k)).join("");c.underlinedWords.length>0;)r(c,0)}catch{}}let b=0;function h(c,g){c.classList.toggle("tt-has-cue",!!g),g?c.title=`My cue: ${g}`:c.removeAttribute("title")}function $(c,g){c.addEventListener("pointerdown",u=>{var O,q;if(e.deleteMode)return;const S=u.clientX,k=u.clientY,m=(q=(O=u.target).closest)==null?void 0:q.call(O,".tt-underline");let y=setTimeout(()=>{y=null,b=Date.now()+600,G();const a=m?g.underlinedWords.find(x=>x.span===m):void 0;_e({context:a?a.text:g.text,scope:a?"word":"exercise",initial:(a?a.cue:g.cue)??"",onSave:x=>{a?(a.cue=x,h(a.span,x)):(g.cue=x,h(g.spans[0],x))},onRemove:()=>{a?(a.cue=void 0,h(a.span,void 0)):(g.cue=void 0,h(g.spans[0],void 0))}})},500);const C=()=>{y&&(clearTimeout(y),y=null),document.removeEventListener("pointermove",R),document.removeEventListener("pointerup",C)},R=a=>{Math.hypot(a.clientX-S,a.clientY-k)>8&&C()};document.addEventListener("pointermove",R),document.addEventListener("pointerup",C)})}function T(c,g){$(c,g),c.addEventListener("click",u=>{var k,m,y,C;if(Date.now()<b){u.preventDefault(),u.stopPropagation();return}if(((m=(k=u.target).closest)==null?void 0:m.call(k,"a"))&&(u.preventDefault(),u.stopPropagation()),e.deleteMode){u.preventDefault(),u.stopPropagation();const R=(C=(y=u.target).closest)==null?void 0:C.call(y,".tt-underline");if(R&&g.role==="sentence"){const O=g.underlinedWords.findIndex(q=>q.span===R);if(O>=0){r(g,O);return}}i(g.id);return}if(e.mode==="hhh"&&!e.deleteMode){const R=window.getSelection();if(R&&!R.isCollapsed)return;u.preventDefault(),u.stopPropagation(),s(g,u)}})}const L=()=>setTimeout(o,10);return document.addEventListener("mouseup",L,!0),{getSelections:()=>e.highlights.map(c=>({id:c.id,text:c.text,role:c.role,underlinedCount:c.underlinedWords.length})),validate:()=>{const c=[];return e.highlights.filter(u=>u.role!=="sentence").length%2!==0&&c.push("Last question needs an answer"),c},getMode:()=>e.mode,setMode:c=>{if(e.mode=c,e.deleteMode){e.deleteMode=!1;for(const g of e.highlights)for(const u of g.spans)u.classList.remove("tt-highlight--delete")}},toggleDeleteMode:()=>{e.deleteMode=!e.deleteMode;for(const c of e.highlights)for(const g of c.spans)g.classList.toggle("tt-highlight--delete",e.deleteMode);return e.deleteMode},isDeleteMode:()=>e.deleteMode,getQAPairs:()=>{const c=e.highlights.filter(u=>u.role!=="sentence"),g=[];for(let u=0;u+1<c.length;u+=2)g.push({question:c[u].text,answer:c[u+1].text});return g},getHHHData:()=>e.highlights.filter(g=>g.role==="sentence").map(g=>{const u=g.text,S=g.underlinedWords.map(k=>{const m=u.indexOf(k.text);return m>=0?{start:m,end:m+k.text.length}:null}).filter(k=>k!==null);return{sourceText:u,sentenceStart:0,sentenceEnd:u.length,underlinedWords:S}}),getOrderedExerciseData:()=>{const c=[];t=[];const g=[...e.highlights].sort((k,m)=>{const y=k.spans[0],C=m.spans[0];if(!y||!C)return 0;const R=y.compareDocumentPosition(C);return R&Node.DOCUMENT_POSITION_FOLLOWING?-1:R&Node.DOCUMENT_POSITION_PRECEDING?1:0}),u=g.filter(k=>k.role!=="sentence"),S=new Set;for(const k of g)if(k.role==="question"){const m=u.indexOf(k),y=Math.floor(m/2);if(S.has(y))continue;const C=u[m+1];C&&(S.add(y),c.push({type:"qa",question:k.text,answer:C.text,cue:k.cue??C.cue}),t.push(C.id))}else{if(k.role==="answer")continue;{const m=k.text;let y=k.underlinedWords.map(C=>{const R=m.indexOf(C.text);return R>=0?{start:R,end:R+C.text.length,cue:C.cue}:null}).filter(C=>C!==null);y.length===0&&k.randomPick&&(y=[{start:k.randomPick.start,end:k.randomPick.end}]),c.push({type:"hhh",sourceText:m,sentenceStart:0,sentenceEnd:m.length,underlinedWords:y,cue:k.cue}),t.push(k.id)}}return c},hideAnswers:()=>{for(const c of e.highlights)if(c.role==="answer")for(const g of c.spans){g.dataset.ttOriginal=g.innerHTML;const u="•".repeat(Math.min(c.text.length,12));g.innerHTML=`<span style="letter-spacing:2px;color:${l.violet};font-weight:bold">${u}</span>`}},hideUnderlinedWords:()=>{for(const c of e.highlights)if(c.role==="sentence")if(c.underlinedWords.length>0)for(const g of c.underlinedWords){g.span.dataset.ttOriginal=g.span.innerHTML;const u="•".repeat(Math.min(g.text.length,8));g.span.innerHTML=`<span style="letter-spacing:2px;color:${l.violet};font-weight:bold">${u}</span>`}else{const g=[];for(const u of c.spans){const S=we(u),k=/[\p{L}\p{M}'']+/gu;let m;for(;(m=k.exec(S))!==null;)g.push({span:u,text:S,localStart:m.index,localEnd:m.index+m[0].length,word:m[0]})}if(g.length>0){const u=g[Math.floor(Math.random()*g.length)],k=c.text.indexOf(u.word);c.randomPick={text:u.word,start:k>=0?k:0,end:k>=0?k+u.word.length:u.word.length},u.span.dataset.ttOriginal=u.span.innerHTML,u.span.dataset.ttRandomStart=String(u.localStart),u.span.dataset.ttRandomEnd=String(u.localEnd);const m=ae(u.text.slice(0,u.localStart)),y="•".repeat(Math.min(u.word.length,8)),C=ae(u.text.slice(u.localEnd));u.span.innerHTML=`${m}<span style="letter-spacing:2px;color:${l.violet};font-weight:bold">${y}</span>${C}`}}},revealWord:(c,g)=>{var k;const u=g!=null?t[g]:void 0,S=u?e.highlights.filter(m=>m.id===u):e.highlights;for(const m of S){for(const y of m.underlinedWords)if((y.text.replace(/^[.,;:!?'"()\-–—\s]+|[.,;:!?'"()\-–—\s]+$/g,"")===c||y.text===c)&&y.span.dataset.ttOriginal){y.span.innerHTML=`<span style="color:${l.greenInk};font-weight:bold">${y.span.dataset.ttOriginal}</span>`;return}if(m.role==="sentence"&&((k=m.randomPick)==null?void 0:k.text)===c){for(const y of m.spans)if(y.dataset.ttOriginal&&y.dataset.ttRandomStart){const C=parseInt(y.dataset.ttRandomStart,10),R=parseInt(y.dataset.ttRandomEnd,10),O=document.createElement("span");O.innerHTML=y.dataset.ttOriginal;const q=O.textContent||"",a=ae(q.slice(0,C)),x=ae(q.slice(C,R)),p=ae(q.slice(R));y.innerHTML=`${a}<span style="color:${l.greenInk};font-weight:bold">${x}</span>${p}`;return}}if(m.role==="answer"&&mt(m.text)===c){for(const y of m.spans)y.dataset.ttOriginal&&(y.innerHTML=`<span style="color:${l.greenInk};font-weight:bold">${y.dataset.ttOriginal}</span>`);return}}},showAnswers:()=>{for(const c of e.highlights){for(const g of c.underlinedWords)g.span.dataset.ttOriginal&&(g.span.innerHTML=g.span.dataset.ttOriginal,delete g.span.dataset.ttOriginal);for(const g of c.spans)g.dataset.ttOriginal&&(g.innerHTML=g.dataset.ttOriginal,delete g.dataset.ttOriginal,delete g.dataset.ttRandomStart,delete g.dataset.ttRandomEnd);delete c.randomPick}},destroy:()=>{for(const c of[...e.highlights])i(c.id);e.highlights=[],document.removeEventListener("mouseup",L,!0)}}}let wt=1;function vt(e){return Array.from(e).filter(t=>/[\p{L}\p{M}'''\-\s]/u.test(t)).join("")}function Y(){const e=window.getSelection();e&&(window.__tiptongClearing=!0,e.removeAllRanges(),window.__tiptongClearing=!1)}function W(e){try{return e.startContainer.isConnected&&e.endContainer.isConnected}catch{return!1}}function yt(e){let t=e.nodeType===Node.ELEMENT_NODE?e:e.parentElement;for(;t;){if(t.id||t.hasAttribute("data-page")||t.hasAttribute("data-chapter")||t.tagName==="ARTICLE"||t.tagName==="MAIN"||t.tagName==="SECTION")return t;t=t.parentElement}return document.body}function kt(e){if(e===document.body)return"body";if(e.id)return`#${CSS.escape(e.id)}`;const t=[];let n=e;for(;n&&n!==document.body;){if(n.id){t.unshift(`#${CSS.escape(n.id)}`);break}const o=n.parentElement;if(!o)break;const r=Array.from(o.children).indexOf(n);t.unshift(`${n.tagName.toLowerCase()}:nth-child(${r+1})`),n=o}return t.join(" > ")||"body"}function Le(e,t,n){const o=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);let r=0,s;for(;s=o.nextNode();){if(s===t)return r+n;r+=(s.textContent||"").length}return r+n}function de(e){const t=yt(e.commonAncestorContainer);return{ancestorSelector:kt(t),charStart:Le(t,e.startContainer,e.startOffset),charEnd:Le(t,e.endContainer,e.endOffset),text:e.toString()}}function ue(e){const t=document.querySelector(e.ancestorSelector);if(!t)return null;const n=document.createTreeWalker(t,NodeFilter.SHOW_TEXT);let o=0,r=null,s=0,i=null,d=0,b;for(;b=n.nextNode();){const h=(b.textContent||"").length;if(!r&&o+h>e.charStart&&(r=b,s=e.charStart-o),!i&&o+h>=e.charEnd){i=b,d=e.charEnd-o;break}o+=h}if(!r||!i)return null;try{const h=document.createRange();return h.setStart(r,s),h.setEnd(i,d),e.text&&h.toString()!==e.text?(console.warn("[TipTong] Re-anchored range text mismatch, skipping"),null):h}catch{return null}}function $t(e){const t=document.caretRangeFromPoint(e.clientX,e.clientY);if(!t||t.startContainer.nodeType!==Node.TEXT_NODE)return null;const n=t.startContainer,o=n.textContent||"",r=t.startOffset;if(r>=o.length||o[r]===" "||o[r]===`
`)return null;let s=r;for(;s>0&&o[s-1]!==" "&&o[s-1]!==`
`;)s--;let i=r;for(;i<o.length&&o[i]!==" "&&o[i]!==`
`;)i++;const d=document.createRange();return d.setStart(n,s),d.setEnd(n,i),d}function St(e){if(e.startContainer.nodeType===Node.TEXT_NODE){const t=e.startContainer.textContent||"";let n=e.startOffset;for(;n>0&&t[n-1]!==" "&&t[n-1]!==`
`;)n--;e.setStart(e.startContainer,n)}if(e.endContainer.nodeType===Node.TEXT_NODE){const t=e.endContainer.textContent||"";let n=e.endOffset;for(;n<t.length&&t[n]!==" "&&t[n]!==`
`;)n++;e.setEnd(e.endContainer,n)}}function Re(e,t,n){try{const o=document.createRange();return o.setStart(e,t),o.collapse(!0),n.compareBoundaryPoints(Range.START_TO_START,o)<=0&&n.compareBoundaryPoints(Range.END_TO_END,o)>=0}catch{return!1}}function Ie(e,t){try{return e.compareBoundaryPoints(Range.START_TO_END,t)>0&&e.compareBoundaryPoints(Range.END_TO_START,t)<0}catch{return!1}}function ve(e,t){try{return e.compareBoundaryPoints(Range.START_TO_START,t)}catch{return 0}}const ye="tt-css-overlay",Ae=4;function Et(e){if(e.length===0)return[];const t=Array.from(e).sort((r,s)=>r.top-s.top||r.left-s.left),n=[];let o=t[0];for(let r=1;r<t.length;r++){const s=t[r];if(Math.abs(s.top-o.top)<2){const i=Math.min(o.left,s.left),d=Math.max(o.right,s.right),b=Math.min(o.top,s.top),h=Math.max(o.bottom,s.bottom);o=new DOMRect(i,b,d-i,h-b)}else n.push(o),o=s}return n.push(o),n}let He=!1;function Me(){if(He)return;He=!0;let e=0;const t=()=>{e||(e=requestAnimationFrame(()=>{e=0,document.querySelectorAll(`.${ye}, .${he}`).forEach(n=>{var o;(o=n.__ttRelayout)==null||o.call(n)})}))};document.addEventListener("scroll",t,!0),window.addEventListener("resize",t)}function Ne(e,t,n){const o=document.createElement("div");o.className=ye,o.style.cssText="position: absolute; top: 0; left: 0; pointer-events: none; z-index: 999;";const r=()=>{o.textContent="";const s=e.getClientRects();let i;if(s.length>0)i=Et(s);else{const h=e.getBoundingClientRect();i=h.width===0&&h.height===0?[]:[h]}if(i.length===0){o.style.display="none";return}o.style.display="";const d=window.scrollX,b=window.scrollY;for(let h=0;h<i.length;h++){const $=i[h];let T="8px";i.length>1&&(T=h===0?"8px 8px 0 0":h===i.length-1?"0 0 8px 8px":"0");const L=document.createElement("div");L.style.cssText=`
        position: absolute;
        top: ${$.top+b}px;
        left: ${$.left+d-Ae}px;
        width: ${$.width+Ae*2}px;
        height: ${$.height}px;
        ${n}
        border-radius: ${T};
        display: flex;
        align-items: center;
        justify-content: center;
        pointer-events: none;
      `,h===0&&(L.textContent=t),o.appendChild(L)}};return r(),o.__ttRelayout=r,Me(),document.body.appendChild(o),o}function Ct(){document.querySelectorAll(`.${ye}`).forEach(e=>e.remove())}const he="tt-css-badge";function Oe(){document.querySelectorAll(`.${he}`).forEach(e=>e.remove())}function ke(e){if(Oe(),e.deleteMode)return;const t=e.highlights.filter(o=>o.role==="question"||o.role==="answer");for(const o of t){const r=o.ranges[0];if(!r||!W(r))continue;const s=r.getClientRects(),i=s.length>0?s[0]:r.getBoundingClientRect();if(i.width===0&&i.height===0)continue;const d=document.createElement("div");d.className=he;const b=o.role==="answer";d.textContent=b?"A":"Q",d.style.cssText=`
      position: absolute;
      top: ${i.top+window.scrollY-8}px;
      left: ${i.left+window.scrollX-8}px;
      width: 18px;
      height: 18px;
      background: ${b?l.green:l.violet};
      color: ${b?l.dark:"white"};
      font-size: ${_.small};
      font-weight: bold;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      pointer-events: none;
      z-index: 1000;
      line-height: 1;
    `,d.__ttRelayout=()=>{const h=r.getClientRects(),$=h.length>0?h[0]:r.getBoundingClientRect();d.style.display=$.width===0&&$.height===0?"none":"flex",d.style.top=`${$.top+window.scrollY-8}px`,d.style.left=`${$.left+window.scrollX-8}px`},document.body.appendChild(d)}const n=[];for(const o of e.highlights){o.cue&&o.ranges[0]&&n.push({range:o.ranges[0],cue:o.cue});for(const r of o.underlinedWords)r.cue&&n.push({range:r.range,cue:r.cue})}for(const o of n){if(!W(o.range))continue;const r=document.createElement("div");r.className=he,r.textContent="✎",r.title=`My cue: ${o.cue}`,r.style.cssText=`
      position: absolute;
      width: 16px;
      height: 16px;
      background: ${l.violet};
      color: white;
      font-size: 10px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      pointer-events: none;
      z-index: 1000;
      line-height: 1;
    `;const s=()=>{const i=o.range.getClientRects(),d=i.length>0?i[0]:o.range.getBoundingClientRect();r.style.display=d.width===0&&d.height===0?"none":"flex",r.style.top=`${d.top+window.scrollY-8}px`,r.style.left=`${d.right+window.scrollX-6}px`};s(),r.__ttRelayout=s,document.body.appendChild(r)}Me()}function K(e){if(typeof CSS>"u"||!("highlights"in CSS))return;const t=CSS.highlights,n=[],o=[],r=[],s=[],i=[];for(const d of e.highlights){const b=e.deleteMode?i:d.role==="answer"?o:d.role==="question"?n:r;for(const h of d.ranges)W(h)&&b.push(h);for(const h of d.underlinedWords)!e.deleteMode&&W(h.range)&&s.push(h.range)}t.delete("tt-question"),t.delete("tt-answer"),t.delete("tt-sentence"),t.delete("tt-underline"),t.delete("tt-delete");try{n.length>0&&t.set("tt-question",new window.Highlight(...n)),o.length>0&&t.set("tt-answer",new window.Highlight(...o)),r.length>0&&t.set("tt-sentence",new window.Highlight(...r)),s.length>0&&t.set("tt-underline",new window.Highlight(...s)),i.length>0&&t.set("tt-delete",new window.Highlight(...i))}catch(d){console.warn("[TipTong] CSS Highlight API error:",d)}ke(e)}function Tt(){oe(),ut();const e={mode:"hhh",highlights:[],deleteMode:!1},t=[];let n=[],o=null;function r(){let a=!1;for(const x of e.highlights){for(let p=0;p<x.ranges.length;p++)if(!W(x.ranges[p])&&x.anchors[p]){const w=ue(x.anchors[p]);w&&(x.ranges[p]=w,a=!0)}for(let p=0;p<x.underlinedWords.length;p++){const w=x.underlinedWords[p];if(!W(w.range)&&w.anchor){const v=ue(w.anchor);v&&(w.range=v,a=!0)}}}a&&K(e)}function s(){o&&clearTimeout(o),o=setTimeout(r,100)}const i=new MutationObserver(a=>{if(e.highlights.length===0)return;a.some(p=>p.type==="childList"&&(p.addedNodes.length>0||p.removedNodes.length>0))&&s()});i.observe(document.body,{childList:!0,subtree:!0});let d=null;document.addEventListener("mouseup",()=>{const a=window.getSelection();a&&!a.isCollapsed&&a.rangeCount>0?(d=a.getRangeAt(0).cloneRange(),Y()):d=null},!0);function b(a,x){for(const p of e.highlights){for(const w of p.ranges)if(Re(a,x,w))return p;for(const w of p.underlinedWords)if(Re(a,x,w.range))return p}return null}function h(a){for(const x of e.highlights)for(const p of x.ranges)if(Ie(a,p))return x;return null}function $(){const a=d;if(d=null,!a)return;if(e.deleteMode)if(a.toString().trim().length>0)e.deleteMode=!1,K(e);else return;if(!a.toString().trim())return;const p=document.getElementById("tt-toolbar"),w=document.getElementById("tt-popup");if(p!=null&&p.contains(a.startContainer)){Y();return}if(w!=null&&w.contains(a.startContainer)){Y();return}St(a);const v=a.toString().trim();if(!v){Y();return}const f=b(a.startContainer,a.startOffset),E=b(a.endContainer,a.endOffset);if(f&&f===E){if(e.mode==="hhh"&&f.role==="sentence"){Y();return}Y();return}const I=f||E||h(a);if(I){T(I,a),Y(),K(e);return}if(e.mode==="hhh"&&v.split(/\s+/).filter(Boolean).length<2){Y();return}const M=e.highlights.filter(ce=>ce.role!=="sentence").length,j=e.mode==="qa"?M%2===0?"question":"answer":"sentence",Z=`tt-css-${wt++}`,ne=de(a),P={id:Z,text:v,role:j,ranges:[a],anchors:[ne],underlinedWords:[]};e.highlights.push(P),Y(),K(e)}function T(a,x){try{const p=[...a.ranges,x];let w=p[0],v=p[0];for(const E of p)E.compareBoundaryPoints(Range.START_TO_START,w)<0&&(w=E),E.compareBoundaryPoints(Range.END_TO_END,v)>0&&(v=E);const f=document.createRange();f.setStart(w.startContainer,w.startOffset),f.setEnd(v.endContainer,v.endOffset),a.ranges=[f],a.anchors=[de(f)],a.text=f.toString().trim(),a.underlinedWords=[]}catch{}}function L(a,x){const p=$t(x);if(!p)return;const w=p.toString().trim();if(!w)return;const v=a.underlinedWords.findIndex(f=>{try{return Ie(f.range,p)||f.text===w}catch{return f.text===w}});if(v>=0)a.underlinedWords.splice(v,1);else{const f=a.text.split(/\s+/).filter(Boolean).length,E=Math.floor(f/2);if(a.underlinedWords.length>=E)return;const I=p.cloneRange();a.underlinedWords.push({text:w,range:I,anchor:de(I)})}K(e)}function c(a){const x=e.highlights.find(w=>w.id===a);if(!x)return;const p=new Set([a]);if(x.role==="question"||x.role==="answer"){const w=e.highlights.filter(I=>I.role!=="sentence"),v=w.findIndex(I=>I.id===a),E=v%2===0?v+1:v-1;E>=0&&E<w.length&&p.add(w[E].id)}e.highlights=e.highlights.filter(w=>!p.has(w.id)),e.highlights.length===0&&(e.deleteMode=!1),K(e)}let g=0;function u(a){var ne;if(e.deleteMode)return;const x=document.getElementById("tt-toolbar"),p=document.getElementById("tt-popup");if(x!=null&&x.contains(a.target)||p!=null&&p.contains(a.target)||(ne=document.getElementById("tt-cue-overlay"))!=null&&ne.contains(a.target))return;const w=document.caretRangeFromPoint(a.clientX,a.clientY);if(!w)return;const v=b(w.startContainer,w.startOffset);if(!v)return;const f=v.underlinedWords.find(P=>{try{return W(P.range)&&P.range.comparePoint(w.startContainer,w.startOffset)===0}catch{return!1}}),E=a.clientX,I=a.clientY;let M=setTimeout(()=>{M=null,g=Date.now()+600,Y(),_e({context:f?f.text:v.text,scope:f?"word":"exercise",initial:(f?f.cue:v.cue)??"",onSave:P=>{f?f.cue=P:v.cue=P,ke(e)},onRemove:()=>{f?f.cue=void 0:v.cue=void 0,ke(e)}})},500);const j=()=>{M&&(clearTimeout(M),M=null),document.removeEventListener("pointermove",Z),document.removeEventListener("pointerup",j)},Z=P=>{Math.hypot(P.clientX-E,P.clientY-I)>8&&j()};document.addEventListener("pointermove",Z),document.addEventListener("pointerup",j)}function S(a){var E,I;if(Date.now()<g){a.preventDefault(),a.stopPropagation();return}const x=document.getElementById("tt-toolbar"),p=document.getElementById("tt-popup");if(x!=null&&x.contains(a.target)||p!=null&&p.contains(a.target))return;const w=document.caretRangeFromPoint(a.clientX,a.clientY);if(!w)return;const v=b(w.startContainer,w.startOffset);if(!v)return;if(e.deleteMode){if(a.preventDefault(),a.stopPropagation(),v.role==="sentence"){const M=v.underlinedWords.findIndex(j=>{try{return W(j.range)&&j.range.comparePoint(w.startContainer,w.startOffset)===0}catch{return!1}});if(M>=0){v.underlinedWords.splice(M,1),K(e);return}}c(v.id);return}if(e.mode==="hhh"&&v.role==="sentence"){const M=window.getSelection();if(M&&!M.isCollapsed)return;a.preventDefault(),a.stopPropagation(),L(v,a)}((I=(E=a.target).closest)==null?void 0:I.call(E,"a"))&&v&&(a.preventDefault(),a.stopPropagation())}const k=()=>setTimeout($,10);document.addEventListener("mouseup",k,!0),document.addEventListener("click",S,!0),document.addEventListener("pointerdown",u,!0);function m(a,x){const p="•".repeat(Math.min(x.length,12)),w=Ne(a,p,`background: white; color: ${l.violet}; font-weight: bold; letter-spacing: 2px; font-size: inherit; box-shadow: 0 1px 4px rgba(0,0,0,0.1);`);return t.push(w),w}function y(a,x){const p=Ne(a,x,`background: white; color: ${l.greenInk}; font-weight: bold; font-size: inherit; box-shadow: 0 1px 4px rgba(0,0,0,0.1);`);return t.push(p),p}function C(){for(const a of t)a.remove();t.length=0,Ct()}function R(a){const x=a.ranges[0];if(!x||!W(x))return null;const p=[],w=O(x);let v=0;for(const Z of w){const ne=Z.textContent||"",P=Z===x.startContainer?x.startOffset:0,ce=Z===x.endContainer?x.endOffset:ne.length,at=ne.slice(P,ce),xn=/[\p{L}\p{M}'']+/gu;let ie;for(;(ie=xn.exec(at))!==null;)p.push({word:ie[0],node:Z,localStart:P+ie.index,localEnd:P+ie.index+ie[0].length,hlTextOffset:v+ie.index});v+=at.length}if(p.length===0)return null;const f=p[Math.floor(Math.random()*p.length)],E=document.createRange();try{E.setStart(f.node,f.localStart),E.setEnd(f.node,f.localEnd)}catch{return null}const I=a.text.indexOf(f.word,f.hlTextOffset>0?f.hlTextOffset-1:0),M=I>=0?I:f.hlTextOffset,j=M+f.word.length;return{text:f.word,start:M,end:j,range:E}}function O(a){const x=a.commonAncestorContainer,p=[];if(x.nodeType===Node.TEXT_NODE)p.push(x);else{const w=document.createTreeWalker(x,NodeFilter.SHOW_TEXT);let v;for(;v=w.nextNode();){try{const f=document.createRange();if(f.selectNodeContents(v),a.compareBoundaryPoints(Range.START_TO_END,f)>0||a.compareBoundaryPoints(Range.END_TO_START,f)<0)continue}catch{continue}p.push(v)}}return p}function q(a,x){const p=O(a);for(const w of p){const f=(w.textContent||"").indexOf(x);if(f>=0)try{const E=document.createRange();return E.setStart(w,f),E.setEnd(w,f+x.length),E}catch{continue}}return null}return{getSelections:()=>e.highlights.map(a=>({id:a.id,text:a.text,role:a.role,underlinedCount:a.underlinedWords.length})),validate:()=>{const a=[];return e.highlights.filter(p=>p.role!=="sentence").length%2!==0&&a.push("Last question needs an answer"),a},getMode:()=>e.mode,setMode:a=>{e.mode=a,e.deleteMode&&(e.deleteMode=!1),K(e)},toggleDeleteMode:()=>(e.deleteMode=!e.deleteMode,K(e),e.deleteMode),isDeleteMode:()=>e.deleteMode,getQAPairs:()=>{const a=e.highlights.filter(p=>p.role!=="sentence"),x=[];for(let p=0;p+1<a.length;p+=2)x.push({question:a[p].text,answer:a[p+1].text});return x},getHHHData:()=>e.highlights.filter(x=>x.role==="sentence").map(x=>{const p=x.text,w=x.underlinedWords.map(v=>{const f=p.indexOf(v.text);return f>=0?{start:f,end:f+v.text.length}:null}).filter(v=>v!==null);return{sourceText:p,sentenceStart:0,sentenceEnd:p.length,underlinedWords:w}}),getOrderedExerciseData:()=>{const a=[];n=[];const x=[...e.highlights].sort((v,f)=>{const E=v.ranges[0],I=f.ranges[0];return!E||!I?0:ve(E,I)}),p=x.filter(v=>v.role!=="sentence"),w=new Set;for(const v of x)if(v.role==="question"){const f=p.indexOf(v),E=Math.floor(f/2);if(w.has(E))continue;const I=p[f+1];I&&(w.add(E),a.push({type:"qa",question:v.text,answer:I.text,cue:v.cue??I.cue}),n.push(I.id))}else{if(v.role==="answer")continue;{const f=v.text;let E=v.underlinedWords.map(I=>{const M=f.indexOf(I.text);return M>=0?{start:M,end:M+I.text.length,cue:I.cue}:null}).filter(I=>I!==null);E.length===0&&v.randomPick&&(E=[{start:v.randomPick.start,end:v.randomPick.end}]),a.push({type:"hhh",sourceText:f,sentenceStart:0,sentenceEnd:f.length,underlinedWords:E,cue:v.cue}),n.push(v.id)}}return a},hideAnswers:()=>{for(const a of e.highlights)if(a.role==="answer"){for(const x of a.ranges)if(W(x))try{m(x,a.text)}catch(p){console.warn("[TipTong] hideAnswers overlay error:",p)}}},hideUnderlinedWords:()=>{for(const a of e.highlights)if(a.role==="sentence")if(a.underlinedWords.length>0){const x=a.underlinedWords.filter(w=>W(w.range)).sort((w,v)=>ve(w.range,v.range)),p=[];for(const w of x){const v=p[p.length-1];if(v){const f=v.range.getBoundingClientRect(),E=w.range.getBoundingClientRect();if(Math.abs(f.top-E.top)<2&&E.left-f.right<f.height){const M=document.createRange();M.setStart(v.range.startContainer,v.range.startOffset),M.setEnd(w.range.endContainer,w.range.endOffset),v.range=M,v.text+=" "+w.text;continue}}p.push({range:w.range.cloneRange(),text:w.text})}for(const w of p)try{m(w.range,w.text)}catch(v){console.warn("[TipTong] hideUnderlinedWords overlay error:",v)}}else{const x=R(a);if(x){a.randomPick={text:x.text,start:x.start,end:x.end,range:x.range,anchor:de(x.range)};try{m(x.range,x.text)}catch(p){console.warn("[TipTong] hideRandom overlay error:",p)}}}},revealWord:(a,x)=>{var v;const p=x!=null?n[x]:void 0,w=p?e.highlights.filter(f=>f.id===p):e.highlights;for(const f of w){for(const E of f.underlinedWords)if(E.text.replace(/^[.,;:!?'"()\-–—\s]+|[.,;:!?'"()\-–—\s]+$/g,"")===a||E.text===a){W(E.range)&&y(E.range,E.text);return}if(f.underlinedWords.length>1&&f.role==="sentence"){const E=[...f.underlinedWords].filter(M=>W(M.range)).sort((M,j)=>ve(M.range,j.range)),I=E.map(M=>M.text.replace(/^[.,;:!?'"()\-–—\s]+|[.,;:!?'"()\-–—\s]+$/g,"")).join(" ");if(I===a||I.includes(a)){for(const M of E)W(M.range)&&y(M.range,M.text);return}}if(f.role==="sentence"&&((v=f.randomPick)==null?void 0:v.text)===a){let E=f.randomPick.range;if(E&&!W(E)&&f.randomPick.anchor&&(E=ue(f.randomPick.anchor)??void 0,E&&(f.randomPick.range=E)),E&&W(E)){y(E,a);return}const I=f.ranges[0];if(I&&W(I)){const M=q(I,a);if(M){y(M,a);return}}}if(f.role==="answer"&&vt(f.text)===a){for(let E=0;E<f.ranges.length;E++){let I=f.ranges[E];if(!W(I)&&f.anchors[E]){const M=ue(f.anchors[E]);M&&(f.ranges[E]=M,I=M)}W(I)&&y(I,f.text)}return}}},showAnswers:()=>{C();for(const a of e.highlights)delete a.randomPick},destroy:()=>{if(C(),Oe(),i.disconnect(),o&&clearTimeout(o),e.highlights=[],e.deleteMode=!1,typeof CSS<"u"&&"highlights"in CSS){const a=CSS.highlights;a.delete("tt-question"),a.delete("tt-answer"),a.delete("tt-sentence"),a.delete("tt-underline"),a.delete("tt-delete")}document.removeEventListener("mouseup",k,!0),document.removeEventListener("click",S,!0),document.removeEventListener("pointerdown",u,!0)}}}var D=(e=>(e.CHARACTER_PLACEHOLDERS="CHARACTER_PLACEHOLDERS",e.NEXT_LETTER="NEXT_LETTER",e.ALL_VOWELS="ALL_VOWELS",e.ALL_CONSONANTS="ALL_CONSONANTS",e.SHUFFLED_LETTERS="SHUFFLED_LETTERS",e.RANDOM_LETTER="RANDOM_LETTER",e.HANGMAN="HANGMAN",e.FIRST_CONSONANT="FIRST_CONSONANT",e.FIRST_VOWEL="FIRST_VOWEL",e.CONSONANT_LIST="CONSONANT_LIST",e.SELF_AUTHORED="SELF_AUTHORED",e))(D||{});function ge(e){return e.normalize("NFD").replace(/[\u0300-\u036f]/g,"")}const pe=new Set(["a","e","i","o","u","y"]);function qe(e){const t=[...e];for(let n=t.length-1;n>0;n--){const o=Math.floor(Math.random()*(n+1));[t[n],t[o]]=[t[o],t[n]]}return t}function $e(e){return e>0?100/e:0}function _t(e,t){let n=0;for(let o=0;o<e.length;o++)t.has(o)&&n++;return n}const Lt={id:D.CHARACTER_PLACEHOLDERS,label:"Show length",icon:"📏",iconName:"ruler",description:"Shows how many characters the word has",repeatable:!1,autoRevealsLength:!0,revealsPositions:!1,costType:"free",modality:"text",group:"reveal",apply(e,t){return{type:this.id,revealedIndices:[],cost:0}}},Rt={id:D.NEXT_LETTER,label:"Next letter",icon:"➡️",iconName:"arrow-right",description:"Reveals the next unrevealed letter from left to right",repeatable:!0,autoRevealsLength:!1,revealsPositions:!0,costType:"per-letter",modality:"text",group:"reveal",apply(e,t){for(let n=0;n<e.length;n++)if(!t.has(n))return{type:this.id,revealedIndices:[n],cost:$e(e.length)};return{type:this.id,revealedIndices:[],cost:0}}},It={id:D.ALL_VOWELS,label:"Vowels",icon:"🔤",iconName:"vowels",description:"Reveals all vowels (a, e, i, o, u, y — including accented)",repeatable:!1,autoRevealsLength:!0,revealsPositions:!0,costType:"proportional",modality:"text",group:"reveal",apply(e,t){const n=e.toLowerCase(),o=[];for(let r=0;r<e.length;r++)pe.has(ge(n[r]))&&!t.has(r)&&o.push(r);return{type:this.id,revealedIndices:o,cost:e.length>0?o.length/e.length*100:0}}},At={id:D.ALL_CONSONANTS,label:"Consonants",icon:"🔡",iconName:"consonants",description:"Reveals all consonants (including accented like ç, ñ)",repeatable:!1,autoRevealsLength:!0,revealsPositions:!0,costType:"proportional",modality:"text",group:"reveal",apply(e,t){const n=e.toLowerCase(),o=[];for(let r=0;r<e.length;r++)!pe.has(ge(n[r]))&&!t.has(r)&&o.push(r);return{type:this.id,revealedIndices:o,cost:e.length>0?o.length/e.length*100:0}}},Ht={id:D.SHUFFLED_LETTERS,label:"Shuffle",icon:"🔀",iconName:"shuffle",description:"Shuffles the letters within each word (doesn't reveal positions)",repeatable:!0,autoRevealsLength:!0,revealsPositions:!1,costType:"flat",flatCost:40,modality:"text",group:"reorder",apply(e,t){const n=e.length-_t(e,t);if(n===0)return{type:this.id,revealedIndices:[],cost:0};const o=e.split(" ").map(r=>qe(r.split("")).join("")).join(" ");return{type:this.id,revealedIndices:[],cost:40*(n/e.length),displayData:o}}},Mt={id:D.RANDOM_LETTER,label:"Random",icon:"🎲",iconName:"dice",description:"Reveals one random unrevealed letter",repeatable:!0,autoRevealsLength:!0,revealsPositions:!0,costType:"per-letter",modality:"text",group:"reveal",apply(e,t){const n=[];for(let r=0;r<e.length;r++)t.has(r)||n.push(r);if(n.length===0)return{type:this.id,revealedIndices:[],cost:0};const o=n[Math.floor(Math.random()*n.length)];return{type:this.id,revealedIndices:[o],cost:$e(e.length)}}},Nt={id:D.HANGMAN,label:"Structure",icon:"␣",iconName:"slots",description:"Shows the word breaks and punctuation, with a slot for each letter",repeatable:!1,autoRevealsLength:!0,revealsPositions:!0,costType:"proportional",modality:"text",group:"reveal",apply(e,t){const n=[];for(let o=0;o<e.length;o++){const r=e[o];!/[\p{L}\p{N}]/u.test(r)&&!t.has(o)&&n.push(o)}return{type:this.id,revealedIndices:n,cost:e.length>0?n.length/e.length*100:0}}};function We(e,t){return(n,o)=>{const r=n.toLowerCase();for(let s=0;s<n.length;s++){const i=ge(r[s]);if(/[a-z]/.test(i)&&pe.has(i)===t&&!o.has(s))return{type:e,revealedIndices:[s],cost:$e(n.length)}}return{type:e,revealedIndices:[],cost:0}}}const Ot={id:D.FIRST_CONSONANT,label:"Consonant",icon:"🔡",iconName:"consonant",description:"Reveals the first consonant, then each following one",repeatable:!0,autoRevealsLength:!1,revealsPositions:!0,costType:"per-letter",modality:"text",group:"reveal",apply(e,t){return We(D.FIRST_CONSONANT,!1)(e,t)}},qt={id:D.FIRST_VOWEL,label:"Vowel",icon:"🔤",iconName:"vowel",description:"Reveals the first vowel, then each following one",repeatable:!0,autoRevealsLength:!1,revealsPositions:!0,costType:"per-letter",modality:"text",group:"reveal",apply(e,t){return We(D.FIRST_VOWEL,!0)(e,t)}},Wt={id:D.CONSONANT_LIST,label:"Consonant list",icon:"🔡",iconName:"list",description:"Lists the consonants you still need in random order, without their positions",repeatable:!1,autoRevealsLength:!1,revealsPositions:!1,costType:"proportional",modality:"text",group:"reorder",apply(e,t){const n=e.toLowerCase(),o=[];for(let r=0;r<e.length;r++){if(t.has(r))continue;const s=n[r],i=ge(s);/[a-z]/.test(i)&&!pe.has(i)&&o.push(s)}return o.length===0?{type:this.id,revealedIndices:[],cost:0}:{type:this.id,revealedIndices:[],cost:e.length>0?o.length/e.length*50:0,displayData:qe(o).join(" ")}}},Se=[{id:D.SELF_AUTHORED,label:"My cue",icon:"✎",iconName:"pen",description:"Shows a cue you wrote yourself when creating this exercise",repeatable:!0,autoRevealsLength:!1,revealsPositions:!1,costType:"flat",flatCost:10,modality:"text",group:"reveal",apply(e,t){return{type:this.id,revealedIndices:[],cost:10}}},Lt,Rt,Mt,It,qt,At,Ot,Wt,Ht],Dt=[...Se,Nt];function re(e){const t=Dt.find(n=>n.id===e);if(!t)throw new Error(`Unknown hint type: ${e}`);return t}function zt(e,t,n=new Set){return re(t).apply(e,n)}function Ee(e){const t=e.reduce((n,o)=>n+o.cost,0);return Math.min(t,100)}function De(e,t,n){return e.apply(t,new Set(n))}function ze(e,t,n){return De(e,t,n).cost}function Pt(e,t,n,o={}){if(t.length===0)return!1;if(e.id===D.CHARACTER_PLACEHOLDERS)return o.lengthAlreadyKnown!==!0;if(e.id===D.SELF_AUTHORED)return o.remainingCues===void 0||o.remainingCues>0;const r=De(e,t,n);return r.revealedIndices.length>0||r.displayData!==void 0}function Bt(e,t){return(e??[]).slice(t)}let Pe="strict";function fe(){return Pe}function Ft(e){return e.normalize("NFD").replace(/[̀-ͯ]/g,"")}function Be(e,t){const n=e.toLowerCase();return t==="strict"?n:Ft(n)}function me(e,t,n=Pe){return t===""?!1:Be(e,n)===Be(t,n)}function le(e,t=fe()){const n=new Set;return e.blanks.forEach((o,r)=>{(o.revealed||me(o.expected,o.actual,t))&&n.add(r)}),n}function Fe(e){return{exercise:e,hintUsages:[],isComplete:!1,shuffledLettersMap:{}}}function jt(e){return e.blanks.map(t=>t.actual).join("")}function Ut(e,t,n,o=fe()){const r=e.exercise.queries.find($=>$.id===t);if(!r)return e;const s=z(r,o);if(s.correct===s.total)return e;const i=r.blanks.map(($,T)=>{const L=n[T]??"";return $.revealed&&L!==""&&!me($.expected,L,o)?{...$,actual:L,revealed:!1}:{...$,actual:L}}),d={...r,blanks:i},b=e.exercise.queries.map($=>$.id===t?d:$),h={...e.exercise,queries:b};return{...e,exercise:h,isComplete:Ce(h)}}function Qt(e,t,n){const o=e.exercise.queries.find(c=>c.id===t);if(!o)return e;const r=re(n),s=le(o);if(!r.repeatable&&e.hintUsages.some(g=>g.queryId===t&&g.type===n))return e;const i=zt(o.answer,n,s);if(r.id!==D.CHARACTER_PLACEHOLDERS&&i.revealedIndices.length===0&&!i.displayData&&i.cost===0)return e;const d=o.blanks.map((c,g)=>i.revealedIndices.includes(g)?{...c,revealed:!0}:c),b={...o,blanks:d},h=e.exercise.queries.map(c=>c.id===t?b:c),$={queryId:t,type:n,cost:i.cost,usedAt:new Date,displayData:i.displayData},T={...e.exercise,queries:h},L={...e.shuffledLettersMap};return i.displayData&&n==="SHUFFLED_LETTERS"&&(L[t]=i.displayData),{...e,exercise:T,hintUsages:[...e.hintUsages,$],isComplete:Ce(T),shuffledLettersMap:L}}function Xt(e,t,n){const o=e.exercise.queries.find($=>$.id===t);if(!o||n<0||n>=o.blanks.length||le(o).has(n))return e;const r=o.blanks.map(($,T)=>T===n?{...$,revealed:!0}:$),s={...o,blanks:r},i=e.exercise.queries.map($=>$.id===t?s:$),d=o.answer.length>0?100/o.answer.length:0,b={queryId:t,type:D.NEXT_LETTER,cost:d,usedAt:new Date},h={...e.exercise,queries:i};return{...e,exercise:h,hintUsages:[...e.hintUsages,b],isComplete:Ce(h)}}function Ce(e,t=fe()){return e.queries.every(n=>n.blanks.every(o=>me(o.expected,o.actual,t)))}function z(e,t=fe()){const n=e.blanks.length;return{correct:e.blanks.filter(r=>me(r.expected,r.actual,t)).length,total:n}}function je(){return Math.random().toString(36).substring(2,10)}function Yt(e){return Array.from(e).filter(t=>/[\p{L}\p{M}'''\-\s]/u.test(t)).join("")}function Vt(e){return e.split("").map(t=>({expected:t,actual:"",revealed:!1}))}function Gt(e){const t=e.match(/^[.,;:!?'"()\-–—\s]+/),n=t?t[0].length:0,o=e.match(/[.,;:!?'"()\-–—\s]+$/),r=o?o[0].length:0;return{cleaned:e.slice(n,e.length-r||void 0),leadingLen:n,trailingLen:r}}function Kt(e,t){if(e.length<=1)return e;const n=[...e].sort((r,s)=>r.start-s.start),o=[{...n[0]}];for(let r=1;r<n.length;r++){const s=n[r],i=o[o.length-1];t.slice(i.end,s.start).trim().length===0?i.end=s.end:o.push({...s})}return o}function Jt(e){if(!e.sentenceSelection||e.wordSelections.length===0)return null;const t=e.sourceText.slice(e.sentenceSelection.start,e.sentenceSelection.end),n=Kt(e.wordSelections,e.sourceText),o=[];let r=t;for(let s=n.length-1;s>=0;s--){const i=n[s],d=i.start-e.sentenceSelection.start,b=i.end-e.sentenceSelection.start,h=t.slice(d,b),{cleaned:$,leadingLen:T,trailingLen:L}=Gt(h),c=Yt($);if(c.length===0)continue;const g=d+T,u=b-L,S={id:je(),answer:c,blanks:Vt(c),startIndex:g,endIndex:u};o.unshift(S);const k="_".repeat(c.length);r=r.slice(0,g)+k+r.slice(u)}return o.length===0?null:{id:je(),type:"hhh",originalSentence:t,sentenceWithBlanks:r,queries:o,createdAt:new Date}}function Ue(){return Math.random().toString(36).substring(2,10)}function Zt(e){return Array.from(e).filter(t=>/[\p{L}\p{M}'''\-\s]/u.test(t)).join("")}function en(e){return e.split("").map(t=>({expected:t,actual:"",revealed:!1}))}function tn(e,t){const n=e.slice(t.question.start,t.question.end).trim(),o=Zt(e.slice(t.answer.start,t.answer.end).trim());if(n.length===0||o.length===0)return null;const r={id:Ue(),answer:o,blanks:en(o),startIndex:0,endIndex:o.length},s="_".repeat(o.length);return{id:Ue(),type:"qa",originalSentence:n,sentenceWithBlanks:s,queries:[r],createdAt:new Date}}const Qe=new Date("2026-09-28");function Xe(e){return e.split("").map(t=>({expected:t,actual:"",revealed:!1}))}function A(e,t,n){return{id:e,type:"qa",originalSentence:t,sentenceWithBlanks:"_".repeat(n.length),queries:[{id:`${e}-q1`,answer:n,blanks:Xe(n),startIndex:0,endIndex:n.length}],createdAt:Qe}}function nn(e,t){let n=0;for(;;){const o=e.indexOf(t,n);if(o<0)throw new Error(`Fixture error: "${t}" not found in "${e}"`);const r=e[o-1],s=e[o+t.length],i=d=>d!==void 0&&new RegExp("\\p{L}","u").test(d);if(!i(r)&&!i(s))return o;n=o+1}}function H(e,t,n){const o=n.map((s,i)=>{const d=nn(t,s);return{id:`${e}-q${i+1}`,answer:s,blanks:Xe(s),startIndex:d,endIndex:d+s.length}}).sort((s,i)=>s.startIndex-i.startIndex);let r=t;for(const s of o)r=r.slice(0,s.startIndex)+"_".repeat(s.answer.length)+r.slice(s.endIndex);return{id:e,type:"hhh",originalSentence:t,sentenceWithBlanks:r,queries:o,createdAt:Qe}}A("b1-nl-qa-1","Hoe noem je de persoon die brood en taarten bakt?","de bakker"),A("b1-nl-qa-2","Wat neem je mee als het regent?","een paraplu"),A("b1-nl-qa-3","Hoe noem je het gebouw waar je boeken kunt lenen?","de bibliotheek"),A("b1-nl-qa-4","Welk seizoen komt na de zomer?","de herfst"),A("b1-nl-qa-5","Hoe noem je de dokter die zieke dieren beter maakt?","de dierenarts"),A("b1-nl-qa-6","Hoe noem je het eerste eten van de dag?","het ontbijt"),A("b1-nl-qa-7","Hoe noem je de broer van je moeder?","de oom"),A("b1-nl-qa-8","Waar wacht je op de trein?","op het station"),A("b1-nl-qa-9","Hoe noem je iemand die in een restaurant kookt?","de kok"),A("b1-nl-qa-10","Hoe noem je het geld dat je elke maand verdient?","het salaris"),H("b1-nl-pres-1","Hallo, ik heet Thomas en ik ben dertig jaar oud.",["heet","oud"]),H("b1-nl-pres-2","Ik werk als verpleegkundige in een groot ziekenhuis in Antwerpen.",["verpleegkundige","ziekenhuis"]),H("b1-nl-pres-3","In het weekend ga ik graag wandelen in het bos met mijn hond.",["wandelen","hond"]),H("b1-nl-pres-4","Mijn grootste droom is om een lange reis door Azië te maken.",["droom","reis"]),H("b1-nl-pres-5","Daarom spaar ik elke maand een beetje geld voor die reis.",["spaar","geld"]),H("b1-nl-pres-6","Elke ochtend fiets ik in twintig minuten naar mijn werk.",["twintig minuten","werk"]),H("b1-nl-pres-7","Mijn zus woont in Gent en ik bezoek haar elke zondag.",["woont","elke zondag"]),H("b1-nl-pres-8","Op vrijdag kook ik graag verse soep met groenten uit de tuin.",["verse soep","tuin"]),H("b1-nl-pres-9","Volgend jaar wil ik een cursus Japans volgen voor mijn reis.",["cursus Japans","reis"]),H("b1-nl-pres-10","Mijn hond heet Max en hij wordt volgende maand vier jaar oud.",["volgende maand","vier jaar"]),A("b1-nl-opp-1","Wat is het tegenovergestelde van 'duur'?","goedkoop"),A("b1-nl-opp-2","Wat is het tegenovergestelde van 'groot'?","klein"),A("b1-nl-opp-3","Wat is het tegenovergestelde van 'snel'?","langzaam"),A("b1-nl-opp-4","Wat is het tegenovergestelde van 'makkelijk'?","moeilijk"),A("b1-nl-opp-5","Wat is het tegenovergestelde van 'vol'?","leeg"),A("b1-nl-opp-6","Wat is het tegenovergestelde van 'zwaar'?","licht"),A("b1-nl-opp-7","Wat is het tegenovergestelde van 'schoon'?","vuil"),A("b1-nl-opp-8","Wat is het tegenovergestelde van 'dichtbij'?","ver weg"),A("b1-nl-opp-9","Wat is het tegenovergestelde van 'beginnen'?","stoppen"),A("b1-nl-opp-10","Wat is het tegenovergestelde van 'vroeg'?","laat"),H("b1-nl-city-1","Vanochtend nemen we de trein naar het centrum van Amsterdam.",["de trein","centrum"]),H("b1-nl-city-2","Eerst drinken we koffie met appeltaart in een klein café aan de gracht.",["koffie","gracht"]),H("b1-nl-city-3","Daarna huren we fietsen om door het Vondelpark te rijden.",["huren","fietsen"]),H("b1-nl-city-4","In het museum bekijken we de beroemde schilderijen van Van Gogh.",["museum","beroemde schilderijen"]),H("b1-nl-city-5","Voor de lunch eten we een broodje haring bij een kraampje op de markt.",["broodje haring","markt"]),H("b1-nl-city-6","In de middag maken we een rondvaart door de oude grachten van de stad.",["rondvaart","oude grachten"]),H("b1-nl-city-7","We kopen souvenirs en verse kaas in een gezellige winkel.",["souvenirs","verse kaas"]),H("b1-nl-city-8","Het begint zacht te regenen, dus we schuilen onder een grote paraplu.",["regenen","grote paraplu"]),H("b1-nl-city-9","Voor het diner bestellen we pannenkoeken met stroop en poedersuiker.",["bestellen","pannenkoeken"]),H("b1-nl-city-10","Moe maar gelukkig nemen we de laatste trein terug naar huis.",["laatste trein","huis"]),A("b1-en-qa-1","What do you call the person who flies a plane?","a pilot"),A("b1-en-qa-2","What do you use to open a locked door?","a key"),A("b1-en-qa-3","What do you call the meal you eat in the morning?","breakfast"),A("b1-en-qa-4","Which season comes after winter?","spring"),A("b1-en-qa-5","What do you call the place where you watch films on a big screen?","the cinema"),A("b1-en-qa-6","What do you call the room where you cook your meals?","the kitchen"),A("b1-en-qa-7","What do you call your mother's brother?","your uncle"),A("b1-en-qa-8","Where do you wait for a train?","at the station"),A("b1-en-qa-9","What do you call a person who cooks in a restaurant?","a chef"),A("b1-en-qa-10","What do you call the money you earn every month?","a salary"),H("b1-en-pres-1","Hi, my name is Sarah and I am twenty-eight years old.",["name","old"]),H("b1-en-pres-2","I work as an engineer at a small software company in Manchester.",["engineer","company"]),H("b1-en-pres-3","Every morning I take the train to work and read a book on the way.",["train","book"]),H("b1-en-pres-4","My biggest dream is to open my own restaurant one day.",["dream","restaurant"]),H("b1-en-pres-5","That is why I save money every month and take cooking classes in the evening.",["save","cooking"]),H("b1-en-pres-6","Every evening I cook a new recipe from an old Italian cookbook.",["new recipe","cookbook"]),H("b1-en-pres-7","My brother lives in Leeds and I visit him every weekend.",["lives","every weekend"]),H("b1-en-pres-8","Next year I want to take a business course to learn about restaurants.",["business course","learn"]),H("b1-en-pres-9","My favourite dish is a simple pasta with fresh tomatoes and basil.",["favourite dish","fresh tomatoes"]),H("b1-en-pres-10","With a bit of luck I will open the doors of my restaurant in five years.",["doors","five years"]),A("b1-en-opp-1","What is the opposite of 'expensive'?","cheap"),A("b1-en-opp-2","What is the opposite of 'big'?","small"),A("b1-en-opp-3","What is the opposite of 'fast'?","slow"),A("b1-en-opp-4","What is the opposite of 'easy'?","difficult"),A("b1-en-opp-5","What is the opposite of 'full'?","empty"),A("b1-en-opp-6","What is the opposite of 'heavy'?","light"),A("b1-en-opp-7","What is the opposite of 'clean'?","dirty"),A("b1-en-opp-8","What is the opposite of 'near'?","far away"),A("b1-en-opp-9","What is the opposite of 'to begin'?","to stop"),A("b1-en-opp-10","What is the opposite of 'early'?","late"),H("b1-en-city-1","This morning we take the red bus to the centre of London.",["red bus","centre"]),H("b1-en-city-2","First we drink tea with scones in a small café near the river.",["tea","river"]),H("b1-en-city-3","Then we walk through Hyde Park and feed the friendly ducks.",["walk","friendly ducks"]),H("b1-en-city-4","In the museum we look at old maps and famous paintings.",["museum","famous paintings"]),H("b1-en-city-5","For lunch we eat fish and chips at a busy market.",["lunch","busy market"]),H("b1-en-city-6","In the afternoon we take a boat trip on the River Thames.",["afternoon","boat trip"]),H("b1-en-city-7","We buy postcards and small gifts for our friends at home.",["postcards","small gifts"]),H("b1-en-city-8","It starts to rain softly, so we hide under a large umbrella.",["rain","large umbrella"]),H("b1-en-city-9","For dinner we order hot soup and fresh bread in a warm pub.",["order","hot soup"]),H("b1-en-city-10","Tired but happy, we take the last train back to our hotel.",["last train","hotel"]);function Ye(e,t){return e.hintUsages.filter(n=>n.queryId===t&&n.type===D.SELF_AUTHORED).length}function Ve(e,t,n){const o=e.hintUsages.some(r=>r.queryId===t.id&&re(r.type).autoRevealsLength);return Pt(n,t.answer,le(t),{lengthAlreadyKnown:o,remainingCues:Bt(t.customCues,Ye(e,t.id)).length})}function Te(e,t,n){const o=e.exercise.queries.find(i=>i.id===t);if(!o)return null;const r=new Set(e.hintUsages.filter(i=>i.queryId===t).map(i=>i.type)),s=Se.filter(i=>n!=null&&n.has(i.id)?!1:(!r.has(i.id)||i.repeatable)&&Ve(e,o,i));return s.length===0?null:s[Math.floor(Math.random()*s.length)]}function on(e,t){const n=t?e.hintUsages.filter(d=>d.queryId===t):[],o=Math.min(n.reduce((d,b)=>d+b.cost,0),100),r=e.exercise.queries.filter(d=>z(d).correct===z(d).total).map(d=>Ee(e.hintUsages.filter(b=>b.queryId===d.id))),s=r.length>0?r.reduce((d,b)=>d+b,0)/r.length:0,i=o<30?l.green:o<60?l.yellow:l.orange;return`
    <div class="tt-help-bar" data-score="${o}">
      <div class="tt-help-bar__labels">
        <span class="tt-help-bar__label">Help used: ${Math.round(o)}%<span class="tt-help-bar__preview"></span></span>
        ${r.length>0?`<span class="tt-help-bar__avg">avg: ${Math.round(s)===0?"Perfect!":Math.round(s)+"%"}</span>`:""}
      </div>
      <div class="tt-help-bar__track">
        <div class="tt-help-bar__fill" style="width:${Math.min(o,100)}%;background:${i}"></div>
        <div class="tt-help-bar__ghost" style="left:${Math.min(o,100)}%"></div>
      </div>
    </div>
  `}const rn=(()=>{try{return localStorage.getItem("tiptong_app_url")??"https://maganino.github.io/TipTong-pilot"}catch{return"https://maganino.github.io/TipTong-pilot"}})();function Ge(e,t){var r,s,i;(r=document.getElementById("tt-save-overlay"))==null||r.remove();const n=document.createElement("div");n.id="tt-save-overlay",n.className="tt-save-overlay";const o=e.length;n.innerHTML=`<div class="tt-save-card tt-save-card--invite">
    <div class="tt-save-wordmark">TipTong</div>
    <div class="tt-save-num">${o}</div>
    <div class="tt-save-what">exercise${o!==1?"s":""} ready</div>
    <div class="tt-save-line">Yours to keep — play anywhere, hints and scores included.</div>
    <button class="tt-save-go-btn" id="tt-save-go">▶&nbsp; Save &amp; play in the app</button>
    <div class="tt-save-cancel" id="tt-save-cancel">Not now</div>
  </div>`,document.body.appendChild(n),(s=n.querySelector("#tt-save-go"))==null||s.addEventListener("click",()=>{var T;const d=t&&t.length>0?{exercises:e,scores:t}:e,b=JSON.stringify(d),h=btoa(encodeURIComponent(b).replace(/%([0-9A-F]{2})/g,(L,c)=>String.fromCharCode(parseInt(c,16)))),$=`${rn}/?import=${h}`;typeof chrome<"u"&&((T=chrome.runtime)!=null&&T.sendMessage)?chrome.runtime.sendMessage({type:"tiptong:open-tab",url:$}):window.open($,"_blank"),n.querySelector(".tt-save-card").innerHTML=`
      <div class="tt-save-done-ring">&#10003;</div>
      <div class="tt-save-what">Off to the app</div>
      <div class="tt-save-line" style="margin-bottom:8px">Pick a playlist there to finish</div>
    `,setTimeout(()=>n.remove(),2e3)}),(i=n.querySelector("#tt-save-cancel"))==null||i.addEventListener("click",()=>n.remove()),n.addEventListener("click",d=>{d.target===n&&n.remove()})}function sn(e,t){var i,d;const n=new Array(e.blanks.length).fill(null),o=new Set;for(let b=0;b<e.blanks.length;b++){const h=e.blanks[b];if(h.revealed||h.actual!==""&&h.actual.toLowerCase()===h.expected.toLowerCase()){if(!o.has(b)&&((i=t[b])==null?void 0:i.toLowerCase())===h.expected.toLowerCase())o.add(b);else for(let $=0;$<t.length;$++)if(!o.has($)&&((d=t[$])==null?void 0:d.toLowerCase())===h.expected.toLowerCase()){o.add($);break}}}const r=[];for(let b=0;b<t.length;b++)!o.has(b)&&t[b]!==" "&&r.push(t[b]);let s=0;for(let b=0;b<e.blanks.length;b++){const h=e.blanks[b];h.expected===" "||h.revealed||h.actual!==""&&h.actual.toLowerCase()===h.expected.toLowerCase()||h.actual===""&&s<r.length&&(n[b]=r[s],s++)}return n}function Ke(e,t){return t.some(n=>n.queryId!==e?!1:re(n.type).autoRevealsLength)}function Je(e,t){if(!e.blanks.some(i=>i.actual!==""||i.revealed))return`<span class="tt-inline-blank ${t?"tt-inline-blank--active":""}" data-query="${e.id}">···</span>`;let o=-1;for(let i=e.blanks.length-1;i>=0;i--){const d=e.blanks[i];if(d.revealed||d.actual!==""){o=i;break}}const r=o<e.blanks.length-1;let s=`<span class="tt-inline-blank" data-query="${e.id}">`;for(let i=0;i<=o;i++){const d=e.blanks[i];if(d.expected===" ")s+=" ";else if(d.revealed)s+=`<span class="tt-inline-char tt-inline-char--revealed">${d.expected}</span>`;else if(d.actual==="")s+='<span class="tt-inline-char tt-inline-char--empty">·</span>';else{const b=d.actual.toLowerCase()===d.expected.toLowerCase();s+=`<span class="tt-inline-char ${b?"tt-inline-char--correct":"tt-inline-char--wrong"}">${d.actual}</span>`}}return r&&(s+='<span class="tt-inline-char tt-inline-char--empty">...</span>'),s+="</span>",s}function Ze(e,t,n){const o=n?sn(e,n):null;let r='<div class="tt-blanks">';for(let s=0;s<e.blanks.length;s++){const i=e.blanks[s];if(i.expected===" "){r+='<div class="tt-blank-word-gap"></div>';continue}const d=i.actual!=="",b=i.revealed,h=d&&i.actual.toLowerCase()===i.expected.toLowerCase(),$=d&&!h&&!b,T=o==null?void 0:o[s],L=!b&&!d&&!!T;let c="tt-blank";b?c+=" tt-blank--revealed":h?c+=" tt-blank--correct":$?c+=" tt-blank--wrong":L&&(c+=" tt-blank--shuffled"),t&&(c+=" tt-blank--active");const g=b?i.expected:d?i.actual:L?T:" ";r+=`<div class="${c}" data-reveal-char="${s}" data-reveal-query="${e.id}" style="cursor:pointer">${g}</div>`}return r+="</div>",r}function an(e){const t=e.state,{exercise:n}=t,{originalSentence:o,queries:r}=n;let s="",i=0;for(const d of r){d.startIndex>i&&(s+=`<span class="tt-sentence-text">${te(o.slice(i,d.startIndex))}</span>`);const b=z(d),h=b.correct===b.total,$=Ke(d.id,t.hintUsages),T=e.activeQueryId===d.id,L=t.shuffledLettersMap[d.id];h?s+=`<span class="tt-solved">${te(d.answer)}</span>`:$?s+=`<span data-query="${d.id}">${Ze(d,T,L)}</span>`:s+=Je(d,T),i=d.endIndex}return i<o.length&&(s+=`<span class="tt-sentence-text">${te(o.slice(i))}</span>`),s}function ln(e){const t=e.state.exercise.queries;if(t.length<=1)return"";let n='<div class="tt-word-progress">';for(let o=0;o<t.length;o++){const r=t[o],s=z(r).correct===z(r).total,i=e.activeQueryId===r.id;let d="tt-word-dot";s&&(d+=" tt-word-dot--done"),i&&(d+=" tt-word-dot--active"),n+=`<span class="${d}" data-query-dot="${r.id}">${s?"✓":o+1}</span>`}return n+="</div>",n}function cn(e,t){const n=e.exercise.queries.find(s=>s.id===t);if(!n)return"";const o=new Set(e.hintUsages.filter(s=>s.queryId===t).map(s=>s.type));let r='<div class="tt-hints">';for(const s of Se){const d=o.has(s.id)&&!s.repeatable||!Ve(e,n,s),b=`tt-hint-chip${d?" tt-hint-chip--disabled":""}`,h=d?0:ze(s,n.answer,le(n)),$=h>0?`${s.description} — costs ${h}% help`:s.description;r+=`<button class="${b}" data-hint="${s.id}" data-cost="${h}" title="${$}"${d?" disabled":""}>${s.icon} ${s.label.split(" ")[0]}</button>`}return r+="</div>",r}function dn(e,t){const n=Math.round(t)===0?"Perfect!":`Help: ${Math.round(t)}%`,o=t<30?l.green:t<60?l.yellow:l.orange,r=document.createElement("div");r.className="tt-query-score",r.style.cssText=`
    text-align:center;padding:6px 12px;margin:4px 0;
    border-radius: ${N.sm};font-size: ${_.small};font-weight:700;
    color:${o};background:${o}15;
    animation:tt-fade-in 0.2s ease;
  `,r.textContent=n;const s=e.querySelector(".tt-answer-box");s?s.parentNode.insertBefore(r,s):e.appendChild(r)}function F(e){var g;if(!e.state||!e.popup)return;const{exercise:t}=e.state,n=e.popup.querySelector(".tt-popup__body");if(!n)return;if(e.minimized){n.style.display="none";return}n.style.display="block",t.type;const o=t.type==="hhh";if(!e.activeQueryId){const u=t.queries.find(S=>z(S).correct!==z(S).total);u&&(e.activeQueryId=u.id)}if(t.queries.every(u=>z(u).correct===z(u).total)){const u=e.currentIndex>=e.exercises.length-1,S=Ee(e.state.hintUsages),k=Math.round(S)===0?"Perfect!":`Help needed: ${Math.round(S)}%`;n.innerHTML=`
      <div class="tt-complete">
        <div class="tt-complete__check">&#10003;</div>
        <p style="font-size: ${_.body};margin:8px 0">${te(t.originalSentence)}</p>
        <p style="font-size: ${_.small};color:${S<30?l.green:S<60?l.yellow:l.orange};font-weight:600;margin:4px 0">${k}</p>
        ${u?`<button class="tt-hint-chip" style="margin-top:16px;font-size:${_.small}" data-action="close">Done</button>`:`<button class="tt-hint-chip" style="margin-top:16px;font-size:${_.small}" data-action="next">Next &rarr;</button>`}
        ${u?`<button class="tt-hint-chip" style="margin-top:8px;font-size:${_.small};border:1px solid ${l.yellow};color:${l.yellow}" data-action="save">Save to playlist</button>`:""}
      </div>
    `,et(e);return}const s=t.queries.find(u=>u.id===e.activeQueryId)??null,i=s?t.queries.indexOf(s):-1;let d="";if(o)d+=`<div class="tt-sentence">${an(e)}</div>`,d+=ln(e);else if(d+=`<div class="tt-popup__question">${te(t.originalSentence)} ?</div>`,s){const u=Ke(s.id,e.state.hintUsages),S=e.state.shuffledLettersMap[s.id];u?d+=Ze(s,!0,S):d+=Je(s,!0)}if(s){const u=jt(s),S=o?`${i+1}/${t.queries.length}`:"Type the answer",k=e.flashHint?`<span class="tt-hint-flash-inline">${e.flashHint.icon} ${e.flashHint.label}</span>`:"",m=e.suggestedFor===s.id?e.suggested:null,y=!e.showHints&&!e.flashHint&&m?`<button class="tt-hint-flash-inline tt-hint-chip--suggested" id="tt-suggested">${m.icon} ${m.label.split(" ")[0]} · ${ze(m,s.answer,le(s))}%</button>`:"",C=e.showHints?`<div class="tt-hints-inline">${cn(e.state,s.id)}</div>`:"",O=(s.customCues??[]).slice(0,Ye(e.state,s.id)),q=O.length>0?`<div class="tt-cue-reveal">${O.map(a=>`<div>✎ ${te(a)}</div>`).join("")}</div>`:"";d+=`
      <div class="tt-answer-box">
        <div class="tt-answer-header">
          <span class="tt-answer-label">${S}</span>
          ${C}
          <div style="display:flex;align-items:center;margin-left:auto;gap:4px">
            ${k}${y}
            <button class="tt-bulb ${e.showHints?"tt-bulb--active":""}" id="tt-bulb">💡</button>
          </div>
        </div>
        ${q}
        <input class="tt-input" value="${te(u)}" placeholder="Type here..." autocomplete="off" autocorrect="off" autocapitalize="off" />
      </div>
    `}d+=on(e.state,e.activeQueryId),d+=`<div class="tt-score">Exercise ${e.currentIndex+1} of ${e.exercises.length}</div>`,n.innerHTML=d;const b=u=>{!e.state||!s||(e.state=Qt(e.state,s.id,u.id),e.flashHint=u,e.suggested=null,e.suggestedFor=null,e.showHints=!1,F(e),setTimeout(()=>{e.flashHint===u&&(e.flashHint=null,F(e))},2e3))},h=n.querySelector("#tt-bulb");if(h&&s){let k=null,m=!1,y=!1,C=0,R=0,O=null;const q=()=>{O==null||O.classList.remove("tt-hint-chip--tracked"),O=null},a=(p,w)=>{var f,E;const v=(E=(f=document.elementFromPoint(p,w))==null?void 0:f.closest)==null?void 0:E.call(f,"[data-hint]");v!==O&&(q(),v&&!v.hasAttribute("disabled")&&(O=v,v.classList.add("tt-hint-chip--tracked")))},x=()=>{if(!e.state)return;const p=new Set;e.suggested&&p.add(e.suggested.id),e.lastSuggestion&&p.add(e.lastSuggestion);const w=e.suggested?new Set([e.suggested.id]):void 0,v=Te(e.state,s.id,p)??Te(e.state,s.id,w)??Te(e.state,s.id);v&&(e.lastSuggestion=v.id,e.suggested=v,e.suggestedFor=s.id,e.flashHint=null,F(e))};h.addEventListener("pointerdown",p=>{p.preventDefault(),m=!1,y=!1,C=p.clientX,R=p.clientY,e.showHints||(k=setTimeout(()=>{k=null,y=!0,e.suggested=null,e.suggestedFor=null,e.flashHint=null,e.showHints=!0,F(e)},300));const w=f=>{!m&&Math.hypot(f.clientX-C,f.clientY-R)>10&&(m=!0),e.showHints&&a(f.clientX,f.clientY)},v=()=>{if(document.removeEventListener("pointermove",w),k&&(clearTimeout(k),k=null),e.showHints){const f=O;q(),f?b(re(f.dataset.hint)):!y&&!m&&(e.showHints=!1,F(e))}else m||x()};document.addEventListener("pointermove",w),document.addEventListener("pointerup",v,{once:!0})}),h.addEventListener("contextmenu",p=>p.preventDefault())}(g=n.querySelector("#tt-suggested"))==null||g.addEventListener("click",()=>{const u=e.suggestedFor===(s==null?void 0:s.id)?e.suggested:null;u&&b(u)});const $=n.querySelector(".tt-input");$&&s&&($.focus(),$.setSelectionRange($.value.length,$.value.length),$.addEventListener("input",()=>{var k;if(!e.state||!s)return;e.flashHint=null,e.state=Ut(e.state,s.id,$.value);const u=e.state.exercise.queries.find(m=>m.id===s.id),S=z(u);if(S.correct===S.total){(k=e.onWordComplete)==null||k.call(e,u.answer,e.currentIndex);const m=e.state.hintUsages.filter(R=>R.queryId===s.id),y=Ee(m);e.completedScores.push({exerciseId:e.state.exercise.id,queryId:s.id,score:y,hintUsages:m.map(R=>({type:R.type,cost:R.cost}))});const C=e.state.exercise.queries.find(R=>R.id!==s.id&&z(R).correct!==z(R).total);if(C){dn(n,y),setTimeout(()=>{e.activeQueryId=C.id,F(e)},1200);return}}F(e)}));const T=n.querySelector(".tt-help-bar"),L=n.querySelector(".tt-help-bar__ghost"),c=n.querySelector(".tt-help-bar__preview");n.querySelectorAll("[data-hint]").forEach(u=>{u.addEventListener("click",()=>{!e.state||!s||b(re(u.dataset.hint))}),u.addEventListener("mouseenter",()=>{const S=Number(u.dataset.cost??0);if(!T||!L||S<=0)return;const k=Number(T.dataset.score??0);L.style.width=`${Math.max(0,Math.min(S,100-k))}%`,c&&(c.textContent=` → ${Math.min(Math.round(k+S),100)}%`)}),u.addEventListener("mouseleave",()=>{L&&(L.style.width="0%"),c&&(c.textContent="")})}),n.querySelectorAll("[data-reveal-char]").forEach(u=>{u.addEventListener("click",S=>{var C;if(S.stopPropagation(),!e.state)return;const k=parseInt(u.dataset.revealChar,10),m=u.dataset.revealQuery;e.activeQueryId!==m&&(e.activeQueryId=m),e.state=Xt(e.state,m,k);const y=e.state.exercise.queries.find(R=>R.id===m);if(y){const R=z(y);R.correct===R.total&&((C=e.onWordComplete)==null||C.call(e,y.answer,e.currentIndex))}F(e)})}),n.querySelectorAll("[data-query]").forEach(u=>{u.addEventListener("click",()=>{const S=u.dataset.query;e.activeQueryId!==S&&(e.activeQueryId=S,F(e))})}),n.querySelectorAll("[data-query-dot]").forEach(u=>{u.addEventListener("click",()=>{const S=u.dataset.queryDot;e.activeQueryId=S,e.showHints=!1,e.flashHint=null,F(e)})}),et(e)}function et(e){var t,n;e.popup&&(e.popup.querySelectorAll("[data-action]").forEach(o=>{o.addEventListener("click",()=>{const r=o.dataset.action;r==="next"?(e.currentIndex++,e.activeQueryId=null,e.showHints=!1,e.flashHint=null,e.currentIndex<e.exercises.length&&(e.state=Fe(e.exercises[e.currentIndex]),F(e))):r==="close"?tt(e):r==="save"&&Ge(e.exercises,e.completedScores)})}),(t=e.popup.querySelector(".tt-popup__close"))==null||t.addEventListener("click",()=>{tt(e)}),(n=e.popup.querySelector(".tt-popup__minimize"))==null||n.addEventListener("click",()=>{e.minimized=!e.minimized;const o=e.popup.querySelector(".tt-popup__minimize");o&&(o.textContent=e.minimized?"▲":"▼"),F(e)}))}function tt(e){var t,n;e._keyHandler&&document.removeEventListener("keydown",e._keyHandler),(t=e.popup)==null||t.remove(),e.popup=null,(n=e.onClose)==null||n.call(e)}function te(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function un(e,t){var s;oe(),(s=document.getElementById("tt-popup"))==null||s.remove();const n=document.createElement("div");n.id="tt-popup",n.className="tt-popup",n.innerHTML=`
    <div class="tt-popup__header">
      <span class="tt-popup__title">TipTong</span>
      <div style="display:flex;gap:8px">
        <button class="tt-popup__minimize" title="Minimize">▼</button>
        <button class="tt-popup__close" title="Close">&times;</button>
      </div>
    </div>
    <div class="tt-popup__body"></div>
  `,document.body.appendChild(n);const o={exercises:e,currentIndex:0,state:e.length>0?Fe(e[0]):null,activeQueryId:null,showHints:!1,flashHint:null,minimized:!1,popup:n,suggested:null,suggestedFor:null,lastSuggestion:null,completedScores:[],onClose:t==null?void 0:t.onClose,onWordComplete:t==null?void 0:t.onWordComplete},r=i=>{if(i.key!=="Enter"||!o.popup)return;const d=o.popup.querySelector("[data-action='next']"),b=o.popup.querySelector("[data-action='close']");d?(i.preventDefault(),d.click()):b&&(i.preventDefault(),b.click())};document.addEventListener("keydown",r),o._keyHandler=r,F(o)}function hn(e,t,n){const o=e.slice(t,n),r=[],s=/[\p{L}\p{M}'']+/gu;let i;for(;(i=s.exec(o))!==null;)r.push({start:t+i.index,end:t+i.index+i[0].length});return r.length===0?{start:t,end:n}:r[Math.floor(Math.random()*r.length)]}function nt(e,t){if(t.cue&&(e.queries=e.queries.map(n=>({...n,customCues:[t.cue]}))),t.type==="hhh")for(const n of t.underlinedWords){if(!n.cue)continue;const o=n.start-t.sentenceStart,r=n.end-t.sentenceStart,s=e.queries.find(i=>i.startIndex<r&&i.endIndex>o);s&&(s.customCues=[...s.customCues??[],n.cue])}return e}function ot(e){const t=[];for(const n of e)if(n.type==="qa"){const o=n.question+" "+n.answer,r=tn(o,{question:{start:0,end:n.question.length},answer:{start:n.question.length+1,end:o.length}});r&&t.push(nt(r,n))}else{let o=n.underlinedWords;o.length===0&&(o=[hn(n.sourceText,n.sentenceStart,n.sentenceEnd)]);const r=Jt({sourceText:n.sourceText,sentenceSelection:{start:n.sentenceStart,end:n.sentenceEnd},wordSelections:o});r&&t.push(nt(r,n))}return t}function gn(e,t){un(ot(e),t)}function pn(e){const t=ot(e);return t.length===0?!1:(oe(),Ge(t),!0)}const Q={green:X.brandEnergeticGreen,orange:X.brandBrightOrange,dark:X.brandDarkViolet},V={display:B.familyDisplay,sans:B.familySans,label:B.sizeLabel,body:B.sizeBody,small:B.sizeSmall},se={lg:ee.lg},rt=window===window.top;function fn(){return typeof CSS>"u"||!("highlights"in CSS)||typeof window.Highlight!="function"?!1:[()=>!!window.__NEXT_DATA__,()=>!!document.querySelector("[data-reactroot]"),()=>!!document.querySelector("#__next"),()=>{const t=document.body;return t?Object.keys(t).some(n=>n.startsWith("__reactFiber")||n.startsWith("__reactInternalInstance")):!1},()=>{const t=document.getElementById("root")||document.getElementById("app");return t?t._reactRootContainer?!0:Object.keys(t).some(n=>n.startsWith("__reactFiber")||n.startsWith("__reactContainer")):!1},()=>!!document.getElementById("___gatsby"),()=>window.location.hostname.includes("perlego"),()=>/(^|\.)(chatgpt\.com|openai\.com|claude\.ai)$/.test(window.location.hostname),()=>{const t=document.querySelectorAll("body > *, body > * > *");for(const n of t)if(Object.keys(n).some(o=>o.startsWith("__reactFiber")||o.startsWith("__reactContainer")))return!0;return!1}].some(t=>{try{return t()}catch{return!1}})}function st(){if(window.__tiptong){be();return}oe();const e=document.createElement("style");e.id="tt-suppress-host",e.textContent=`
    *, *::before, *::after {
      -webkit-user-select: text !important;
      user-select: text !important;
    }
    [class*="overlay"]:not([class*="tt-"]), [class*="Overlay"]:not([class*="tt-"]),
    [class*="mask"]:not([class*="tt-"]), [class*="Mask"]:not([class*="tt-"]),
    [class*="selection-layer"], [class*="SelectionLayer"] {
      pointer-events: none !important;
    }
    .highlighter-context, .highlighter-context * {
      pointer-events: auto !important;
      -webkit-user-select: text !important;
      user-select: text !important;
    }
    [class*="AnnotationToolbar"], [class*="annotationToolbar"],
    [class*="SelectionToolbar"], [class*="selectionToolbar"],
    [data-testid*="annotation"], [data-testid*="highlight"],
    [class*="Popover"], [class*="popover"],
    [class*="highlightMenu"], [class*="selectionPopover"],
    [class*="SelectionPopover"], [class*="tooltip-selection"] {
      display: none !important;
      visibility: hidden !important;
      pointer-events: none !important;
    }
  `,document.head.appendChild(e);const t=Selection.prototype.removeAllRanges,n=Selection.prototype.empty;Selection.prototype.removeAllRanges=function(){if(!(window.__tiptong&&!window.__tiptongClearing))return t.call(this)},Selection.prototype.empty=function(){if(!(window.__tiptong&&!window.__tiptongClearing))return n.call(this)},window.__tiptongSelectionRestore={origRemoveAllRanges:t,origEmpty:n};const o=fn();o&&console.log("[TipTong] Using CSS Highlight API (React site detected)");const r=o?Tt():xt();window.__tiptong=r,rt?mn(r):bn(r)}function mn(e){const t=document.createElement("div");t.id="tt-toolbar",t.style.cssText=`
    position: fixed; top: 0; left: 0; right: 0; z-index: 999998;
    background: ${U.gradient}; padding: 10px 16px;
    display: flex; align-items: center; gap: 10px;
    border-bottom: ${U.cardBorder};
    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    font-family: ${V.sans};
  `,t.innerHTML=`
    <span style="color:${Q.green};font-family:${V.display};font-weight:800;font-size: ${V.body};margin-right:auto">TipTong</span>
    <div style="display:flex;background:rgba(255,255,255,0.15);border-radius: ${se.lg};overflow:hidden">
      <button data-tt-mode="hhh" style="background:white;border:none;color:${Q.dark};padding:6px 12px;font-size: ${V.small};font-weight:600;cursor:pointer;border-radius: ${se.lg}">HHH</button>
      <button data-tt-mode="qa" style="background:transparent;border:none;color:rgba(255,255,255,0.7);padding:6px 12px;font-size: ${V.small};font-weight:600;cursor:pointer;border-radius: ${se.lg}">Q&A</button>
    </div>
    <button id="tt-delete-btn" style="background:transparent;border:1px solid rgba(255,138,0,0.5);color:${Q.orange};padding:6px 12px;font-size: ${V.small};font-weight:600;cursor:pointer;border-radius: ${se.lg}">Delete</button>
    <span id="tt-status" style="color:rgba(255,255,255,0.7);font-size: ${V.small}">Select text to highlight</span>
    <button id="tt-save-btn" style="background:transparent;border:1px solid ${Q.green};color:${Q.green};padding:6px 14px;font-size: ${V.small};font-weight:bold;cursor:pointer;border-radius: ${se.lg}">Save</button>
    <button id="tt-play-btn" style="background:${Q.green};border:none;color:${Q.dark};padding:6px 16px;font-size: ${V.small};font-weight:bold;cursor:pointer;border-radius: ${se.lg}">Play</button>
    <button id="tt-close-btn" style="background:none;border:none;color:white;font-size: ${V.label};cursor:pointer;opacity:0.6;padding:4px">&times;</button>
  `,document.body.appendChild(t),document.body.style.marginTop=t.offsetHeight+"px";const n=t.querySelector("#tt-status"),o=t.querySelector("#tt-delete-btn");t.querySelectorAll("[data-tt-mode]").forEach(h=>{h.addEventListener("click",()=>{t.querySelectorAll("[data-tt-mode]").forEach(T=>{T.style.background="transparent",T.style.color="rgba(255,255,255,0.7)"}),h.style.background="white",h.style.color=Q.dark;const $=h.dataset.ttMode;e.setMode($),J({type:"tt:set-mode",mode:$}),r()})}),o.addEventListener("click",()=>{const h=e.toggleDeleteMode();o.style.background=h?Q.orange:"transparent",o.style.color=h?"white":Q.orange,o.textContent=h?"Done":"Delete",J({type:"tt:toggle-delete"})}),t.querySelector("#tt-play-btn").addEventListener("click",()=>{const h=e.getSelections();it("tt:get-exercises",$=>{if(h.length===0&&$.length===0){n.textContent="No highlights yet";return}const T=e.validate();if(T.length>0){b(T[0]);return}e.isDeleteMode()&&e.toggleDeleteMode(),o.style.display="none",e.showAnswers(),e.hideAnswers(),e.hideUnderlinedWords(),J({type:"tt:prepare-play"});let L=e.getOrderedExerciseData();if($.length>0&&(L=L.concat($)),L.length===0){n.textContent="No complete exercises";return}gn(L,{onClose:()=>{e.showAnswers(),o.style.display="",J({type:"tt:end-play"})},onWordComplete:(c,g)=>{e.revealWord(c,g),J({type:"tt:reveal-word",word:c,exerciseIndex:g})}})})}),t.querySelector("#tt-save-btn").addEventListener("click",()=>{const h=e.validate();if(h.length>0){b(h[0]);return}it("tt:get-exercises-data",$=>{const T=e.getOrderedExerciseData().concat($);if(T.length===0){n.textContent="No highlights yet";return}pn(T)||(n.textContent="No complete exercises")})}),window.addEventListener("message",h=>{var $;(($=h.data)==null?void 0:$.type)==="tt:status-update"&&i(h.data)});function r(){e.isDeleteMode()||(o.style.background="transparent",o.style.color=Q.orange,o.textContent="Delete"),J({type:"tt:request-status"}),s()}function s(){const h=e.getSelections();if(h.length===0){n.textContent="Select text to highlight";return}const $=h.filter(c=>c.role!=="sentence"),T=h.filter(c=>c.role==="sentence"),L=[];if($.length>0){const c=Math.floor($.length/2);L.push(`${c} Q&A${$.length%2!==0?" · answer next":""}`)}T.length>0&&L.push(`${T.length} HHH`),n.textContent=L.join(" + ")}function i(h){const $=e.getSelections(),T=$.filter(g=>g.role!=="sentence").length+h.qaCount,L=$.filter(g=>g.role==="sentence").length+h.hhhCount;if(T===0&&L===0){n.textContent="Select text to highlight";return}const c=[];if(T>0){const g=Math.floor(T/2);c.push(`${g} Q&A${T%2!==0?" · answer next":""}`)}L>0&&c.push(`${L} HHH`),n.textContent=c.join(" + ")}const d=()=>setTimeout(r,50);document.addEventListener("mouseup",d),t.querySelector("#tt-close-btn").addEventListener("click",()=>{J({type:"tt:teardown"}),be()}),window.__tiptongCleanup={hl:e,onStatusUpdate:d},chrome.runtime.onMessage.addListener(h=>{h.type==="tiptong:toggle"&&(J({type:"tt:teardown"}),be())});function b(h){var T;(T=document.querySelector(".tt-toast"))==null||T.remove();const $=document.createElement("div");$.className="tt-toast",$.textContent="⚠ "+h,document.body.appendChild($),setTimeout(()=>$.remove(),3e3)}}function bn(e){window.addEventListener("message",n=>{var o,r;if((r=(o=n.data)==null?void 0:o.type)!=null&&r.startsWith("tt:"))switch(n.data.type){case"tt:set-mode":e.setMode(n.data.mode);break;case"tt:toggle-delete":e.toggleDeleteMode();break;case"tt:request-status":{const s=e.getSelections();window.parent.postMessage({type:"tt:status-update",qaCount:s.filter(i=>i.role!=="sentence").length,hhhCount:s.filter(i=>i.role==="sentence").length},"*");break}case"tt:get-exercises":{e.showAnswers(),e.hideAnswers(),e.hideUnderlinedWords();const s=e.getOrderedExerciseData();window.parent.postMessage({type:"tt:exercises-response",data:s},"*");break}case"tt:get-exercises-data":{const s=e.getOrderedExerciseData();window.parent.postMessage({type:"tt:exercises-response",data:s},"*");break}case"tt:prepare-play":e.showAnswers(),e.hideAnswers(),e.hideUnderlinedWords();break;case"tt:end-play":e.showAnswers();break;case"tt:reveal-word":e.revealWord(n.data.word,n.data.exerciseIndex);break;case"tt:teardown":be();break}});const t=()=>{setTimeout(()=>{const n=e.getSelections();window.parent.postMessage({type:"tt:status-update",qaCount:n.filter(o=>o.role!=="sentence").length,hhhCount:n.filter(o=>o.role==="sentence").length},"*")},50)};document.addEventListener("mouseup",t),window.__tiptongCleanup={hl:e,onStatusUpdate:t}}function J(e){var n;const t=document.querySelectorAll("iframe");for(const o of t)try{(n=o.contentWindow)==null||n.postMessage(e,"*")}catch{}}function it(e,t){const n=document.querySelectorAll("iframe");if(n.length===0){t([]);return}const o=[];let r=0;const s=setTimeout(()=>t(o),500),i=d=>{var b;((b=d.data)==null?void 0:b.type)==="tt:exercises-response"&&(o.push(...d.data.data||[]),r++,r>=n.length&&(clearTimeout(s),window.removeEventListener("message",i),t(o)))};window.addEventListener("message",i),J({type:e})}function be(){var o,r,s,i;const e=window.__tiptongCleanup;e&&(e.hl.showAnswers(),e.hl.destroy(),document.removeEventListener("mouseup",e.onStatusUpdate),delete window.__tiptongCleanup);const t=document.getElementById("tt-toolbar");t&&t.remove(),rt&&(document.body.style.marginTop=""),(o=document.getElementById("tt-styles"))==null||o.remove(),(r=document.getElementById("tt-css-highlight-styles"))==null||r.remove(),(s=document.getElementById("tt-popup"))==null||s.remove(),(i=document.getElementById("tt-suppress-host"))==null||i.remove();const n=window.__tiptongSelectionRestore;n&&(Selection.prototype.removeAllRanges=n.origRemoveAllRanges,Selection.prototype.empty=n.origEmpty,delete window.__tiptongSelectionRestore),delete window.__tiptong}st(),window.__tiptongInit=st})();
