/*! TipTong Extension — © 2026 TipTong. All rights reserved.
 * Proprietary software. No license is granted to copy, modify, or redistribute. */(function(){"use strict";const F={brandElectricViolet:"#4E15FF",brandEnergeticGreen:"#0FFFB9",brandDarkViolet:"#160751",brandBrightOrange:"#FF5400",brandBrightYellow:"#FFDE00",brandWhite:"#FFFFFF",supportLavender:"#B6A6EB"},z={familyDisplay:"Bryant, Nunito, Montserrat, system-ui, sans-serif",familySans:'Montserrat, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif',sizeHero:"48px",sizeH1:"32px",sizeH2:"24px",sizeLabel:"18px",sizeBody:"16px",sizeSmall:"14px"},B={tile:"2px",sm:"5px",md:"12px",lg:"16px",xl:"24px",pill:"100px"},w={display:z.familyDisplay,sans:z.familySans,hero:z.sizeHero,h1:z.sizeH1,h2:z.sizeH2,label:z.sizeLabel,body:z.sizeBody,small:z.sizeSmall},L={tile:B.tile,sm:B.sm,md:B.md,lg:B.lg,xl:B.xl,pill:B.pill},a={violet:F.brandElectricViolet,green:F.brandEnergeticGreen,orange:F.brandBrightOrange,yellow:F.brandBrightYellow,dark:F.brandDarkViolet,white:F.brandWhite,lavender:F.supportLavender,greenInk:"#0A9E74"},W={gradient:`linear-gradient(170deg, #14406B 0%, #16265C 55%, ${a.dark} 100%)`,card:"rgba(255,255,255,0.06)",cardBorder:"1px solid rgba(255,255,255,0.12)"},Ie=`
.tt-highlight {
  background-color: ${a.violet}20 !important;
  border-bottom: 2px solid ${a.violet}60 !important;
  border-radius: ${L.tile} !important;
  cursor: pointer !important;
  transition: background-color 0.15s !important;
  position: relative !important;
  display: inline !important;
}
.tt-highlight:hover {
  background-color: ${a.violet}35 !important;
}
.tt-highlight--answer {
  background-color: ${a.green}20 !important;
  border-bottom-color: ${a.green}60 !important;
}
.tt-highlight--answer:hover {
  background-color: ${a.green}35 !important;
}
.tt-highlight--delete {
  background-color: ${a.orange}20 !important;
  border-bottom-color: ${a.orange} !important;
  text-decoration: line-through !important;
  cursor: pointer !important;
}
.tt-underline {
  border-bottom: 2px dotted ${a.green} !important;
  font-weight: bold !important;
  background-color: ${a.green}20 !important;
  border-radius: ${L.tile} !important;
  cursor: pointer !important;
}
.tt-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  border-radius: ${L.sm};
  color: white;
  font-size: ${w.small};
  font-weight: bold;
  margin-right: 3px;
  vertical-align: middle;
  line-height: 16px;
}
.tt-badge--q { background-color: ${a.violet}; }
.tt-badge--a { background-color: ${a.green}; }

/* Interactive sentence (HHH inline blanks) */
.tt-sentence {
  font-size: ${w.body};
  line-height: 2;
  background: ${W.card};
  border: ${W.cardBorder};
  border-radius: ${L.md};
  padding: 12px 16px;
  margin-bottom: 12px;
  color: ${a.white};
}
.tt-sentence-text { color: ${a.white}; }
.tt-inline-blank {
  font-weight: bold;
  color: ${a.lavender};
  background: ${a.white}10;
  border-radius: ${L.sm};
  padding: 2px 6px;
  cursor: pointer;
}
.tt-inline-blank--active {
  background: ${a.green}20;
  color: ${a.green};
}
.tt-inline-char { font-size: ${w.body}; }
.tt-inline-char--revealed { color: ${a.white}; background: ${a.green}; border-radius: ${L.tile}; padding: 0 1px; }
.tt-inline-char--correct { color: ${a.green}; font-weight: bold; }
.tt-inline-char--wrong { color: ${a.orange}; font-weight: bold; }
.tt-inline-char--empty { color: ${a.white}30; }
.tt-solved {
  font-weight: bold;
  color: ${a.green};
  background: ${a.green}10;
  border-radius: ${L.sm};
  padding: 2px 4px;
}

/* Word progress dots */
.tt-word-progress {
  display: flex;
  gap: 12px;
  justify-content: center;
  margin-bottom: 12px;
}
.tt-word-dot {
  width: 24px;
  height: 24px;
  border-radius: ${L.md};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: ${w.small};
  font-weight: 600;
  cursor: pointer;
  background: ${a.white}20;
  color: ${a.white};
  opacity: 0.6;
}
.tt-word-dot--done { background: ${a.green}; opacity: 1; }
.tt-word-dot--active { background: ${a.white}; color: ${a.green}; border: 2px solid ${a.green}; opacity: 1; }

/* Answer box */
.tt-answer-box {
  background: ${a.white}10;
  border-radius: ${L.md};
  padding: 12px;
  margin-top: 8px;
  border: 1px solid ${a.green}40;
}
.tt-answer-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}
.tt-answer-label {
  font-size: ${w.small};
  color: ${a.white};
  opacity: 0.6;
  text-transform: uppercase;
  letter-spacing: 1px;
}
.tt-bulb {
  /* The browser must not turn the fan drag into a scroll or text selection. */
  touch-action: none;
  user-select: none;
  background: ${a.white}15;
  border: none;
  border-radius: ${L.lg};
  width: 32px;
  height: 32px;
  font-size: ${w.body};
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
}
.tt-bulb:hover, .tt-bulb--active { background: ${a.yellow}40; }
.tt-hint-container { margin-bottom: 8px; }
.tt-blank--active { border-bottom-color: ${a.green}; }

/* Player popup */
.tt-popup {
  position: fixed;
  bottom: 20px;
  right: 20px;
  width: 380px;
  max-width: calc(100vw - 40px);
  background: ${W.gradient};
  border: ${W.cardBorder};
  border-radius: ${L.xl};
  box-shadow: 0 8px 32px rgba(0,0,0,0.4);
  z-index: 999999;
  font-family: ${w.sans};
  color: ${a.white};
  overflow: hidden;
}
.tt-popup__header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px;
  background: ${W.card};
  border-bottom: ${W.cardBorder};
}
.tt-popup__title {
  font-family: ${w.display};
  font-size: ${w.small};
  font-weight: 800;
  letter-spacing: 0.02em;
  color: ${a.green};
}
.tt-popup__close {
  background: none;
  border: none;
  color: ${a.white};
  font-size: ${w.label};
  cursor: pointer;
  opacity: 0.7;
  padding: 4px;
}
.tt-popup__minimize {
  background: none;
  border: none;
  color: ${a.white};
  font-size: ${w.small};
  cursor: pointer;
  opacity: 0.7;
  padding: 4px;
}
.tt-popup__close:hover, .tt-popup__minimize:hover { opacity: 1; }
.tt-popup__body {
  padding: 16px;
}
.tt-popup__question {
  font-size: ${w.body};
  line-height: 1.5;
  margin-bottom: 16px;
  color: ${a.white};
}

/* Blank boxes */
.tt-blanks {
  display: flex;
  flex-wrap: wrap;
  gap: 3px;
  margin-bottom: 12px;
}
.tt-blank-word-gap { width: 12px; }
.tt-blank {
  width: 22px;
  height: 28px;
  border-radius: ${L.sm};
  background: ${a.white}15;
  border-bottom: 2px solid ${a.violet}40;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: ${w.small};
  font-weight: bold;
  color: ${a.white}50;
}
.tt-blank--correct {
  color: ${a.green};
  background: ${a.green}15;
  border-bottom-color: ${a.green};
}
.tt-blank--wrong {
  color: ${a.orange};
  background: ${a.orange}15;
  border-bottom-color: ${a.orange};
}
.tt-blank--revealed {
  color: ${a.white};
  background: ${a.green};
  border-bottom-color: ${a.green};
}
.tt-blank--shuffled {
  color: ${a.yellow};
  background: ${a.yellow}15;
  border-bottom-color: ${a.yellow}40;
}

/* Input */
.tt-input {
  width: 100%;
  height: 40px;
  background: ${a.white}15;
  border: none;
  border-radius: ${L.sm};
  color: ${a.white};
  font-size: ${w.body};
  text-align: center;
  font-weight: 600;
  outline: none;
  box-sizing: border-box;
  padding: 0 12px;
}
.tt-input::placeholder { color: ${a.white}40; }
.tt-input:focus { box-shadow: 0 0 0 2px ${a.green}60; }

/* Hint bar */
.tt-hints {
  display: flex;
  gap: 6px;
  overflow-x: auto;
  padding: 8px 0;
  scrollbar-width: none;
}
.tt-hints::-webkit-scrollbar { display: none; }
.tt-hint-chip {
  display: flex;
  align-items: center;
  gap: 4px;
  background: ${a.white}15;
  border: none;
  border-radius: ${L.lg};
  padding: 6px 10px;
  color: ${a.white};
  font-size: ${w.small};
  font-weight: 600;
  cursor: pointer;
  white-space: nowrap;
  transition: background 0.15s;
}
.tt-hint-chip:hover { background: ${a.white}25; }
.tt-hint-chip--disabled { opacity: 0.3; pointer-events: none; }
/* Chip under the finger during a fan drag — dock magnification */
.tt-hint-chip--tracked {
  background: ${a.green}30;
  outline: 1px solid ${a.green};
  transform: scale(1.12);
}
/* Pending bulb suggestion, glowing for its confirming tap */
.tt-hint-chip--suggested {
  border: 1px solid ${a.green};
  background: ${a.green}15;
  cursor: pointer;
  box-shadow: 0 0 8px ${a.green}60;
}
/* Help progress bar */
.tt-help-bar {
  padding: 8px 12px;
}
.tt-help-bar__labels {
  display: flex;
  justify-content: space-between;
  margin-bottom: 4px;
}
.tt-help-bar__label {
  font-size: ${w.small};
  font-weight: 600;
  color: ${a.white};
}
.tt-help-bar__avg {
  font-size: ${w.small};
  color: ${a.white};
  opacity: 0.5;
}
.tt-help-bar__track {
  position: relative;
  height: 6px;
  border-radius: ${L.tile};
  background: ${a.white}15;
  overflow: hidden;
}
.tt-help-bar__fill {
  height: 100%;
  border-radius: ${L.tile};
  transition: width 0.3s ease, background-color 0.3s ease;
}
/* Hover price preview: grows out of the fill while a hint chip is hovered */
.tt-help-bar__ghost {
  position: absolute;
  top: 0;
  height: 100%;
  width: 0;
  background: ${a.white}55;
  border-radius: ${L.tile};
  transition: width 0.15s ease;
  pointer-events: none;
}
.tt-help-bar__preview {
  color: ${a.yellow};
  font-weight: 600;
}

/* Hint flash pill — inline to left of bulb */
.tt-hint-flash-inline {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  background: ${a.white}10;
  border: 1px solid ${a.green}40;
  border-radius: ${L.md};
  padding: 3px 8px;
  font-size: ${w.small};
  color: ${a.white};
  white-space: nowrap;
}

/* Hints bar inline in header */
.tt-hints-inline {
  flex: 1;
  overflow-x: auto;
  margin: 0 4px;
}
.tt-hints-inline::-webkit-scrollbar { display: none; }
.tt-hints-inline .tt-hints {
  flex-wrap: nowrap;
  gap: 4px;
}
.tt-hints-inline .tt-hint-chip {
  padding: 4px 8px;
  font-size: ${w.small};
}

/* Revealed "My cue" lines above the input */
.tt-cue-reveal {
  margin-bottom: 8px;
  display: grid;
  gap: 4px;
}
.tt-cue-reveal div {
  font-size: ${w.small};
  color: ${a.yellow};
  background: ${a.yellow}12;
  border-radius: ${L.sm};
  padding: 4px 8px;
}

/* ✎ marker on highlights that carry an authored cue */
.tt-has-cue::after {
  content: "✎";
  font-size: 10px;
  vertical-align: super;
  color: ${a.violet};
  opacity: 0.8;
  margin-left: 1px;
}

/* Cue editor (long-press on a highlight or underline) */
.tt-cue-context {
  font-size: ${w.small};
  color: ${a.lavender};
  font-style: italic;
  margin-bottom: 10px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.tt-cue-input {
  width: 100%;
  box-sizing: border-box;
  height: 36px;
  background: ${a.white}10;
  border: 1px solid ${a.white}20;
  border-radius: ${L.sm};
  padding: 0 10px;
  font-size: ${w.small};
  color: ${a.white};
  outline: none;
}
.tt-cue-input:focus { box-shadow: 0 0 0 2px ${a.green}60; }
.tt-cue-actions {
  display: flex;
  gap: 8px;
  margin-top: 14px;
  align-items: center;
}
.tt-cue-remove {
  font-size: ${w.small};
  color: ${a.orange};
  cursor: pointer;
  margin-right: auto;
}

/* Save modal */
.tt-save-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999999;
  padding: 24px;
}
.tt-save-card {
  background: ${W.gradient};
  border: ${W.cardBorder};
  border-radius: ${L.lg};
  padding: 20px;
  width: 100%;
  max-width: 360px;
  color: ${a.white};
}
.tt-save-card h3 {
  margin: 0;
  font-family: ${w.display};
  font-weight: 800;
  font-size: ${w.label};
}
.tt-save-card .tt-save-sub {
  font-size: ${w.small};
  opacity: 0.6;
  margin-top: 2px;
}

/* The invite: a centered hand-off card — the app surface in miniature,
   one number, one line, one glowing way forward. */
@keyframes tt-pop {
  from { opacity: 0; transform: scale(0.94) translateY(10px); }
  to   { opacity: 1; transform: scale(1) translateY(0); }
}
.tt-save-card--invite {
  text-align: center;
  padding: 26px 24px 18px;
  /* A green dawn over the app gradient — the moment feels like a win */
  background:
    radial-gradient(420px 220px at 50% -40%, ${a.green}2E, transparent 65%),
    ${W.gradient};
  animation: tt-pop 0.25s ease-out;
}
.tt-save-wordmark {
  font-family: ${w.display};
  font-weight: 800;
  font-size: ${w.small};
  letter-spacing: 0.04em;
  color: ${a.green};
}
.tt-save-num {
  font-family: ${w.display};
  font-weight: 800;
  font-size: 46px;
  line-height: 1.1;
  color: ${a.yellow};
  margin-top: 8px;
}
.tt-save-what {
  font-size: ${w.body};
  font-weight: 700;
  color: ${a.white};
  margin-bottom: 8px;
}
.tt-save-line {
  font-size: ${w.small};
  color: ${a.lavender};
  line-height: 1.5;
  max-width: 30ch;
  margin: 0 auto 18px;
}
.tt-save-go-btn {
  width: 100%;
  box-sizing: border-box;
  background: ${a.green};
  color: ${a.dark};
  border: none;
  border-radius: ${L.pill};
  padding: 13px 16px;
  font-family: ${w.display};
  font-size: ${w.body};
  font-weight: 800;
  cursor: pointer;
  box-shadow: 0 6px 20px ${a.green}40;
  transition: transform 0.12s ease, box-shadow 0.12s ease;
}
.tt-save-go-btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 8px 24px ${a.green}55;
}
.tt-save-done-ring {
  width: 56px;
  height: 56px;
  margin: 8px auto 12px;
  border-radius: ${L.pill};
  background: ${a.green};
  color: ${a.dark};
  font-size: ${w.h2};
  font-weight: 800;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 6px 20px ${a.green}40;
}
.tt-save-row {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 8px;
  border-bottom: 1px solid ${a.white}10;
  cursor: pointer;
  border-radius: ${L.sm};
}
.tt-save-row:hover {
  background: ${a.white}10;
}
.tt-save-input {
  flex: 1;
  height: 32px;
  background: ${a.white}10;
  border: 1px solid ${a.white}20;
  border-radius: ${L.sm};
  padding: 0 8px;
  font-size: ${w.small};
  color: ${a.white};
}
.tt-save-input::placeholder { color: ${a.white}40; }
.tt-save-create-btn {
  background: ${a.green};
  border: none;
  border-radius: ${L.pill};
  padding: 6px 14px;
  font-weight: bold;
  color: ${a.dark};
  cursor: pointer;
  font-size: ${w.small};
}
.tt-save-cancel {
  text-align: center;
  margin-top: 12px;
  font-size: ${w.small};
  opacity: 0.5;
  cursor: pointer;
}
.tt-save-check {
  text-align: center;
  font-size: ${w.h1};
  color: ${a.green};
}
.tt-save-msg {
  text-align: center;
  font-size: ${w.small};
  font-weight: 600;
  margin-top: 8px;
}

/* Toast animations */
@keyframes tt-fade-in {
  from { opacity: 0; transform: translateY(-4px); }
  to { opacity: 1; transform: translateY(0); }
}
@keyframes tt-toast-fade {
  0% { opacity: 0; transform: translateY(-10px); }
  10% { opacity: 1; transform: translateY(0); }
  80% { opacity: 1; transform: translateY(0); }
  100% { opacity: 0; transform: translateY(-10px); }
}
.tt-toast {
  position: fixed;
  top: 52px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 999999;
  background: ${a.orange};
  color: white;
  padding: 10px 20px;
  border-radius: ${L.sm};
  font-family: ${w.sans};
  font-size: ${w.small};
  font-weight: 600;
  box-shadow: 0 4px 12px rgba(0,0,0,0.3);
  animation: tt-toast-fade 3s ease forwards;
  pointer-events: none;
}

/* Score */
.tt-score {
  text-align: center;
  padding: 8px;
  font-size: ${w.small};
  color: ${a.white};
  opacity: 0.6;
}

/* Complete state */
.tt-complete {
  text-align: center;
  padding: 20px;
}
.tt-complete__check {
  font-size: ${w.hero};
  color: ${a.green};
  margin-bottom: 8px;
}
.tt-complete__score {
  font-size: ${w.h1};
  font-weight: bold;
  /* Not electric violet: on the dark surface it reads as a gap (see HelpDonut). */
  color: ${a.yellow};
}
`;function Y(){if(document.getElementById("tt-styles"))return;He();const e=document.createElement("style");e.id="tt-styles",e.textContent=Ie,document.head.appendChild(e)}function He(){if(!document.getElementById("tt-fonts"))try{const e=document.createElement("link");e.id="tt-fonts",e.rel="stylesheet",e.href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Nunito:wght@700&display=swap",document.head.appendChild(e)}catch{}}function Ne(e){var i,d,u,h;Y(),(i=document.getElementById("tt-cue-overlay"))==null||i.remove();const t=document.createElement("div");t.id="tt-cue-overlay",t.className="tt-save-overlay",t.innerHTML=`<div class="tt-save-card">
    <h3>My cue — this ${e.scope}</h3>
    <div class="tt-save-sub" style="margin-bottom:10px">A hint in your own words, offered in play under ✎ My cue</div>
    <div class="tt-cue-context">“${Me(e.context)}”</div>
    <input class="tt-cue-input" id="tt-cue-input" placeholder="e.g. where you sit · 6 letters" maxlength="120" />
    <div class="tt-cue-actions">
      ${e.initial?'<span class="tt-cue-remove" id="tt-cue-remove">Remove</span>':""}
      <span class="tt-save-cancel" style="margin:0" id="tt-cue-cancel">Cancel</span>
      <button class="tt-save-create-btn" id="tt-cue-save">Save cue</button>
    </div>
  </div>`,document.body.appendChild(t);const n=t.querySelector("#tt-cue-input");n.value=e.initial,setTimeout(()=>n.focus(),50);const o=()=>t.remove(),s=()=>{const m=n.value.trim();m?e.onSave(m):e.initial&&e.onRemove(),o()};(d=t.querySelector("#tt-cue-save"))==null||d.addEventListener("click",s),n.addEventListener("keydown",m=>{m.key==="Enter"&&s(),m.key==="Escape"&&o(),m.stopPropagation()}),(u=t.querySelector("#tt-cue-cancel"))==null||u.addEventListener("click",o),(h=t.querySelector("#tt-cue-remove"))==null||h.addEventListener("click",()=>{e.onRemove(),o()}),t.addEventListener("click",m=>{m.target===t&&o()})}function Me(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}let qe=1;function j(){const e=window.getSelection();e&&(window.__tiptongClearing=!0,e.removeAllRanges(),window.__tiptongClearing=!1)}function te(e,t,n){const o=[];if(e.startContainer===e.endContainer&&e.startContainer.nodeType===Node.TEXT_NODE){const h=document.createElement("span");return h.className=t,h.dataset.ttId=n,e.surroundContents(h),o.push(h),o}const s=[],i=document.createTreeWalker(e.commonAncestorContainer,NodeFilter.SHOW_TEXT);let d,u=!1;for(;d=i.nextNode();)if(d===e.startContainer)u=!0,s.push({node:d,start:e.startOffset,end:d.textContent.length});else if(d===e.endContainer){s.push({node:d,start:0,end:e.endOffset});break}else u&&s.push({node:d,start:0,end:d.textContent.length});for(let h=s.length-1;h>=0;h--){const{node:m,start:x,end:S}=s[h];if(x===S)continue;const E=document.createRange();E.setStart(m,x),E.setEnd(m,S);const l=document.createElement("span");l.className=t,l.dataset.ttId=n,E.surroundContents(l),o.push(l)}return o.reverse(),o}function Ae(e){const t=document.caretRangeFromPoint(e.clientX,e.clientY);if(!t||t.startContainer.nodeType!==Node.TEXT_NODE)return null;const n=t.startContainer,o=n.textContent||"",s=t.startOffset;if(s>=o.length||o[s]===" "||o[s]===`
`)return null;let i=s;for(;i>0&&o[i-1]!==" "&&o[i-1]!==`
`;)i--;let d=s;for(;d<o.length&&o[d]!==" "&&o[d]!==`
`;)d++;const u=document.createRange();return u.setStart(n,i),u.setEnd(n,d),u}function Re(e,t,n){if(n!=="qa")return;const o=document.createElement("span");o.className=`tt-badge ${t==="answer"?"tt-badge--a":"tt-badge--q"}`,o.setAttribute("data-tt-badge",""),o.textContent=t==="answer"?"A":"Q",e.insertBefore(o,e.firstChild)}function Oe(e){return Array.from(e).filter(t=>/[\p{L}\p{M}'''\-\s]/u.test(t)).join("")}function X(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function ne(e){let t="";for(const n of e.childNodes)if(n.nodeType===Node.TEXT_NODE)t+=n.textContent;else if(n.nodeType===Node.ELEMENT_NODE){const o=n;if(o.dataset.ttHandle||o.hasAttribute("data-tt-badge"))continue;t+=ne(o)}return t}function ze(e){if(e.startContainer.nodeType===Node.TEXT_NODE){const t=e.startContainer.textContent||"";let n=e.startOffset;for(;n>0&&t[n-1]!==" "&&t[n-1]!==`
`;)n--;e.setStart(e.startContainer,n)}if(e.endContainer.nodeType===Node.TEXT_NODE){const t=e.endContainer.textContent||"";let n=e.endOffset;for(;n<t.length&&t[n]!==" "&&t[n]!==`
`;)n++;e.setEnd(e.endContainer,n)}}function We(){Y();const e={mode:"hhh",highlights:[],deleteMode:!1};let t=[];function n(l){var r,b,f,p;let c=l.nodeType===Node.TEXT_NODE?l.parentElement:l;for(;c;){if((r=c.dataset)!=null&&r.ttId)return e.highlights.find(g=>g.id===c.dataset.ttId)??null;if((b=c.classList)!=null&&b.contains("tt-underline")&&((p=(f=c.parentElement)==null?void 0:f.dataset)!=null&&p.ttId))return e.highlights.find(g=>g.id===c.parentElement.dataset.ttId)??null;c=c.parentElement}return null}function o(){if(e.deleteMode){const N=window.getSelection();if(N&&!N.isCollapsed&&N.toString().trim().length>0){e.deleteMode=!1;for(const M of e.highlights)for(const R of M.spans)R.classList.remove("tt-highlight--delete")}else return}const l=window.getSelection();if(!l||l.isCollapsed||!l.rangeCount||!l.toString().trim())return;const r=l.getRangeAt(0),b=document.getElementById("tt-toolbar"),f=document.getElementById("tt-popup");if(b!=null&&b.contains(r.startContainer)){j();return}if(f!=null&&f.contains(r.startContainer)){j();return}ze(r);const p=r.toString().trim();if(!p){j();return}const g=n(r.startContainer),v=n(r.endContainer);if(g&&g===v){if(e.mode==="hhh"&&g.role==="sentence"){j();return}j();return}const y=g||v;if(y){u(y,r),j();return}if(e.mode==="hhh"&&p.split(/\s+/).filter(Boolean).length<2){j();return}const T=e.highlights.filter(N=>N.role!=="sentence").length,_=e.mode==="qa"?T%2===0?"question":"answer":"sentence",C=`tt-${qe++}`,I=te(r,_==="answer"?"tt-highlight tt-highlight--answer":"tt-highlight",C);if(I.length>0){Re(I[0],_,e.mode);const N={id:C,text:p,role:_,spans:I,underlinedWords:[]};e.highlights.push(N),I.forEach(M=>S(M,N))}j()}function s(l,c){const r=l.underlinedWords[c];if(!r)return;const b=r.span.parentNode;if(b){for(;r.span.firstChild;)b.insertBefore(r.span.firstChild,r.span);b.removeChild(r.span),b.normalize()}l.underlinedWords.splice(c,1)}function i(l,c){var p,g;const r=Ae(c);if(!r)return;const b=r.toString().trim();if(!b)return;const f=l.underlinedWords.findIndex(v=>v.span.contains(r.startContainer)||v.text===b);if(f>=0)s(l,f);else{const v=c.target;if((p=v.classList)!=null&&p.contains("tt-underline")||(g=v.closest)!=null&&g.call(v,".tt-underline")){const C=v.classList.contains("tt-underline")?v:v.closest(".tt-underline"),A=l.underlinedWords.findIndex(I=>I.span===C);if(A>=0){s(l,A);return}}const y=l.text.split(/\s+/).filter(Boolean).length,T=Math.floor(y/2);if(l.underlinedWords.length>=T)return;const _=document.createElement("span");_.className="tt-underline";try{r.surroundContents(_),l.underlinedWords.push({text:b,span:_})}catch{}}}function d(l){const c=e.highlights.find(b=>b.id===l);if(!c)return;const r=new Set([l]);if(c.role==="question"||c.role==="answer"){const b=e.highlights.filter(v=>v.role!=="sentence"),f=b.findIndex(v=>v.id===l),g=f%2===0?f+1:f-1;g>=0&&g<b.length&&r.add(b[g].id)}for(const b of r){const f=e.highlights.find(p=>p.id===b);if(f){for(const p of f.underlinedWords){const g=p.span.parentNode;if(g){for(;p.span.firstChild;)g.insertBefore(p.span.firstChild,p.span);g.removeChild(p.span)}}for(const p of f.spans)p.querySelectorAll("[data-tt-badge]").forEach(g=>g.remove());for(const p of f.spans){const g=p.parentNode;if(g){for(;p.firstChild;)g.insertBefore(p.firstChild,p);g.removeChild(p),g.normalize()}}}}e.highlights=e.highlights.filter(b=>!r.has(b.id)),e.highlights.length===0&&(e.deleteMode=!1)}function u(l,c){try{const r=n(c.startContainer)===l,b=n(c.endContainer)===l;if(!r){const f=l.spans[0],p=document.createRange();if(p.setStart(c.startContainer,c.startOffset),p.setEndBefore(f),p.toString().length>0)try{const g=te(p,f.className,l.id);l.spans.unshift(...g);const v=f.querySelector("[data-tt-badge]");v&&g[0]&&g[0].insertBefore(v,g[0].firstChild),g.forEach(y=>S(y,l))}catch{}}if(!b){const f=l.spans[l.spans.length-1],p=document.createRange();if(p.setStartAfter(f),p.setEnd(c.endContainer,c.endOffset),p.toString().length>0)try{const g=te(p,f.className,l.id);l.spans.push(...g),g.forEach(v=>S(v,l))}catch{}}for(l.text=l.spans.map(f=>ne(f)).join("");l.underlinedWords.length>0;)s(l,0)}catch{}}let h=0;function m(l,c){l.classList.toggle("tt-has-cue",!!c),c?l.title=`My cue: ${c}`:l.removeAttribute("title")}function x(l,c){l.addEventListener("pointerdown",r=>{var T,_;if(e.deleteMode)return;const b=r.clientX,f=r.clientY,p=(_=(T=r.target).closest)==null?void 0:_.call(T,".tt-underline");let g=setTimeout(()=>{g=null,h=Date.now()+600,j();const C=p?c.underlinedWords.find(A=>A.span===p):void 0;Ne({context:C?C.text:c.text,scope:C?"word":"exercise",initial:(C?C.cue:c.cue)??"",onSave:A=>{C?(C.cue=A,m(C.span,A)):(c.cue=A,m(c.spans[0],A))},onRemove:()=>{C?(C.cue=void 0,m(C.span,void 0)):(c.cue=void 0,m(c.spans[0],void 0))}})},500);const v=()=>{g&&(clearTimeout(g),g=null),document.removeEventListener("pointermove",y),document.removeEventListener("pointerup",v)},y=C=>{Math.hypot(C.clientX-b,C.clientY-f)>8&&v()};document.addEventListener("pointermove",y),document.addEventListener("pointerup",v)})}function S(l,c){x(l,c),l.addEventListener("click",r=>{var f,p,g,v;if(Date.now()<h){r.preventDefault(),r.stopPropagation();return}if(((p=(f=r.target).closest)==null?void 0:p.call(f,"a"))&&(r.preventDefault(),r.stopPropagation()),e.deleteMode){r.preventDefault(),r.stopPropagation();const y=(v=(g=r.target).closest)==null?void 0:v.call(g,".tt-underline");if(y&&c.role==="sentence"){const T=c.underlinedWords.findIndex(_=>_.span===y);if(T>=0){s(c,T);return}}d(c.id);return}if(e.mode==="hhh"&&!e.deleteMode){const y=window.getSelection();if(y&&!y.isCollapsed)return;r.preventDefault(),r.stopPropagation(),i(c,r)}})}const E=()=>setTimeout(o,10);return document.addEventListener("mouseup",E,!0),{getSelections:()=>e.highlights.map(l=>({id:l.id,text:l.text,role:l.role,underlinedCount:l.underlinedWords.length})),validate:()=>{const l=[];return e.highlights.filter(r=>r.role!=="sentence").length%2!==0&&l.push("Last question needs an answer"),l},getMode:()=>e.mode,setMode:l=>{if(e.mode=l,e.deleteMode){e.deleteMode=!1;for(const c of e.highlights)for(const r of c.spans)r.classList.remove("tt-highlight--delete")}},toggleDeleteMode:()=>{e.deleteMode=!e.deleteMode;for(const l of e.highlights)for(const c of l.spans)c.classList.toggle("tt-highlight--delete",e.deleteMode);return e.deleteMode},isDeleteMode:()=>e.deleteMode,getQAPairs:()=>{const l=e.highlights.filter(r=>r.role!=="sentence"),c=[];for(let r=0;r+1<l.length;r+=2)c.push({question:l[r].text,answer:l[r+1].text});return c},getHHHData:()=>e.highlights.filter(c=>c.role==="sentence").map(c=>{const r=c.text,b=c.underlinedWords.map(f=>{const p=r.indexOf(f.text);return p>=0?{start:p,end:p+f.text.length}:null}).filter(f=>f!==null);return{sourceText:r,sentenceStart:0,sentenceEnd:r.length,underlinedWords:b}}),getOrderedExerciseData:()=>{const l=[];t=[];const c=[...e.highlights].sort((f,p)=>{const g=f.spans[0],v=p.spans[0];if(!g||!v)return 0;const y=g.compareDocumentPosition(v);return y&Node.DOCUMENT_POSITION_FOLLOWING?-1:y&Node.DOCUMENT_POSITION_PRECEDING?1:0}),r=c.filter(f=>f.role!=="sentence"),b=new Set;for(const f of c)if(f.role==="question"){const p=r.indexOf(f),g=Math.floor(p/2);if(b.has(g))continue;const v=r[p+1];v&&(b.add(g),l.push({type:"qa",question:f.text,answer:v.text,cue:f.cue??v.cue}),t.push(v.id))}else{if(f.role==="answer")continue;{const p=f.text;let g=f.underlinedWords.map(v=>{const y=p.indexOf(v.text);return y>=0?{start:y,end:y+v.text.length,cue:v.cue}:null}).filter(v=>v!==null);g.length===0&&f.randomPick&&(g=[{start:f.randomPick.start,end:f.randomPick.end}]),l.push({type:"hhh",sourceText:p,sentenceStart:0,sentenceEnd:p.length,underlinedWords:g,cue:f.cue}),t.push(f.id)}}return l},hideAnswers:()=>{for(const l of e.highlights)if(l.role==="answer")for(const c of l.spans){c.dataset.ttOriginal=c.innerHTML;const r="•".repeat(Math.min(l.text.length,12));c.innerHTML=`<span style="letter-spacing:2px;color:${a.violet};font-weight:bold">${r}</span>`}},hideUnderlinedWords:()=>{for(const l of e.highlights)if(l.role==="sentence")if(l.underlinedWords.length>0)for(const c of l.underlinedWords){c.span.dataset.ttOriginal=c.span.innerHTML;const r="•".repeat(Math.min(c.text.length,8));c.span.innerHTML=`<span style="letter-spacing:2px;color:${a.violet};font-weight:bold">${r}</span>`}else{const c=[];for(const r of l.spans){const b=ne(r),f=/[\p{L}\p{M}'']+/gu;let p;for(;(p=f.exec(b))!==null;)c.push({span:r,text:b,localStart:p.index,localEnd:p.index+p[0].length,word:p[0]})}if(c.length>0){const r=c[Math.floor(Math.random()*c.length)],f=l.text.indexOf(r.word);l.randomPick={text:r.word,start:f>=0?f:0,end:f>=0?f+r.word.length:r.word.length},r.span.dataset.ttOriginal=r.span.innerHTML,r.span.dataset.ttRandomStart=String(r.localStart),r.span.dataset.ttRandomEnd=String(r.localEnd);const p=X(r.text.slice(0,r.localStart)),g="•".repeat(Math.min(r.word.length,8)),v=X(r.text.slice(r.localEnd));r.span.innerHTML=`${p}<span style="letter-spacing:2px;color:${a.violet};font-weight:bold">${g}</span>${v}`}}},revealWord:(l,c)=>{var f;const r=c!=null?t[c]:void 0,b=r?e.highlights.filter(p=>p.id===r):e.highlights;for(const p of b){for(const g of p.underlinedWords)if((g.text.replace(/^[.,;:!?'"()\-–—\s]+|[.,;:!?'"()\-–—\s]+$/g,"")===l||g.text===l)&&g.span.dataset.ttOriginal){g.span.innerHTML=`<span style="color:${a.greenInk};font-weight:bold">${g.span.dataset.ttOriginal}</span>`;return}if(p.role==="sentence"&&((f=p.randomPick)==null?void 0:f.text)===l){for(const g of p.spans)if(g.dataset.ttOriginal&&g.dataset.ttRandomStart){const v=parseInt(g.dataset.ttRandomStart,10),y=parseInt(g.dataset.ttRandomEnd,10),T=document.createElement("span");T.innerHTML=g.dataset.ttOriginal;const _=T.textContent||"",C=X(_.slice(0,v)),A=X(_.slice(v,y)),I=X(_.slice(y));g.innerHTML=`${C}<span style="color:${a.greenInk};font-weight:bold">${A}</span>${I}`;return}}if(p.role==="answer"&&Oe(p.text)===l){for(const g of p.spans)g.dataset.ttOriginal&&(g.innerHTML=`<span style="color:${a.greenInk};font-weight:bold">${g.dataset.ttOriginal}</span>`);return}}},showAnswers:()=>{for(const l of e.highlights){for(const c of l.underlinedWords)c.span.dataset.ttOriginal&&(c.span.innerHTML=c.span.dataset.ttOriginal,delete c.span.dataset.ttOriginal);for(const c of l.spans)c.dataset.ttOriginal&&(c.innerHTML=c.dataset.ttOriginal,delete c.dataset.ttOriginal,delete c.dataset.ttRandomStart,delete c.dataset.ttRandomEnd);delete l.randomPick}},destroy:()=>{for(const l of[...e.highlights])d(l.id);e.highlights=[],document.removeEventListener("mouseup",E,!0)}}}var H=(e=>(e.CHARACTER_PLACEHOLDERS="CHARACTER_PLACEHOLDERS",e.NEXT_LETTER="NEXT_LETTER",e.ALL_VOWELS="ALL_VOWELS",e.ALL_CONSONANTS="ALL_CONSONANTS",e.SHUFFLED_LETTERS="SHUFFLED_LETTERS",e.RANDOM_LETTER="RANDOM_LETTER",e.HANGMAN="HANGMAN",e.FIRST_CONSONANT="FIRST_CONSONANT",e.FIRST_VOWEL="FIRST_VOWEL",e.CONSONANT_LIST="CONSONANT_LIST",e.SELF_AUTHORED="SELF_AUTHORED",e))(H||{});function K(e){return e.normalize("NFD").replace(/[\u0300-\u036f]/g,"")}const J=new Set(["a","e","i","o","u","y"]);function le(e){const t=[...e];for(let n=t.length-1;n>0;n--){const o=Math.floor(Math.random()*(n+1));[t[n],t[o]]=[t[o],t[n]]}return t}function oe(e){return e>0?100/e:0}function De(e,t){let n=0;for(let o=0;o<e.length;o++)t.has(o)&&n++;return n}const Fe={id:H.CHARACTER_PLACEHOLDERS,label:"Show length",icon:"📏",iconName:"ruler",description:"Shows how many characters the word has",repeatable:!1,autoRevealsLength:!0,revealsPositions:!1,costType:"free",modality:"text",group:"reveal",apply(e,t){return{type:this.id,revealedIndices:[],cost:0}}},Pe={id:H.NEXT_LETTER,label:"Next letter",icon:"➡️",iconName:"arrow-right",description:"Reveals the next unrevealed letter from left to right",repeatable:!0,autoRevealsLength:!1,revealsPositions:!0,costType:"per-letter",modality:"text",group:"reveal",apply(e,t){for(let n=0;n<e.length;n++)if(!t.has(n))return{type:this.id,revealedIndices:[n],cost:oe(e.length)};return{type:this.id,revealedIndices:[],cost:0}}},je={id:H.ALL_VOWELS,label:"Vowels",icon:"🔤",iconName:"vowels",description:"Reveals all vowels (a, e, i, o, u, y — including accented)",repeatable:!1,autoRevealsLength:!0,revealsPositions:!0,costType:"proportional",modality:"text",group:"reveal",apply(e,t){const n=e.toLowerCase(),o=[];for(let s=0;s<e.length;s++)J.has(K(n[s]))&&!t.has(s)&&o.push(s);return{type:this.id,revealedIndices:o,cost:e.length>0?o.length/e.length*100:0}}},Be={id:H.ALL_CONSONANTS,label:"Consonants",icon:"🔡",iconName:"consonants",description:"Reveals all consonants (including accented like ç, ñ)",repeatable:!1,autoRevealsLength:!0,revealsPositions:!0,costType:"proportional",modality:"text",group:"reveal",apply(e,t){const n=e.toLowerCase(),o=[];for(let s=0;s<e.length;s++)!J.has(K(n[s]))&&!t.has(s)&&o.push(s);return{type:this.id,revealedIndices:o,cost:e.length>0?o.length/e.length*100:0}}},Ue={id:H.SHUFFLED_LETTERS,label:"Shuffle",icon:"🔀",iconName:"shuffle",description:"Shuffles the letters within each word (doesn't reveal positions)",repeatable:!0,autoRevealsLength:!0,revealsPositions:!1,costType:"flat",flatCost:40,modality:"text",group:"reorder",apply(e,t){const n=e.length-De(e,t);if(n===0)return{type:this.id,revealedIndices:[],cost:0};const o=e.split(" ").map(s=>le(s.split("")).join("")).join(" ");return{type:this.id,revealedIndices:[],cost:40*(n/e.length),displayData:o}}},Qe={id:H.RANDOM_LETTER,label:"Random",icon:"🎲",iconName:"dice",description:"Reveals one random unrevealed letter",repeatable:!0,autoRevealsLength:!0,revealsPositions:!0,costType:"per-letter",modality:"text",group:"reveal",apply(e,t){const n=[];for(let s=0;s<e.length;s++)t.has(s)||n.push(s);if(n.length===0)return{type:this.id,revealedIndices:[],cost:0};const o=n[Math.floor(Math.random()*n.length)];return{type:this.id,revealedIndices:[o],cost:oe(e.length)}}},Ve={id:H.HANGMAN,label:"Structure",icon:"␣",iconName:"slots",description:"Shows the word breaks and punctuation, with a slot for each letter",repeatable:!1,autoRevealsLength:!0,revealsPositions:!0,costType:"proportional",modality:"text",group:"reveal",apply(e,t){const n=[];for(let o=0;o<e.length;o++){const s=e[o];!/[\p{L}\p{N}]/u.test(s)&&!t.has(o)&&n.push(o)}return{type:this.id,revealedIndices:n,cost:e.length>0?n.length/e.length*100:0}}};function de(e,t){return(n,o)=>{const s=n.toLowerCase();for(let i=0;i<n.length;i++){const d=K(s[i]);if(/[a-z]/.test(d)&&J.has(d)===t&&!o.has(i))return{type:e,revealedIndices:[i],cost:oe(n.length)}}return{type:e,revealedIndices:[],cost:0}}}const Ye={id:H.FIRST_CONSONANT,label:"Consonant",icon:"🔡",iconName:"consonant",description:"Reveals the first consonant, then each following one",repeatable:!0,autoRevealsLength:!1,revealsPositions:!0,costType:"per-letter",modality:"text",group:"reveal",apply(e,t){return de(H.FIRST_CONSONANT,!1)(e,t)}},Xe={id:H.FIRST_VOWEL,label:"Vowel",icon:"🔤",iconName:"vowel",description:"Reveals the first vowel, then each following one",repeatable:!0,autoRevealsLength:!1,revealsPositions:!0,costType:"per-letter",modality:"text",group:"reveal",apply(e,t){return de(H.FIRST_VOWEL,!0)(e,t)}},Ge={id:H.CONSONANT_LIST,label:"Consonant list",icon:"🔡",iconName:"list",description:"Lists the consonants you still need in random order, without their positions",repeatable:!1,autoRevealsLength:!1,revealsPositions:!1,costType:"proportional",modality:"text",group:"reorder",apply(e,t){const n=e.toLowerCase(),o=[];for(let s=0;s<e.length;s++){if(t.has(s))continue;const i=n[s],d=K(i);/[a-z]/.test(d)&&!J.has(d)&&o.push(i)}return o.length===0?{type:this.id,revealedIndices:[],cost:0}:{type:this.id,revealedIndices:[],cost:e.length>0?o.length/e.length*50:0,displayData:le(o).join(" ")}}},se=[{id:H.SELF_AUTHORED,label:"My cue",icon:"✎",iconName:"pen",description:"Shows a cue you wrote yourself when creating this exercise",repeatable:!0,autoRevealsLength:!1,revealsPositions:!1,costType:"flat",flatCost:10,modality:"text",group:"reveal",apply(e,t){return{type:this.id,revealedIndices:[],cost:10}}},Fe,Pe,Qe,je,Xe,Be,Ye,Ge,Ue],Ke=[...se,Ve];function Q(e){const t=Ke.find(n=>n.id===e);if(!t)throw new Error(`Unknown hint type: ${e}`);return t}function Je(e,t,n=new Set){return Q(t).apply(e,n)}function ie(e){const t=e.reduce((n,o)=>n+o.cost,0);return Math.min(t,100)}function ce(e,t,n){return e.apply(t,new Set(n))}function ue(e,t,n){return ce(e,t,n).cost}function Ze(e,t,n,o={}){if(t.length===0)return!1;if(e.id===H.CHARACTER_PLACEHOLDERS)return o.lengthAlreadyKnown!==!0;if(e.id===H.SELF_AUTHORED)return o.remainingCues===void 0||o.remainingCues>0;const s=ce(e,t,n);return s.revealedIndices.length>0||s.displayData!==void 0}function et(e,t){return(e??[]).slice(t)}let pe="strict";function Z(){return pe}function tt(e){return e.normalize("NFD").replace(/[̀-ͯ]/g,"")}function he(e,t){const n=e.toLowerCase();return t==="strict"?n:tt(n)}function ee(e,t,n=pe){return t===""?!1:he(e,n)===he(t,n)}function G(e,t=Z()){const n=new Set;return e.blanks.forEach((o,s)=>{(o.revealed||ee(o.expected,o.actual,t))&&n.add(s)}),n}function ge(e){return{exercise:e,hintUsages:[],isComplete:!1,shuffledLettersMap:{}}}function nt(e){return e.blanks.map(t=>t.actual).join("")}function ot(e,t,n,o=Z()){const s=e.exercise.queries.find(x=>x.id===t);if(!s)return e;const i=q(s,o);if(i.correct===i.total)return e;const d=s.blanks.map((x,S)=>{const E=n[S]??"";return x.revealed&&E!==""&&!ee(x.expected,E,o)?{...x,actual:E,revealed:!1}:{...x,actual:E}}),u={...s,blanks:d},h=e.exercise.queries.map(x=>x.id===t?u:x),m={...e.exercise,queries:h};return{...e,exercise:m,isComplete:re(m)}}function st(e,t,n){const o=e.exercise.queries.find(l=>l.id===t);if(!o)return e;const s=Q(n),i=G(o);if(!s.repeatable&&e.hintUsages.some(c=>c.queryId===t&&c.type===n))return e;const d=Je(o.answer,n,i);if(s.id!==H.CHARACTER_PLACEHOLDERS&&d.revealedIndices.length===0&&!d.displayData&&d.cost===0)return e;const u=o.blanks.map((l,c)=>d.revealedIndices.includes(c)?{...l,revealed:!0}:l),h={...o,blanks:u},m=e.exercise.queries.map(l=>l.id===t?h:l),x={queryId:t,type:n,cost:d.cost,usedAt:new Date,displayData:d.displayData},S={...e.exercise,queries:m},E={...e.shuffledLettersMap};return d.displayData&&n==="SHUFFLED_LETTERS"&&(E[t]=d.displayData),{...e,exercise:S,hintUsages:[...e.hintUsages,x],isComplete:re(S),shuffledLettersMap:E}}function it(e,t,n){const o=e.exercise.queries.find(x=>x.id===t);if(!o||n<0||n>=o.blanks.length||G(o).has(n))return e;const s=o.blanks.map((x,S)=>S===n?{...x,revealed:!0}:x),i={...o,blanks:s},d=e.exercise.queries.map(x=>x.id===t?i:x),u=o.answer.length>0?100/o.answer.length:0,h={queryId:t,type:H.NEXT_LETTER,cost:u,usedAt:new Date},m={...e.exercise,queries:d};return{...e,exercise:m,hintUsages:[...e.hintUsages,h],isComplete:re(m)}}function re(e,t=Z()){return e.queries.every(n=>n.blanks.every(o=>ee(o.expected,o.actual,t)))}function q(e,t=Z()){const n=e.blanks.length;return{correct:e.blanks.filter(s=>ee(s.expected,s.actual,t)).length,total:n}}function fe(){return Math.random().toString(36).substring(2,10)}function rt(e){return Array.from(e).filter(t=>/[\p{L}\p{M}'''\-\s]/u.test(t)).join("")}function at(e){return e.split("").map(t=>({expected:t,actual:"",revealed:!1}))}function lt(e){const t=e.match(/^[.,;:!?'"()\-–—\s]+/),n=t?t[0].length:0,o=e.match(/[.,;:!?'"()\-–—\s]+$/),s=o?o[0].length:0;return{cleaned:e.slice(n,e.length-s||void 0),leadingLen:n,trailingLen:s}}function dt(e,t){if(e.length<=1)return e;const n=[...e].sort((s,i)=>s.start-i.start),o=[{...n[0]}];for(let s=1;s<n.length;s++){const i=n[s],d=o[o.length-1];t.slice(d.end,i.start).trim().length===0?d.end=i.end:o.push({...i})}return o}function ct(e){if(!e.sentenceSelection||e.wordSelections.length===0)return null;const t=e.sourceText.slice(e.sentenceSelection.start,e.sentenceSelection.end),n=dt(e.wordSelections,e.sourceText),o=[];let s=t;for(let i=n.length-1;i>=0;i--){const d=n[i],u=d.start-e.sentenceSelection.start,h=d.end-e.sentenceSelection.start,m=t.slice(u,h),{cleaned:x,leadingLen:S,trailingLen:E}=lt(m),l=rt(x);if(l.length===0)continue;const c=u+S,r=h-E,b={id:fe(),answer:l,blanks:at(l),startIndex:c,endIndex:r};o.unshift(b);const f="_".repeat(l.length);s=s.slice(0,c)+f+s.slice(r)}return o.length===0?null:{id:fe(),type:"hhh",originalSentence:t,sentenceWithBlanks:s,queries:o,createdAt:new Date}}function me(){return Math.random().toString(36).substring(2,10)}function ut(e){return Array.from(e).filter(t=>/[\p{L}\p{M}'''\-\s]/u.test(t)).join("")}function pt(e){return e.split("").map(t=>({expected:t,actual:"",revealed:!1}))}function ht(e,t){const n=e.slice(t.question.start,t.question.end).trim(),o=ut(e.slice(t.answer.start,t.answer.end).trim());if(n.length===0||o.length===0)return null;const s={id:me(),answer:o,blanks:pt(o),startIndex:0,endIndex:o.length},i="_".repeat(o.length);return{id:me(),type:"qa",originalSentence:n,sentenceWithBlanks:i,queries:[s],createdAt:new Date}}const be=new Date("2026-09-28");function ve(e){return e.split("").map(t=>({expected:t,actual:"",revealed:!1}))}function $(e,t,n){return{id:e,type:"qa",originalSentence:t,sentenceWithBlanks:"_".repeat(n.length),queries:[{id:`${e}-q1`,answer:n,blanks:ve(n),startIndex:0,endIndex:n.length}],createdAt:be}}function gt(e,t){let n=0;for(;;){const o=e.indexOf(t,n);if(o<0)throw new Error(`Fixture error: "${t}" not found in "${e}"`);const s=e[o-1],i=e[o+t.length],d=u=>u!==void 0&&new RegExp("\\p{L}","u").test(u);if(!d(s)&&!d(i))return o;n=o+1}}function k(e,t,n){const o=n.map((i,d)=>{const u=gt(t,i);return{id:`${e}-q${d+1}`,answer:i,blanks:ve(i),startIndex:u,endIndex:u+i.length}}).sort((i,d)=>i.startIndex-d.startIndex);let s=t;for(const i of o)s=s.slice(0,i.startIndex)+"_".repeat(i.answer.length)+s.slice(i.endIndex);return{id:e,type:"hhh",originalSentence:t,sentenceWithBlanks:s,queries:o,createdAt:be}}$("b1-nl-qa-1","Hoe noem je de persoon die brood en taarten bakt?","de bakker"),$("b1-nl-qa-2","Wat neem je mee als het regent?","een paraplu"),$("b1-nl-qa-3","Hoe noem je het gebouw waar je boeken kunt lenen?","de bibliotheek"),$("b1-nl-qa-4","Welk seizoen komt na de zomer?","de herfst"),$("b1-nl-qa-5","Hoe noem je de dokter die zieke dieren beter maakt?","de dierenarts"),$("b1-nl-qa-6","Hoe noem je het eerste eten van de dag?","het ontbijt"),$("b1-nl-qa-7","Hoe noem je de broer van je moeder?","de oom"),$("b1-nl-qa-8","Waar wacht je op de trein?","op het station"),$("b1-nl-qa-9","Hoe noem je iemand die in een restaurant kookt?","de kok"),$("b1-nl-qa-10","Hoe noem je het geld dat je elke maand verdient?","het salaris"),k("b1-nl-pres-1","Hallo, ik heet Thomas en ik ben dertig jaar oud.",["heet","oud"]),k("b1-nl-pres-2","Ik werk als verpleegkundige in een groot ziekenhuis in Antwerpen.",["verpleegkundige","ziekenhuis"]),k("b1-nl-pres-3","In het weekend ga ik graag wandelen in het bos met mijn hond.",["wandelen","hond"]),k("b1-nl-pres-4","Mijn grootste droom is om een lange reis door Azië te maken.",["droom","reis"]),k("b1-nl-pres-5","Daarom spaar ik elke maand een beetje geld voor die reis.",["spaar","geld"]),k("b1-nl-pres-6","Elke ochtend fiets ik in twintig minuten naar mijn werk.",["twintig minuten","werk"]),k("b1-nl-pres-7","Mijn zus woont in Gent en ik bezoek haar elke zondag.",["woont","elke zondag"]),k("b1-nl-pres-8","Op vrijdag kook ik graag verse soep met groenten uit de tuin.",["verse soep","tuin"]),k("b1-nl-pres-9","Volgend jaar wil ik een cursus Japans volgen voor mijn reis.",["cursus Japans","reis"]),k("b1-nl-pres-10","Mijn hond heet Max en hij wordt volgende maand vier jaar oud.",["volgende maand","vier jaar"]),$("b1-nl-opp-1","Wat is het tegenovergestelde van 'duur'?","goedkoop"),$("b1-nl-opp-2","Wat is het tegenovergestelde van 'groot'?","klein"),$("b1-nl-opp-3","Wat is het tegenovergestelde van 'snel'?","langzaam"),$("b1-nl-opp-4","Wat is het tegenovergestelde van 'makkelijk'?","moeilijk"),$("b1-nl-opp-5","Wat is het tegenovergestelde van 'vol'?","leeg"),$("b1-nl-opp-6","Wat is het tegenovergestelde van 'zwaar'?","licht"),$("b1-nl-opp-7","Wat is het tegenovergestelde van 'schoon'?","vuil"),$("b1-nl-opp-8","Wat is het tegenovergestelde van 'dichtbij'?","ver weg"),$("b1-nl-opp-9","Wat is het tegenovergestelde van 'beginnen'?","stoppen"),$("b1-nl-opp-10","Wat is het tegenovergestelde van 'vroeg'?","laat"),k("b1-nl-city-1","Vanochtend nemen we de trein naar het centrum van Amsterdam.",["de trein","centrum"]),k("b1-nl-city-2","Eerst drinken we koffie met appeltaart in een klein café aan de gracht.",["koffie","gracht"]),k("b1-nl-city-3","Daarna huren we fietsen om door het Vondelpark te rijden.",["huren","fietsen"]),k("b1-nl-city-4","In het museum bekijken we de beroemde schilderijen van Van Gogh.",["museum","beroemde schilderijen"]),k("b1-nl-city-5","Voor de lunch eten we een broodje haring bij een kraampje op de markt.",["broodje haring","markt"]),k("b1-nl-city-6","In de middag maken we een rondvaart door de oude grachten van de stad.",["rondvaart","oude grachten"]),k("b1-nl-city-7","We kopen souvenirs en verse kaas in een gezellige winkel.",["souvenirs","verse kaas"]),k("b1-nl-city-8","Het begint zacht te regenen, dus we schuilen onder een grote paraplu.",["regenen","grote paraplu"]),k("b1-nl-city-9","Voor het diner bestellen we pannenkoeken met stroop en poedersuiker.",["bestellen","pannenkoeken"]),k("b1-nl-city-10","Moe maar gelukkig nemen we de laatste trein terug naar huis.",["laatste trein","huis"]),$("b1-en-qa-1","What do you call the person who flies a plane?","a pilot"),$("b1-en-qa-2","What do you use to open a locked door?","a key"),$("b1-en-qa-3","What do you call the meal you eat in the morning?","breakfast"),$("b1-en-qa-4","Which season comes after winter?","spring"),$("b1-en-qa-5","What do you call the place where you watch films on a big screen?","the cinema"),$("b1-en-qa-6","What do you call the room where you cook your meals?","the kitchen"),$("b1-en-qa-7","What do you call your mother's brother?","your uncle"),$("b1-en-qa-8","Where do you wait for a train?","at the station"),$("b1-en-qa-9","What do you call a person who cooks in a restaurant?","a chef"),$("b1-en-qa-10","What do you call the money you earn every month?","a salary"),k("b1-en-pres-1","Hi, my name is Sarah and I am twenty-eight years old.",["name","old"]),k("b1-en-pres-2","I work as an engineer at a small software company in Manchester.",["engineer","company"]),k("b1-en-pres-3","Every morning I take the train to work and read a book on the way.",["train","book"]),k("b1-en-pres-4","My biggest dream is to open my own restaurant one day.",["dream","restaurant"]),k("b1-en-pres-5","That is why I save money every month and take cooking classes in the evening.",["save","cooking"]),k("b1-en-pres-6","Every evening I cook a new recipe from an old Italian cookbook.",["new recipe","cookbook"]),k("b1-en-pres-7","My brother lives in Leeds and I visit him every weekend.",["lives","every weekend"]),k("b1-en-pres-8","Next year I want to take a business course to learn about restaurants.",["business course","learn"]),k("b1-en-pres-9","My favourite dish is a simple pasta with fresh tomatoes and basil.",["favourite dish","fresh tomatoes"]),k("b1-en-pres-10","With a bit of luck I will open the doors of my restaurant in five years.",["doors","five years"]),$("b1-en-opp-1","What is the opposite of 'expensive'?","cheap"),$("b1-en-opp-2","What is the opposite of 'big'?","small"),$("b1-en-opp-3","What is the opposite of 'fast'?","slow"),$("b1-en-opp-4","What is the opposite of 'easy'?","difficult"),$("b1-en-opp-5","What is the opposite of 'full'?","empty"),$("b1-en-opp-6","What is the opposite of 'heavy'?","light"),$("b1-en-opp-7","What is the opposite of 'clean'?","dirty"),$("b1-en-opp-8","What is the opposite of 'near'?","far away"),$("b1-en-opp-9","What is the opposite of 'to begin'?","to stop"),$("b1-en-opp-10","What is the opposite of 'early'?","late"),k("b1-en-city-1","This morning we take the red bus to the centre of London.",["red bus","centre"]),k("b1-en-city-2","First we drink tea with scones in a small café near the river.",["tea","river"]),k("b1-en-city-3","Then we walk through Hyde Park and feed the friendly ducks.",["walk","friendly ducks"]),k("b1-en-city-4","In the museum we look at old maps and famous paintings.",["museum","famous paintings"]),k("b1-en-city-5","For lunch we eat fish and chips at a busy market.",["lunch","busy market"]),k("b1-en-city-6","In the afternoon we take a boat trip on the River Thames.",["afternoon","boat trip"]),k("b1-en-city-7","We buy postcards and small gifts for our friends at home.",["postcards","small gifts"]),k("b1-en-city-8","It starts to rain softly, so we hide under a large umbrella.",["rain","large umbrella"]),k("b1-en-city-9","For dinner we order hot soup and fresh bread in a warm pub.",["order","hot soup"]),k("b1-en-city-10","Tired but happy, we take the last train back to our hotel.",["last train","hotel"]);function xe(e,t){return e.hintUsages.filter(n=>n.queryId===t&&n.type===H.SELF_AUTHORED).length}function we(e,t,n){const o=e.hintUsages.some(s=>s.queryId===t.id&&Q(s.type).autoRevealsLength);return Ze(n,t.answer,G(t),{lengthAlreadyKnown:o,remainingCues:et(t.customCues,xe(e,t.id)).length})}function ae(e,t,n){const o=e.exercise.queries.find(d=>d.id===t);if(!o)return null;const s=new Set(e.hintUsages.filter(d=>d.queryId===t).map(d=>d.type)),i=se.filter(d=>n!=null&&n.has(d.id)?!1:(!s.has(d.id)||d.repeatable)&&we(e,o,d));return i.length===0?null:i[Math.floor(Math.random()*i.length)]}function ft(e,t){const n=t?e.hintUsages.filter(u=>u.queryId===t):[],o=Math.min(n.reduce((u,h)=>u+h.cost,0),100),s=e.exercise.queries.filter(u=>q(u).correct===q(u).total).map(u=>ie(e.hintUsages.filter(h=>h.queryId===u.id))),i=s.length>0?s.reduce((u,h)=>u+h,0)/s.length:0,d=o<30?a.green:o<60?a.yellow:a.orange;return`
    <div class="tt-help-bar" data-score="${o}">
      <div class="tt-help-bar__labels">
        <span class="tt-help-bar__label">Help used: ${Math.round(o)}%<span class="tt-help-bar__preview"></span></span>
        ${s.length>0?`<span class="tt-help-bar__avg">avg: ${Math.round(i)===0?"Perfect!":Math.round(i)+"%"}</span>`:""}
      </div>
      <div class="tt-help-bar__track">
        <div class="tt-help-bar__fill" style="width:${Math.min(o,100)}%;background:${d}"></div>
        <div class="tt-help-bar__ghost" style="left:${Math.min(o,100)}%"></div>
      </div>
    </div>
  `}const mt=(()=>{try{return localStorage.getItem("tiptong_app_url")??"https://maganino.github.io/TipTong-pilot"}catch{return"https://maganino.github.io/TipTong-pilot"}})();function ye(e,t){var s,i,d;(s=document.getElementById("tt-save-overlay"))==null||s.remove();const n=document.createElement("div");n.id="tt-save-overlay",n.className="tt-save-overlay";const o=e.length;n.innerHTML=`<div class="tt-save-card tt-save-card--invite">
    <div class="tt-save-wordmark">TipTong</div>
    <div class="tt-save-num">${o}</div>
    <div class="tt-save-what">exercise${o!==1?"s":""} ready</div>
    <div class="tt-save-line">Yours to keep — play anywhere, hints and scores included.</div>
    <button class="tt-save-go-btn" id="tt-save-go">▶&nbsp; Save &amp; play in the app</button>
    <div class="tt-save-cancel" id="tt-save-cancel">Not now</div>
  </div>`,document.body.appendChild(n),(i=n.querySelector("#tt-save-go"))==null||i.addEventListener("click",()=>{var S;const u=t&&t.length>0?{exercises:e,scores:t}:e,h=JSON.stringify(u),m=btoa(encodeURIComponent(h).replace(/%([0-9A-F]{2})/g,(E,l)=>String.fromCharCode(parseInt(l,16)))),x=`${mt}/?import=${m}`;typeof chrome<"u"&&((S=chrome.runtime)!=null&&S.sendMessage)?chrome.runtime.sendMessage({type:"tiptong:open-tab",url:x}):window.open(x,"_blank"),n.querySelector(".tt-save-card").innerHTML=`
      <div class="tt-save-done-ring">&#10003;</div>
      <div class="tt-save-what">Off to the app</div>
      <div class="tt-save-line" style="margin-bottom:8px">Pick a playlist there to finish</div>
    `,setTimeout(()=>n.remove(),2e3)}),(d=n.querySelector("#tt-save-cancel"))==null||d.addEventListener("click",()=>n.remove()),n.addEventListener("click",u=>{u.target===n&&n.remove()})}function bt(e,t){var d,u;const n=new Array(e.blanks.length).fill(null),o=new Set;for(let h=0;h<e.blanks.length;h++){const m=e.blanks[h];if(m.revealed||m.actual!==""&&m.actual.toLowerCase()===m.expected.toLowerCase()){if(!o.has(h)&&((d=t[h])==null?void 0:d.toLowerCase())===m.expected.toLowerCase())o.add(h);else for(let x=0;x<t.length;x++)if(!o.has(x)&&((u=t[x])==null?void 0:u.toLowerCase())===m.expected.toLowerCase()){o.add(x);break}}}const s=[];for(let h=0;h<t.length;h++)!o.has(h)&&t[h]!==" "&&s.push(t[h]);let i=0;for(let h=0;h<e.blanks.length;h++){const m=e.blanks[h];m.expected===" "||m.revealed||m.actual!==""&&m.actual.toLowerCase()===m.expected.toLowerCase()||m.actual===""&&i<s.length&&(n[h]=s[i],i++)}return n}function $e(e,t){return t.some(n=>n.queryId!==e?!1:Q(n.type).autoRevealsLength)}function ke(e,t){if(!e.blanks.some(d=>d.actual!==""||d.revealed))return`<span class="tt-inline-blank ${t?"tt-inline-blank--active":""}" data-query="${e.id}">···</span>`;let o=-1;for(let d=e.blanks.length-1;d>=0;d--){const u=e.blanks[d];if(u.revealed||u.actual!==""){o=d;break}}const s=o<e.blanks.length-1;let i=`<span class="tt-inline-blank" data-query="${e.id}">`;for(let d=0;d<=o;d++){const u=e.blanks[d];if(u.expected===" ")i+=" ";else if(u.revealed)i+=`<span class="tt-inline-char tt-inline-char--revealed">${u.expected}</span>`;else if(u.actual==="")i+='<span class="tt-inline-char tt-inline-char--empty">·</span>';else{const h=u.actual.toLowerCase()===u.expected.toLowerCase();i+=`<span class="tt-inline-char ${h?"tt-inline-char--correct":"tt-inline-char--wrong"}">${u.actual}</span>`}}return s&&(i+='<span class="tt-inline-char tt-inline-char--empty">...</span>'),i+="</span>",i}function Se(e,t,n){const o=n?bt(e,n):null;let s='<div class="tt-blanks">';for(let i=0;i<e.blanks.length;i++){const d=e.blanks[i];if(d.expected===" "){s+='<div class="tt-blank-word-gap"></div>';continue}const u=d.actual!=="",h=d.revealed,m=u&&d.actual.toLowerCase()===d.expected.toLowerCase(),x=u&&!m&&!h,S=o==null?void 0:o[i],E=!h&&!u&&!!S;let l="tt-blank";h?l+=" tt-blank--revealed":m?l+=" tt-blank--correct":x?l+=" tt-blank--wrong":E&&(l+=" tt-blank--shuffled"),t&&(l+=" tt-blank--active");const c=h?d.expected:u?d.actual:E?S:" ";s+=`<div class="${l}" data-reveal-char="${i}" data-reveal-query="${e.id}" style="cursor:pointer">${c}</div>`}return s+="</div>",s}function vt(e){const t=e.state,{exercise:n}=t,{originalSentence:o,queries:s}=n;let i="",d=0;for(const u of s){u.startIndex>d&&(i+=`<span class="tt-sentence-text">${U(o.slice(d,u.startIndex))}</span>`);const h=q(u),m=h.correct===h.total,x=$e(u.id,t.hintUsages),S=e.activeQueryId===u.id,E=t.shuffledLettersMap[u.id];m?i+=`<span class="tt-solved">${U(u.answer)}</span>`:x?i+=`<span data-query="${u.id}">${Se(u,S,E)}</span>`:i+=ke(u,S),d=u.endIndex}return d<o.length&&(i+=`<span class="tt-sentence-text">${U(o.slice(d))}</span>`),i}function xt(e){const t=e.state.exercise.queries;if(t.length<=1)return"";let n='<div class="tt-word-progress">';for(let o=0;o<t.length;o++){const s=t[o],i=q(s).correct===q(s).total,d=e.activeQueryId===s.id;let u="tt-word-dot";i&&(u+=" tt-word-dot--done"),d&&(u+=" tt-word-dot--active"),n+=`<span class="${u}" data-query-dot="${s.id}">${i?"✓":o+1}</span>`}return n+="</div>",n}function wt(e,t){const n=e.exercise.queries.find(i=>i.id===t);if(!n)return"";const o=new Set(e.hintUsages.filter(i=>i.queryId===t).map(i=>i.type));let s='<div class="tt-hints">';for(const i of se){const u=o.has(i.id)&&!i.repeatable||!we(e,n,i),h=`tt-hint-chip${u?" tt-hint-chip--disabled":""}`,m=u?0:ue(i,n.answer,G(n)),x=m>0?`${i.description} — costs ${m}% help`:i.description;s+=`<button class="${h}" data-hint="${i.id}" data-cost="${m}" title="${x}"${u?" disabled":""}>${i.icon} ${i.label.split(" ")[0]}</button>`}return s+="</div>",s}function yt(e,t){const n=Math.round(t)===0?"Perfect!":`Help: ${Math.round(t)}%`,o=t<30?a.green:t<60?a.yellow:a.orange,s=document.createElement("div");s.className="tt-query-score",s.style.cssText=`
    text-align:center;padding:6px 12px;margin:4px 0;
    border-radius: ${L.sm};font-size: ${w.small};font-weight:700;
    color:${o};background:${o}15;
    animation:tt-fade-in 0.2s ease;
  `,s.textContent=n;const i=e.querySelector(".tt-answer-box");i?i.parentNode.insertBefore(s,i):e.appendChild(s)}function O(e){var c;if(!e.state||!e.popup)return;const{exercise:t}=e.state,n=e.popup.querySelector(".tt-popup__body");if(!n)return;if(e.minimized){n.style.display="none";return}n.style.display="block",t.type;const o=t.type==="hhh";if(!e.activeQueryId){const r=t.queries.find(b=>q(b).correct!==q(b).total);r&&(e.activeQueryId=r.id)}if(t.queries.every(r=>q(r).correct===q(r).total)){const r=e.currentIndex>=e.exercises.length-1,b=ie(e.state.hintUsages),f=Math.round(b)===0?"Perfect!":`Help needed: ${Math.round(b)}%`;n.innerHTML=`
      <div class="tt-complete">
        <div class="tt-complete__check">&#10003;</div>
        <p style="font-size: ${w.body};margin:8px 0">${U(t.originalSentence)}</p>
        <p style="font-size: ${w.small};color:${b<30?a.green:b<60?a.yellow:a.orange};font-weight:600;margin:4px 0">${f}</p>
        ${r?`<button class="tt-hint-chip" style="margin-top:16px;font-size:${w.small}" data-action="close">Done</button>`:`<button class="tt-hint-chip" style="margin-top:16px;font-size:${w.small}" data-action="next">Next &rarr;</button>`}
        ${r?`<button class="tt-hint-chip" style="margin-top:8px;font-size:${w.small};border:1px solid ${a.yellow};color:${a.yellow}" data-action="save">Save to playlist</button>`:""}
      </div>
    `,Ee(e);return}const i=t.queries.find(r=>r.id===e.activeQueryId)??null,d=i?t.queries.indexOf(i):-1;let u="";if(o)u+=`<div class="tt-sentence">${vt(e)}</div>`,u+=xt(e);else if(u+=`<div class="tt-popup__question">${U(t.originalSentence)} ?</div>`,i){const r=$e(i.id,e.state.hintUsages),b=e.state.shuffledLettersMap[i.id];r?u+=Se(i,!0,b):u+=ke(i,!0)}if(i){const r=nt(i),b=o?`${d+1}/${t.queries.length}`:"Type the answer",f=e.flashHint?`<span class="tt-hint-flash-inline">${e.flashHint.icon} ${e.flashHint.label}</span>`:"",p=e.suggestedFor===i.id?e.suggested:null,g=!e.showHints&&!e.flashHint&&p?`<button class="tt-hint-flash-inline tt-hint-chip--suggested" id="tt-suggested">${p.icon} ${p.label.split(" ")[0]} · ${ue(p,i.answer,G(i))}%</button>`:"",v=e.showHints?`<div class="tt-hints-inline">${wt(e.state,i.id)}</div>`:"",T=(i.customCues??[]).slice(0,xe(e.state,i.id)),_=T.length>0?`<div class="tt-cue-reveal">${T.map(C=>`<div>✎ ${U(C)}</div>`).join("")}</div>`:"";u+=`
      <div class="tt-answer-box">
        <div class="tt-answer-header">
          <span class="tt-answer-label">${b}</span>
          ${v}
          <div style="display:flex;align-items:center;margin-left:auto;gap:4px">
            ${f}${g}
            <button class="tt-bulb ${e.showHints?"tt-bulb--active":""}" id="tt-bulb">💡</button>
          </div>
        </div>
        ${_}
        <input class="tt-input" value="${U(r)}" placeholder="Type here..." autocomplete="off" autocorrect="off" autocapitalize="off" />
      </div>
    `}u+=ft(e.state,e.activeQueryId),u+=`<div class="tt-score">Exercise ${e.currentIndex+1} of ${e.exercises.length}</div>`,n.innerHTML=u;const h=r=>{!e.state||!i||(e.state=st(e.state,i.id,r.id),e.flashHint=r,e.suggested=null,e.suggestedFor=null,e.showHints=!1,O(e),setTimeout(()=>{e.flashHint===r&&(e.flashHint=null,O(e))},2e3))},m=n.querySelector("#tt-bulb");if(m&&i){let f=null,p=!1,g=!1,v=0,y=0,T=null;const _=()=>{T==null||T.classList.remove("tt-hint-chip--tracked"),T=null},C=(I,N)=>{var R,_e;const M=(_e=(R=document.elementFromPoint(I,N))==null?void 0:R.closest)==null?void 0:_e.call(R,"[data-hint]");M!==T&&(_(),M&&!M.hasAttribute("disabled")&&(T=M,M.classList.add("tt-hint-chip--tracked")))},A=()=>{if(!e.state)return;const I=new Set;e.suggested&&I.add(e.suggested.id),e.lastSuggestion&&I.add(e.lastSuggestion);const N=e.suggested?new Set([e.suggested.id]):void 0,M=ae(e.state,i.id,I)??ae(e.state,i.id,N)??ae(e.state,i.id);M&&(e.lastSuggestion=M.id,e.suggested=M,e.suggestedFor=i.id,e.flashHint=null,O(e))};m.addEventListener("pointerdown",I=>{I.preventDefault(),p=!1,g=!1,v=I.clientX,y=I.clientY,e.showHints||(f=setTimeout(()=>{f=null,g=!0,e.suggested=null,e.suggestedFor=null,e.flashHint=null,e.showHints=!0,O(e)},300));const N=R=>{!p&&Math.hypot(R.clientX-v,R.clientY-y)>10&&(p=!0),e.showHints&&C(R.clientX,R.clientY)},M=()=>{if(document.removeEventListener("pointermove",N),f&&(clearTimeout(f),f=null),e.showHints){const R=T;_(),R?h(Q(R.dataset.hint)):!g&&!p&&(e.showHints=!1,O(e))}else p||A()};document.addEventListener("pointermove",N),document.addEventListener("pointerup",M,{once:!0})}),m.addEventListener("contextmenu",I=>I.preventDefault())}(c=n.querySelector("#tt-suggested"))==null||c.addEventListener("click",()=>{const r=e.suggestedFor===(i==null?void 0:i.id)?e.suggested:null;r&&h(r)});const x=n.querySelector(".tt-input");x&&i&&(x.focus(),x.setSelectionRange(x.value.length,x.value.length),x.addEventListener("input",()=>{var f;if(!e.state||!i)return;e.flashHint=null,e.state=ot(e.state,i.id,x.value);const r=e.state.exercise.queries.find(p=>p.id===i.id),b=q(r);if(b.correct===b.total){(f=e.onWordComplete)==null||f.call(e,r.answer,e.currentIndex);const p=e.state.hintUsages.filter(y=>y.queryId===i.id),g=ie(p);e.completedScores.push({exerciseId:e.state.exercise.id,queryId:i.id,score:g,hintUsages:p.map(y=>({type:y.type,cost:y.cost}))});const v=e.state.exercise.queries.find(y=>y.id!==i.id&&q(y).correct!==q(y).total);if(v){yt(n,g),setTimeout(()=>{e.activeQueryId=v.id,O(e)},1200);return}}O(e)}));const S=n.querySelector(".tt-help-bar"),E=n.querySelector(".tt-help-bar__ghost"),l=n.querySelector(".tt-help-bar__preview");n.querySelectorAll("[data-hint]").forEach(r=>{r.addEventListener("click",()=>{!e.state||!i||h(Q(r.dataset.hint))}),r.addEventListener("mouseenter",()=>{const b=Number(r.dataset.cost??0);if(!S||!E||b<=0)return;const f=Number(S.dataset.score??0);E.style.width=`${Math.max(0,Math.min(b,100-f))}%`,l&&(l.textContent=` → ${Math.min(Math.round(f+b),100)}%`)}),r.addEventListener("mouseleave",()=>{E&&(E.style.width="0%"),l&&(l.textContent="")})}),n.querySelectorAll("[data-reveal-char]").forEach(r=>{r.addEventListener("click",b=>{var v;if(b.stopPropagation(),!e.state)return;const f=parseInt(r.dataset.revealChar,10),p=r.dataset.revealQuery;e.activeQueryId!==p&&(e.activeQueryId=p),e.state=it(e.state,p,f);const g=e.state.exercise.queries.find(y=>y.id===p);if(g){const y=q(g);y.correct===y.total&&((v=e.onWordComplete)==null||v.call(e,g.answer,e.currentIndex))}O(e)})}),n.querySelectorAll("[data-query]").forEach(r=>{r.addEventListener("click",()=>{const b=r.dataset.query;e.activeQueryId!==b&&(e.activeQueryId=b,O(e))})}),n.querySelectorAll("[data-query-dot]").forEach(r=>{r.addEventListener("click",()=>{const b=r.dataset.queryDot;e.activeQueryId=b,e.showHints=!1,e.flashHint=null,O(e)})}),Ee(e)}function Ee(e){var t,n;e.popup&&(e.popup.querySelectorAll("[data-action]").forEach(o=>{o.addEventListener("click",()=>{const s=o.dataset.action;s==="next"?(e.currentIndex++,e.activeQueryId=null,e.showHints=!1,e.flashHint=null,e.currentIndex<e.exercises.length&&(e.state=ge(e.exercises[e.currentIndex]),O(e))):s==="close"?Le(e):s==="save"&&ye(e.exercises,e.completedScores)})}),(t=e.popup.querySelector(".tt-popup__close"))==null||t.addEventListener("click",()=>{Le(e)}),(n=e.popup.querySelector(".tt-popup__minimize"))==null||n.addEventListener("click",()=>{e.minimized=!e.minimized;const o=e.popup.querySelector(".tt-popup__minimize");o&&(o.textContent=e.minimized?"▲":"▼"),O(e)}))}function Le(e){var t,n;e._keyHandler&&document.removeEventListener("keydown",e._keyHandler),(t=e.popup)==null||t.remove(),e.popup=null,(n=e.onClose)==null||n.call(e)}function U(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function $t(e,t){var i;Y(),(i=document.getElementById("tt-popup"))==null||i.remove();const n=document.createElement("div");n.id="tt-popup",n.className="tt-popup",n.innerHTML=`
    <div class="tt-popup__header">
      <span class="tt-popup__title">TipTong</span>
      <div style="display:flex;gap:8px">
        <button class="tt-popup__minimize" title="Minimize">▼</button>
        <button class="tt-popup__close" title="Close">&times;</button>
      </div>
    </div>
    <div class="tt-popup__body"></div>
  `,document.body.appendChild(n);const o={exercises:e,currentIndex:0,state:e.length>0?ge(e[0]):null,activeQueryId:null,showHints:!1,flashHint:null,minimized:!1,popup:n,suggested:null,suggestedFor:null,lastSuggestion:null,completedScores:[],onClose:t==null?void 0:t.onClose,onWordComplete:t==null?void 0:t.onWordComplete},s=d=>{if(d.key!=="Enter"||!o.popup)return;const u=o.popup.querySelector("[data-action='next']"),h=o.popup.querySelector("[data-action='close']");u?(d.preventDefault(),u.click()):h&&(d.preventDefault(),h.click())};document.addEventListener("keydown",s),o._keyHandler=s,O(o)}function kt(e,t,n){const o=e.slice(t,n),s=[],i=/[\p{L}\p{M}'']+/gu;let d;for(;(d=i.exec(o))!==null;)s.push({start:t+d.index,end:t+d.index+d[0].length});return s.length===0?{start:t,end:n}:s[Math.floor(Math.random()*s.length)]}function Ce(e,t){if(t.cue&&(e.queries=e.queries.map(n=>({...n,customCues:[t.cue]}))),t.type==="hhh")for(const n of t.underlinedWords){if(!n.cue)continue;const o=n.start-t.sentenceStart,s=n.end-t.sentenceStart,i=e.queries.find(d=>d.startIndex<s&&d.endIndex>o);i&&(i.customCues=[...i.customCues??[],n.cue])}return e}function Te(e){const t=[];for(const n of e)if(n.type==="qa"){const o=n.question+" "+n.answer,s=ht(o,{question:{start:0,end:n.question.length},answer:{start:n.question.length+1,end:o.length}});s&&t.push(Ce(s,n))}else{let o=n.underlinedWords;o.length===0&&(o=[kt(n.sourceText,n.sentenceStart,n.sentenceEnd)]);const s=ct({sourceText:n.sourceText,sentenceSelection:{start:n.sentenceStart,end:n.sentenceEnd},wordSelections:o});s&&t.push(Ce(s,n))}return t}function St(e,t){$t(Te(e),t)}function Et(e){const t=Te(e);return t.length===0?!1:(Y(),ye(t),!0)}const D={green:F.brandEnergeticGreen,orange:F.brandBrightOrange,dark:F.brandDarkViolet},P={display:z.familyDisplay,sans:z.familySans,body:z.sizeBody,small:z.sizeSmall},V={lg:B.lg};function Lt(){return window.__pdfReady?Promise.resolve():new Promise(e=>{document.addEventListener("tiptong:pdf-ready",()=>e(),{once:!0}),setTimeout(()=>e(),5e3)})}async function Ct(){await Lt(),Y();const e=document.getElementById("pdf-container"),t=document.createElement("div");t.id="tt-toolbar",t.style.cssText=`
    position: fixed; top: 0; left: 0; right: 0; z-index: 999998;
    background: ${W.gradient}; padding: 10px 16px;
    display: flex; align-items: center; gap: 10px;
    border-bottom: ${W.cardBorder};
    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    font-family: ${P.sans};
  `,t.innerHTML=`
    <span style="color:${D.green};font-family:${P.display};font-weight:800;font-size: ${P.body}">TipTong</span>
    <span style="color:rgba(255,255,255,0.4);font-size: ${P.small};margin-right:auto">PDF</span>
    <div style="display:flex;background:rgba(255,255,255,0.15);border-radius: ${V.lg};overflow:hidden">
      <button data-tt-mode="hhh" style="background:transparent;border:none;color:rgba(255,255,255,0.7);padding:6px 12px;font-size: ${P.small};font-weight:600;cursor:pointer;border-radius: ${V.lg}">HHH</button>
      <button data-tt-mode="qa" style="background:white;border:none;color:${D.dark};padding:6px 12px;font-size: ${P.small};font-weight:600;cursor:pointer;border-radius: ${V.lg}">Q&A</button>
    </div>
    <button id="tt-delete-btn" style="background:transparent;border:1px solid rgba(255,138,0,0.5);color:${D.orange};padding:6px 12px;font-size: ${P.small};font-weight:600;cursor:pointer;border-radius: ${V.lg}">Delete</button>
    <span id="tt-status" style="color:rgba(255,255,255,0.7);font-size: ${P.small}">Select text to highlight</span>
    <button id="tt-save-btn" style="background:transparent;border:1px solid ${D.green};color:${D.green};padding:6px 14px;font-size: ${P.small};font-weight:bold;cursor:pointer;border-radius: ${V.lg}">Save</button>
    <button id="tt-play-btn" style="background:${D.green};border:none;color:${D.dark};padding:6px 16px;font-size: ${P.small};font-weight:bold;cursor:pointer;border-radius: ${V.lg}">Play</button>
  `,document.body.appendChild(t),e&&(e.style.top=t.offsetHeight+"px");const n=We(),o=t.querySelector("#tt-status");t.querySelectorAll("[data-tt-mode]").forEach(h=>{h.addEventListener("click",()=>{t.querySelectorAll("[data-tt-mode]").forEach(m=>{m.style.background="transparent",m.style.color="rgba(255,255,255,0.7)"}),h.style.background="white",h.style.color=D.dark,n.setMode(h.dataset.ttMode),d()})});const s=t.querySelector("#tt-delete-btn");s.addEventListener("click",()=>{const h=n.toggleDeleteMode();s.style.background=h?D.orange:"transparent",s.style.color=h?"white":D.orange,s.textContent=h?"Done":"Delete"}),t.querySelector("#tt-save-btn").addEventListener("click",()=>{const h=n.validate();if(h.length>0){i(h[0]);return}const m=n.getOrderedExerciseData();if(m.length===0){o.textContent="No highlights yet";return}Et(m)||(o.textContent="No complete exercises")}),t.querySelector("#tt-play-btn").addEventListener("click",()=>{if(n.getSelections().length===0){o.textContent="No highlights yet";return}const m=n.validate();if(m.length>0){i(m[0]);return}n.isDeleteMode()&&n.toggleDeleteMode(),s.style.display="none",n.showAnswers(),n.hideAnswers(),n.hideUnderlinedWords();const x=n.getOrderedExerciseData();if(x.length===0){o.textContent="No complete exercises",s.style.display="";return}St(x,{onClose:()=>{n.showAnswers(),s.style.display=""},onWordComplete:S=>n.revealWord(S)})});function i(h){var x;(x=document.querySelector(".tt-toast"))==null||x.remove();const m=document.createElement("div");m.className="tt-toast",m.textContent="⚠ "+h,document.body.appendChild(m),setTimeout(()=>m.remove(),3e3)}function d(){n.isDeleteMode()||(s.style.background="transparent",s.style.color=D.orange,s.textContent="Delete");const h=n.getSelections();if(h.length===0){o.textContent="Select text to highlight";return}const m=h.filter(E=>E.role!=="sentence"),x=h.filter(E=>E.role==="sentence"),S=[];if(m.length>0){const E=Math.floor(m.length/2);S.push(`${E} Q&A${m.length%2!==0?" · answer next":""}`)}x.length>0&&S.push(`${x.length} HHH`),o.textContent=S.join(" + ")}const u=()=>setTimeout(d,50);document.addEventListener("mouseup",u)}Ct()})();
