/*! TipTong Extension — © 2026 TipTong. All rights reserved.
 * Proprietary software. No license is granted to copy, modify, or redistribute. */(function(){"use strict";const Y={brandElectricViolet:"#4E15FF",brandEnergeticGreen:"#0FFFB9",brandDarkViolet:"#160751",brandBrightOrange:"#FF5400",brandBrightYellow:"#FFDE00",brandWhite:"#FFFFFF",supportLavender:"#B6A6EB"},F={familyDisplay:"Bryant, Nunito, Montserrat, system-ui, sans-serif",familySans:'Montserrat, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif',sizeHero:"48px",sizeH1:"32px",sizeH2:"24px",sizeLabel:"18px",sizeBody:"16px",sizeSmall:"14px"},ee={tile:"2px",sm:"5px",md:"12px",lg:"16px",xl:"24px",pill:"100px"},C={display:F.familyDisplay,sans:F.familySans,hero:F.sizeHero,h1:F.sizeH1,h2:F.sizeH2,label:F.sizeLabel,body:F.sizeBody,small:F.sizeSmall},N={tile:ee.tile,sm:ee.sm,md:ee.md,lg:ee.lg,xl:ee.xl,pill:ee.pill},a={violet:Y.brandElectricViolet,green:Y.brandEnergeticGreen,orange:Y.brandBrightOrange,yellow:Y.brandBrightYellow,dark:Y.brandDarkViolet,white:Y.brandWhite,lavender:Y.supportLavender,greenInk:"#0A9E74"},U={gradient:`linear-gradient(170deg, #14406B 0%, #16265C 55%, ${a.dark} 100%)`,card:"rgba(255,255,255,0.06)",cardBorder:"1px solid rgba(255,255,255,0.12)"},ut=`
.tt-highlight {
  background-color: ${a.violet}20 !important;
  border-bottom: 2px solid ${a.violet}60 !important;
  border-radius: ${N.tile} !important;
  cursor: pointer !important;
  transition: background-color 0.15s !important;
  position: relative !important;
  display: inline !important;
}
.tt-highlight:hover {
  background-color: ${a.violet}35 !important;
}
.tt-highlight--answer {
  background-color: ${a.green}20 !important;
  border-bottom-color: ${a.green}60 !important;
}
.tt-highlight--answer:hover {
  background-color: ${a.green}35 !important;
}
.tt-highlight--delete {
  background-color: ${a.orange}20 !important;
  border-bottom-color: ${a.orange} !important;
  text-decoration: line-through !important;
  cursor: pointer !important;
}
.tt-underline {
  border-bottom: 2px dotted ${a.green} !important;
  font-weight: bold !important;
  background-color: ${a.green}20 !important;
  border-radius: ${N.tile} !important;
  cursor: pointer !important;
}
.tt-badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 16px;
  height: 16px;
  border-radius: ${N.sm};
  color: white;
  font-size: ${C.small};
  font-weight: bold;
  margin-right: 3px;
  vertical-align: middle;
  line-height: 16px;
}
.tt-badge--q { background-color: ${a.violet}; }
.tt-badge--a { background-color: ${a.green}; }

/* Interactive sentence (HHH inline blanks) */
.tt-sentence {
  font-size: ${C.body};
  line-height: 2;
  background: ${U.card};
  border: ${U.cardBorder};
  border-radius: ${N.md};
  padding: 12px 16px;
  margin-bottom: 12px;
  color: ${a.white};
}
.tt-sentence-text { color: ${a.white}; }
.tt-inline-blank {
  font-weight: bold;
  color: ${a.lavender};
  background: ${a.white}10;
  border-radius: ${N.sm};
  padding: 2px 6px;
  cursor: pointer;
}
.tt-inline-blank--active {
  background: ${a.green}20;
  color: ${a.green};
}
.tt-inline-char { font-size: ${C.body}; }
.tt-inline-char--revealed { color: ${a.white}; background: ${a.green}; border-radius: ${N.tile}; padding: 0 1px; }
.tt-inline-char--correct { color: ${a.green}; font-weight: bold; }
.tt-inline-char--wrong { color: ${a.orange}; font-weight: bold; }
.tt-inline-char--empty { color: ${a.white}30; }
.tt-solved {
  font-weight: bold;
  color: ${a.green};
  background: ${a.green}10;
  border-radius: ${N.sm};
  padding: 2px 4px;
}

/* Word progress dots */
.tt-word-progress {
  display: flex;
  gap: 12px;
  justify-content: center;
  margin-bottom: 12px;
}
.tt-word-dot {
  width: 24px;
  height: 24px;
  border-radius: ${N.md};
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: ${C.small};
  font-weight: 600;
  cursor: pointer;
  background: ${a.white}20;
  color: ${a.white};
  opacity: 0.6;
}
.tt-word-dot--done { background: ${a.green}; opacity: 1; }
.tt-word-dot--active { background: ${a.white}; color: ${a.green}; border: 2px solid ${a.green}; opacity: 1; }

/* Answer box */
.tt-answer-box {
  background: ${a.white}10;
  border-radius: ${N.md};
  padding: 12px;
  margin-top: 8px;
  border: 1px solid ${a.green}40;
}
.tt-answer-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}
.tt-answer-label {
  font-size: ${C.small};
  color: ${a.white};
  opacity: 0.6;
  text-transform: uppercase;
  letter-spacing: 1px;
}
.tt-bulb {
  /* The browser must not turn the fan drag into a scroll or text selection. */
  touch-action: none;
  user-select: none;
  background: ${a.white}15;
  border: none;
  border-radius: ${N.lg};
  width: 32px;
  height: 32px;
  font-size: ${C.body};
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
}
.tt-bulb:hover, .tt-bulb--active { background: ${a.yellow}40; }
.tt-hint-container { margin-bottom: 8px; }
.tt-blank--active { border-bottom-color: ${a.green}; }

/* Player popup */
.tt-popup {
  position: fixed;
  bottom: 20px;
  right: 20px;
  width: 380px;
  max-width: calc(100vw - 40px);
  background: ${U.gradient};
  border: ${U.cardBorder};
  border-radius: ${N.xl};
  box-shadow: 0 8px 32px rgba(0,0,0,0.4);
  z-index: 999999;
  font-family: ${C.sans};
  color: ${a.white};
  overflow: hidden;
}
.tt-popup__header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 16px;
  background: ${U.card};
  border-bottom: ${U.cardBorder};
}
.tt-popup__title {
  font-family: ${C.display};
  font-size: ${C.small};
  font-weight: 800;
  letter-spacing: 0.02em;
  color: ${a.green};
}
.tt-popup__close {
  background: none;
  border: none;
  color: ${a.white};
  font-size: ${C.label};
  cursor: pointer;
  opacity: 0.7;
  padding: 4px;
}
.tt-popup__minimize {
  background: none;
  border: none;
  color: ${a.white};
  font-size: ${C.small};
  cursor: pointer;
  opacity: 0.7;
  padding: 4px;
}
.tt-popup__close:hover, .tt-popup__minimize:hover { opacity: 1; }
.tt-popup__body {
  padding: 16px;
}
.tt-popup__question {
  font-size: ${C.body};
  line-height: 1.5;
  margin-bottom: 16px;
  color: ${a.white};
}

/* Blank boxes */
.tt-blanks {
  display: flex;
  flex-wrap: wrap;
  gap: 3px;
  margin-bottom: 12px;
}
.tt-blank-word-gap { width: 12px; }
.tt-blank {
  width: 22px;
  height: 28px;
  border-radius: ${N.sm};
  background: ${a.white}15;
  border-bottom: 2px solid ${a.violet}40;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: ${C.small};
  font-weight: bold;
  color: ${a.white}50;
}
.tt-blank--correct {
  color: ${a.green};
  background: ${a.green}15;
  border-bottom-color: ${a.green};
}
.tt-blank--wrong {
  color: ${a.orange};
  background: ${a.orange}15;
  border-bottom-color: ${a.orange};
}
.tt-blank--revealed {
  color: ${a.white};
  background: ${a.green};
  border-bottom-color: ${a.green};
}
.tt-blank--shuffled {
  color: ${a.yellow};
  background: ${a.yellow}15;
  border-bottom-color: ${a.yellow}40;
}

/* Input */
.tt-input {
  width: 100%;
  height: 40px;
  background: ${a.white}15;
  border: none;
  border-radius: ${N.sm};
  color: ${a.white};
  font-size: ${C.body};
  text-align: center;
  font-weight: 600;
  outline: none;
  box-sizing: border-box;
  padding: 0 12px;
}
.tt-input::placeholder { color: ${a.white}40; }
.tt-input:focus { box-shadow: 0 0 0 2px ${a.green}60; }

/* Hint bar */
.tt-hints {
  display: flex;
  gap: 6px;
  overflow-x: auto;
  padding: 8px 0;
  scrollbar-width: none;
}
.tt-hints::-webkit-scrollbar { display: none; }
.tt-hint-chip {
  display: flex;
  align-items: center;
  gap: 4px;
  background: ${a.white}15;
  border: none;
  border-radius: ${N.lg};
  padding: 6px 10px;
  color: ${a.white};
  font-size: ${C.small};
  font-weight: 600;
  cursor: pointer;
  white-space: nowrap;
  transition: background 0.15s;
}
.tt-hint-chip:hover { background: ${a.white}25; }
.tt-hint-chip--disabled { opacity: 0.3; pointer-events: none; }
/* Chip under the finger during a fan drag — dock magnification */
.tt-hint-chip--tracked {
  background: ${a.green}30;
  outline: 1px solid ${a.green};
  transform: scale(1.12);
}
/* Pending bulb suggestion, glowing for its confirming tap */
.tt-hint-chip--suggested {
  border: 1px solid ${a.green};
  background: ${a.green}15;
  cursor: pointer;
  box-shadow: 0 0 8px ${a.green}60;
}
/* Help progress bar */
.tt-help-bar {
  padding: 8px 12px;
}
.tt-help-bar__labels {
  display: flex;
  justify-content: space-between;
  margin-bottom: 4px;
}
.tt-help-bar__label {
  font-size: ${C.small};
  font-weight: 600;
  color: ${a.white};
}
.tt-help-bar__avg {
  font-size: ${C.small};
  color: ${a.white};
  opacity: 0.5;
}
.tt-help-bar__track {
  position: relative;
  height: 6px;
  border-radius: ${N.tile};
  background: ${a.white}15;
  overflow: hidden;
}
.tt-help-bar__fill {
  height: 100%;
  border-radius: ${N.tile};
  transition: width 0.3s ease, background-color 0.3s ease;
}
/* Hover price preview: grows out of the fill while a hint chip is hovered */
.tt-help-bar__ghost {
  position: absolute;
  top: 0;
  height: 100%;
  width: 0;
  background: ${a.white}55;
  border-radius: ${N.tile};
  transition: width 0.15s ease;
  pointer-events: none;
}
.tt-help-bar__preview {
  color: ${a.yellow};
  font-weight: 600;
}

/* Hint flash pill — inline to left of bulb */
.tt-hint-flash-inline {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  background: ${a.white}10;
  border: 1px solid ${a.green}40;
  border-radius: ${N.md};
  padding: 3px 8px;
  font-size: ${C.small};
  color: ${a.white};
  white-space: nowrap;
}

/* Hints bar inline in header */
.tt-hints-inline {
  flex: 1;
  overflow-x: auto;
  margin: 0 4px;
}
.tt-hints-inline::-webkit-scrollbar { display: none; }
.tt-hints-inline .tt-hints {
  flex-wrap: nowrap;
  gap: 4px;
}
.tt-hints-inline .tt-hint-chip {
  padding: 4px 8px;
  font-size: ${C.small};
}

/* Revealed "My cue" lines above the input */
.tt-cue-reveal {
  margin-bottom: 8px;
  display: grid;
  gap: 4px;
}
.tt-cue-reveal div {
  font-size: ${C.small};
  color: ${a.yellow};
  background: ${a.yellow}12;
  border-radius: ${N.sm};
  padding: 4px 8px;
}

/* ✎ marker on highlights that carry an authored cue */
.tt-has-cue::after {
  content: "✎";
  font-size: 10px;
  vertical-align: super;
  color: ${a.violet};
  opacity: 0.8;
  margin-left: 1px;
}

/* Cue editor (long-press on a highlight or underline) */
.tt-cue-context {
  font-size: ${C.small};
  color: ${a.lavender};
  font-style: italic;
  margin-bottom: 10px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.tt-cue-input {
  width: 100%;
  box-sizing: border-box;
  height: 36px;
  background: ${a.white}10;
  border: 1px solid ${a.white}20;
  border-radius: ${N.sm};
  padding: 0 10px;
  font-size: ${C.small};
  color: ${a.white};
  outline: none;
}
.tt-cue-input:focus { box-shadow: 0 0 0 2px ${a.green}60; }
.tt-cue-actions {
  display: flex;
  gap: 8px;
  margin-top: 14px;
  align-items: center;
}
.tt-cue-remove {
  font-size: ${C.small};
  color: ${a.orange};
  cursor: pointer;
  margin-right: auto;
}

/* Save modal */
.tt-save-overlay {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999999;
  padding: 24px;
}
.tt-save-card {
  background: ${U.gradient};
  border: ${U.cardBorder};
  border-radius: ${N.lg};
  padding: 20px;
  width: 100%;
  max-width: 360px;
  color: ${a.white};
}
.tt-save-card h3 {
  margin: 0;
  font-family: ${C.display};
  font-weight: 800;
  font-size: ${C.label};
}
.tt-save-card .tt-save-sub {
  font-size: ${C.small};
  opacity: 0.6;
  margin-top: 2px;
}

/* The invite: a centered hand-off card — the app surface in miniature,
   one number, one line, one glowing way forward. */
@keyframes tt-pop {
  from { opacity: 0; transform: scale(0.94) translateY(10px); }
  to   { opacity: 1; transform: scale(1) translateY(0); }
}
.tt-save-card--invite {
  text-align: center;
  padding: 26px 24px 18px;
  /* A green dawn over the app gradient — the moment feels like a win */
  background:
    radial-gradient(420px 220px at 50% -40%, ${a.green}2E, transparent 65%),
    ${U.gradient};
  animation: tt-pop 0.25s ease-out;
}
.tt-save-wordmark {
  font-family: ${C.display};
  font-weight: 800;
  font-size: ${C.small};
  letter-spacing: 0.04em;
  color: ${a.green};
}
.tt-save-num {
  font-family: ${C.display};
  font-weight: 800;
  font-size: 46px;
  line-height: 1.1;
  color: ${a.yellow};
  margin-top: 8px;
}
.tt-save-what {
  font-size: ${C.body};
  font-weight: 700;
  color: ${a.white};
  margin-bottom: 8px;
}
.tt-save-line {
  font-size: ${C.small};
  color: ${a.lavender};
  line-height: 1.5;
  max-width: 30ch;
  margin: 0 auto 18px;
}
.tt-save-go-btn {
  width: 100%;
  box-sizing: border-box;
  background: ${a.green};
  color: ${a.dark};
  border: none;
  border-radius: ${N.pill};
  padding: 13px 16px;
  font-family: ${C.display};
  font-size: ${C.body};
  font-weight: 800;
  cursor: pointer;
  box-shadow: 0 6px 20px ${a.green}40;
  transition: transform 0.12s ease, box-shadow 0.12s ease;
}
.tt-save-go-btn:hover {
  transform: translateY(-1px);
  box-shadow: 0 8px 24px ${a.green}55;
}
.tt-save-done-ring {
  width: 56px;
  height: 56px;
  margin: 8px auto 12px;
  border-radius: ${N.pill};
  background: ${a.green};
  color: ${a.dark};
  font-size: ${C.h2};
  font-weight: 800;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 6px 20px ${a.green}40;
}
.tt-save-row {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 8px;
  border-bottom: 1px solid ${a.white}10;
  cursor: pointer;
  border-radius: ${N.sm};
}
.tt-save-row:hover {
  background: ${a.white}10;
}
.tt-save-input {
  flex: 1;
  height: 32px;
  background: ${a.white}10;
  border: 1px solid ${a.white}20;
  border-radius: ${N.sm};
  padding: 0 8px;
  font-size: ${C.small};
  color: ${a.white};
}
.tt-save-input::placeholder { color: ${a.white}40; }
.tt-save-create-btn {
  background: ${a.green};
  border: none;
  border-radius: ${N.pill};
  padding: 6px 14px;
  font-weight: bold;
  color: ${a.dark};
  cursor: pointer;
  font-size: ${C.small};
}
.tt-save-cancel {
  text-align: center;
  margin-top: 12px;
  font-size: ${C.small};
  opacity: 0.5;
  cursor: pointer;
}
.tt-save-check {
  text-align: center;
  font-size: ${C.h1};
  color: ${a.green};
}
.tt-save-msg {
  text-align: center;
  font-size: ${C.small};
  font-weight: 600;
  margin-top: 8px;
}

/* Toast animations */
@keyframes tt-fade-in {
  from { opacity: 0; transform: translateY(-4px); }
  to { opacity: 1; transform: translateY(0); }
}
@keyframes tt-toast-fade {
  0% { opacity: 0; transform: translateY(-10px); }
  10% { opacity: 1; transform: translateY(0); }
  80% { opacity: 1; transform: translateY(0); }
  100% { opacity: 0; transform: translateY(-10px); }
}
.tt-toast {
  position: fixed;
  top: 52px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 999999;
  background: ${a.orange};
  color: white;
  padding: 10px 20px;
  border-radius: ${N.sm};
  font-family: ${C.sans};
  font-size: ${C.small};
  font-weight: 600;
  box-shadow: 0 4px 12px rgba(0,0,0,0.3);
  animation: tt-toast-fade 3s ease forwards;
  pointer-events: none;
}

/* Score */
.tt-score {
  text-align: center;
  padding: 8px;
  font-size: ${C.small};
  color: ${a.white};
  opacity: 0.6;
}

/* Complete state */
.tt-complete {
  text-align: center;
  padding: 20px;
}
.tt-complete__check {
  font-size: ${C.hero};
  color: ${a.green};
  margin-bottom: 8px;
}
.tt-complete__score {
  font-size: ${C.h1};
  font-weight: bold;
  /* Not electric violet: on the dark surface it reads as a gap (see HelpDonut). */
  color: ${a.yellow};
}

/* Cue editor card + first-run guide.
   These render inside arbitrary host pages whose CSS can reach into our
   DOM (no shadow root), so every text/background property that decides
   legibility is pinned with !important — a host rule once turned the cue
   input's text black on the dark card. */
.tt-brand-row {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 12px;
}
.tt-brand-row svg { display: block; flex: none; }
.tt-brand-title {
  font-family: ${C.display} !important;
  font-weight: 800 !important;
  font-size: ${C.label} !important;
  color: ${a.white} !important;
  margin: 0 !important;
  line-height: 1.2 !important;
}
.tt-brand-kicker {
  font-family: ${C.sans} !important;
  font-size: ${C.small} !important;
  color: ${a.lavender} !important;
  margin: 0 !important;
}
.tt-cue-card .tt-cue-context {
  color: ${a.lavender} !important;
  background: ${a.white}0A;
  border-radius: ${N.sm};
  padding: 8px 10px;
}
.tt-cue-card .tt-cue-input {
  color: ${a.white} !important;
  background: ${a.white}12 !important;
  caret-color: ${a.green} !important;
  font-family: ${C.sans} !important;
  -webkit-text-fill-color: ${a.white} !important;
}
.tt-cue-card .tt-cue-input::placeholder {
  color: ${a.white} !important;
  -webkit-text-fill-color: ${a.white} !important;
  opacity: 0.45 !important;
}
.tt-cue-card .tt-save-cancel,
.tt-cue-card .tt-cue-remove { font-family: ${C.sans} !important; }
.tt-cue-meta {
  margin-top: 5px;
  font-family: ${C.sans} !important;
  font-size: 11px !important;
  color: ${a.lavender} !important;
  opacity: 0.8;
  text-align: right;
}
.tt-cue-meta--over {
  color: ${a.orange} !important;
  opacity: 1;
  font-weight: 700 !important;
}

/* First-run guide */
.tt-guide-steps { display: grid; gap: 12px; margin: 14px 0 18px; }
.tt-guide-step { display: flex; gap: 12px; align-items: flex-start; }
.tt-guide-num {
  flex: none;
  width: 26px; height: 26px;
  border-radius: ${N.pill};
  background: ${a.green};
  color: ${a.dark} !important;
  font-family: ${C.display} !important;
  font-weight: 800 !important;
  font-size: ${C.small} !important;
  display: flex; align-items: center; justify-content: center;
}
.tt-guide-step b {
  color: ${a.white} !important;
  font-family: ${C.sans} !important;
  font-size: ${C.body} !important;
  font-weight: 700 !important;
}
.tt-guide-step p {
  margin: 2px 0 0 !important;
  color: ${a.lavender} !important;
  font-family: ${C.sans} !important;
  font-size: ${C.small} !important;
  line-height: 1.5 !important;
}
.tt-guide-chip {
  display: inline-block;
  font-family: ${C.display} !important;
  font-weight: 800 !important;
  font-size: 11px !important;
  color: ${a.green} !important;
  border: 1px solid ${a.green}60;
  border-radius: ${N.pill};
  padding: 0 7px;
}
`;function Le(e=34){return`<svg width="${e}" height="${e}" viewBox="0 0 46.18 46.18" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <rect width="46.18" height="46.18" rx="10.2" fill="#0FFFB9"/>
    <g transform="translate(-79 -333)" fill="#4E15FF">
      <path d="M99.8499 344.37H88.4299C87.1499 344.37 86.1699 345.38 86.1699 346.63C86.1699 347.88 87.1799 348.85 88.4299 348.85H95.1199V368.19C95.1199 369.51 96.1299 370.6 97.4499 370.6C98.7699 370.6 99.8599 369.51 99.8599 368.19V348.84L99.8399 344.37H99.8499Z"/>
      <path d="M112.49 344.37H104.8V348.84H112.49C113.77 348.84 114.75 347.83 114.75 346.62C114.75 345.41 113.74 344.36 112.49 344.36V344.37Z"/>
      <path d="M104.66 355.42C104.66 354.14 105.71 353.09 107 353.09C108.29 353.09 109.34 354.14 109.34 355.42V368.26C109.34 369.54 108.29 370.59 107 370.59C105.71 370.59 104.66 369.54 104.66 368.26V355.42Z"/>
    </g>
  </svg>`}function te(){if(document.getElementById("tt-styles"))return;pt();const e=document.createElement("style");e.id="tt-styles",e.textContent=ut,document.head.appendChild(e)}function pt(){if(!document.getElementById("tt-fonts"))try{const e=document.createElement("link");e.id="tt-fonts",e.rel="stylesheet",e.href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Nunito:wght@700&display=swap",document.head.appendChild(e)}catch{}}const gt=`
::highlight(tt-question) {
  background-color: ${a.violet}20;
  color: inherit;
}
::highlight(tt-answer) {
  background-color: ${a.green}20;
  color: inherit;
}
::highlight(tt-sentence) {
  background-color: ${a.violet}20;
  color: inherit;
}
::highlight(tt-underline) {
  background-color: ${a.green}20;
  text-decoration: underline dotted ${a.green};
  text-decoration-thickness: 2px;
  color: inherit;
}
::highlight(tt-delete) {
  background-color: ${a.orange}20;
  text-decoration: line-through;
  color: inherit;
}
`;function ht(){if(document.getElementById("tt-css-highlight-styles"))return;const e=document.createElement("style");e.id="tt-css-highlight-styles",e.textContent=gt,document.head.appendChild(e)}const ft=50;var W=(e=>(e.CHARACTER_PLACEHOLDERS="CHARACTER_PLACEHOLDERS",e.NEXT_LETTER="NEXT_LETTER",e.ALL_VOWELS="ALL_VOWELS",e.ALL_CONSONANTS="ALL_CONSONANTS",e.SHUFFLED_LETTERS="SHUFFLED_LETTERS",e.RANDOM_LETTER="RANDOM_LETTER",e.HANGMAN="HANGMAN",e.FIRST_CONSONANT="FIRST_CONSONANT",e.FIRST_VOWEL="FIRST_VOWEL",e.CONSONANT_LIST="CONSONANT_LIST",e.SELF_AUTHORED="SELF_AUTHORED",e))(W||{});function de(e){return e.normalize("NFD").replace(/[\u0300-\u036f]/g,"")}const ue=new Set(["a","e","i","o","u","y"]);function Re(e){const t=[...e];for(let n=t.length-1;n>0;n--){const o=Math.floor(Math.random()*(n+1));[t[n],t[o]]=[t[o],t[n]]}return t}function ve(e){return e>0?100/e:0}function mt(e,t){let n=0;for(let o=0;o<e.length;o++)t.has(o)&&n++;return n}const bt={id:W.CHARACTER_PLACEHOLDERS,label:"Show length",icon:"📏",iconName:"ruler",description:"Shows how many characters the word has",repeatable:!1,autoRevealsLength:!0,revealsPositions:!1,costType:"free",modality:"text",group:"reveal",apply(e,t){return{type:this.id,revealedIndices:[],cost:0}}},xt={id:W.NEXT_LETTER,label:"Next letter",icon:"➡️",iconName:"arrow-right",description:"Reveals the next unrevealed letter from left to right",repeatable:!0,autoRevealsLength:!1,revealsPositions:!0,costType:"per-letter",modality:"text",group:"reveal",apply(e,t){for(let n=0;n<e.length;n++)if(!t.has(n))return{type:this.id,revealedIndices:[n],cost:ve(e.length)};return{type:this.id,revealedIndices:[],cost:0}}},vt={id:W.ALL_VOWELS,label:"Vowels",icon:"🔤",iconName:"vowels",description:"Reveals all vowels (a, e, i, o, u, y — including accented)",repeatable:!1,autoRevealsLength:!0,revealsPositions:!0,costType:"proportional",modality:"text",group:"reveal",apply(e,t){const n=e.toLowerCase(),o=[];for(let r=0;r<e.length;r++)ue.has(de(n[r]))&&!t.has(r)&&o.push(r);return{type:this.id,revealedIndices:o,cost:e.length>0?o.length/e.length*100:0}}},wt={id:W.ALL_CONSONANTS,label:"Consonants",icon:"🔡",iconName:"consonants",description:"Reveals all consonants (including accented like ç, ñ)",repeatable:!1,autoRevealsLength:!0,revealsPositions:!0,costType:"proportional",modality:"text",group:"reveal",apply(e,t){const n=e.toLowerCase(),o=[];for(let r=0;r<e.length;r++)!ue.has(de(n[r]))&&!t.has(r)&&o.push(r);return{type:this.id,revealedIndices:o,cost:e.length>0?o.length/e.length*100:0}}},yt={id:W.SHUFFLED_LETTERS,label:"Shuffle",icon:"🔀",iconName:"shuffle",description:"Shuffles the letters within each word (doesn't reveal positions)",repeatable:!0,autoRevealsLength:!0,revealsPositions:!1,costType:"flat",flatCost:40,modality:"text",group:"reorder",apply(e,t){const n=e.length-mt(e,t);if(n===0)return{type:this.id,revealedIndices:[],cost:0};const o=e.split(" ").map(r=>Re(r.split("")).join("")).join(" ");return{type:this.id,revealedIndices:[],cost:40*(n/e.length),displayData:o}}},$t={id:W.RANDOM_LETTER,label:"Random",icon:"🎲",iconName:"dice",description:"Reveals one random unrevealed letter",repeatable:!0,autoRevealsLength:!0,revealsPositions:!0,costType:"per-letter",modality:"text",group:"reveal",apply(e,t){const n=[];for(let r=0;r<e.length;r++)t.has(r)||n.push(r);if(n.length===0)return{type:this.id,revealedIndices:[],cost:0};const o=n[Math.floor(Math.random()*n.length)];return{type:this.id,revealedIndices:[o],cost:ve(e.length)}}},kt={id:W.HANGMAN,label:"Structure",icon:"␣",iconName:"slots",description:"Shows the word breaks and punctuation, with a slot for each letter",repeatable:!1,autoRevealsLength:!0,revealsPositions:!0,costType:"proportional",modality:"text",group:"reveal",apply(e,t){const n=[];for(let o=0;o<e.length;o++){const r=e[o];!/[\p{L}\p{N}]/u.test(r)&&!t.has(o)&&n.push(o)}return{type:this.id,revealedIndices:n,cost:e.length>0?n.length/e.length*100:0}}};function He(e,t){return(n,o)=>{const r=n.toLowerCase();for(let s=0;s<n.length;s++){const i=de(r[s]);if(/[a-z]/.test(i)&&ue.has(i)===t&&!o.has(s))return{type:e,revealedIndices:[s],cost:ve(n.length)}}return{type:e,revealedIndices:[],cost:0}}}const St={id:W.FIRST_CONSONANT,label:"Consonant",icon:"🔡",iconName:"consonant",description:"Reveals the first consonant, then each following one",repeatable:!0,autoRevealsLength:!1,revealsPositions:!0,costType:"per-letter",modality:"text",group:"reveal",apply(e,t){return He(W.FIRST_CONSONANT,!1)(e,t)}},Et={id:W.FIRST_VOWEL,label:"Vowel",icon:"🔤",iconName:"vowel",description:"Reveals the first vowel, then each following one",repeatable:!0,autoRevealsLength:!1,revealsPositions:!0,costType:"per-letter",modality:"text",group:"reveal",apply(e,t){return He(W.FIRST_VOWEL,!0)(e,t)}},Ct={id:W.CONSONANT_LIST,label:"Consonant list",icon:"🔡",iconName:"list",description:"Lists the consonants you still need in random order, without their positions",repeatable:!1,autoRevealsLength:!1,revealsPositions:!1,costType:"proportional",modality:"text",group:"reorder",apply(e,t){const n=e.toLowerCase(),o=[];for(let r=0;r<e.length;r++){if(t.has(r))continue;const s=n[r],i=de(s);/[a-z]/.test(i)&&!ue.has(i)&&o.push(s)}return o.length===0?{type:this.id,revealedIndices:[],cost:0}:{type:this.id,revealedIndices:[],cost:e.length>0?o.length/e.length*50:0,displayData:Re(o).join(" ")}}},we=[{id:W.SELF_AUTHORED,label:"My cue",icon:"✎",iconName:"pen",description:"Shows a cue you wrote yourself when creating this exercise",repeatable:!0,autoRevealsLength:!1,revealsPositions:!1,costType:"flat",flatCost:10,modality:"text",group:"reveal",apply(e,t){return{type:this.id,revealedIndices:[],cost:10}}},bt,xt,$t,vt,Et,wt,St,Ct,yt],Tt=[...we,kt];function re(e){const t=Tt.find(n=>n.id===e);if(!t)throw new Error(`Unknown hint type: ${e}`);return t}function _t(e,t,n=new Set){return re(t).apply(e,n)}function ye(e){const t=e.reduce((n,o)=>n+o.cost,0);return Math.min(t,100)}function Ae(e,t,n){return e.apply(t,new Set(n))}function Ie(e,t,n){return Ae(e,t,n).cost}function Lt(e,t,n,o={}){if(t.length===0)return!1;if(e.id===W.CHARACTER_PLACEHOLDERS)return o.lengthAlreadyKnown!==!0;if(e.id===W.SELF_AUTHORED)return o.remainingCues===void 0||o.remainingCues>0;const r=Ae(e,t,n);return r.revealedIndices.length>0||r.displayData!==void 0}function Rt(e,t){return(e??[]).slice(t)}let Me="strict";function pe(){return Me}function Ht(e){return e.normalize("NFD").replace(/[̀-ͯ]/g,"")}function Ne(e,t){const n=e.toLowerCase();return t==="strict"?n:Ht(n)}function ge(e,t,n=Me){return t===""?!1:Ne(e,n)===Ne(t,n)}function ae(e,t=pe()){const n=new Set;return e.blanks.forEach((o,r)=>{(o.revealed||ge(o.expected,o.actual,t))&&n.add(r)}),n}function Oe(e){return{exercise:e,hintUsages:[],isComplete:!1,shuffledLettersMap:{}}}function At(e){return e.blanks.map(t=>t.actual).join("")}function It(e,t,n,o=pe()){const r=e.exercise.queries.find($=>$.id===t);if(!r)return e;const s=z(r,o);if(s.correct===s.total)return e;const i=r.blanks.map(($,L)=>{const _=n[L]??"";return $.revealed&&_!==""&&!ge($.expected,_,o)?{...$,actual:_,revealed:!1}:{...$,actual:_}}),d={...r,blanks:i},b=e.exercise.queries.map($=>$.id===t?d:$),g={...e.exercise,queries:b};return{...e,exercise:g,isComplete:$e(g)}}function Mt(e,t,n){const o=e.exercise.queries.find(c=>c.id===t);if(!o)return e;const r=re(n),s=ae(o);if(!r.repeatable&&e.hintUsages.some(p=>p.queryId===t&&p.type===n))return e;const i=_t(o.answer,n,s);if(r.id!==W.CHARACTER_PLACEHOLDERS&&i.revealedIndices.length===0&&!i.displayData&&i.cost===0)return e;const d=o.blanks.map((c,p)=>i.revealedIndices.includes(p)?{...c,revealed:!0}:c),b={...o,blanks:d},g=e.exercise.queries.map(c=>c.id===t?b:c),$={queryId:t,type:n,cost:i.cost,usedAt:new Date,displayData:i.displayData},L={...e.exercise,queries:g},_={...e.shuffledLettersMap};return i.displayData&&n==="SHUFFLED_LETTERS"&&(_[t]=i.displayData),{...e,exercise:L,hintUsages:[...e.hintUsages,$],isComplete:$e(L),shuffledLettersMap:_}}function Nt(e,t,n){const o=e.exercise.queries.find($=>$.id===t);if(!o||n<0||n>=o.blanks.length||ae(o).has(n))return e;const r=o.blanks.map(($,L)=>L===n?{...$,revealed:!0}:$),s={...o,blanks:r},i=e.exercise.queries.map($=>$.id===t?s:$),d=o.answer.length>0?100/o.answer.length:0,b={queryId:t,type:W.NEXT_LETTER,cost:d,usedAt:new Date},g={...e.exercise,queries:i};return{...e,exercise:g,hintUsages:[...e.hintUsages,b],isComplete:$e(g)}}function $e(e,t=pe()){return e.queries.every(n=>n.blanks.every(o=>ge(o.expected,o.actual,t)))}function z(e,t=pe()){const n=e.blanks.length;return{correct:e.blanks.filter(r=>ge(r.expected,r.actual,t)).length,total:n}}function qe(){return Math.random().toString(36).substring(2,10)}function Ot(e){return Array.from(e).filter(t=>/[\p{L}\p{M}'''\-\s]/u.test(t)).join("")}function qt(e){return e.split("").map(t=>({expected:t,actual:"",revealed:!1}))}function Wt(e){const t=e.match(/^[.,;:!?'"()\-–—\s]+/),n=t?t[0].length:0,o=e.match(/[.,;:!?'"()\-–—\s]+$/),r=o?o[0].length:0;return{cleaned:e.slice(n,e.length-r||void 0),leadingLen:n,trailingLen:r}}function Dt(e,t){if(e.length<=1)return e;const n=[...e].sort((r,s)=>r.start-s.start),o=[{...n[0]}];for(let r=1;r<n.length;r++){const s=n[r],i=o[o.length-1];t.slice(i.end,s.start).trim().length===0?i.end=s.end:o.push({...s})}return o}function zt(e){if(!e.sentenceSelection||e.wordSelections.length===0)return null;const t=e.sourceText.slice(e.sentenceSelection.start,e.sentenceSelection.end),n=Dt(e.wordSelections,e.sourceText),o=[];let r=t;for(let s=n.length-1;s>=0;s--){const i=n[s],d=i.start-e.sentenceSelection.start,b=i.end-e.sentenceSelection.start,g=t.slice(d,b),{cleaned:$,leadingLen:L,trailingLen:_}=Wt(g),c=Ot($);if(c.length===0)continue;const p=d+L,u=b-_,S={id:qe(),answer:c,blanks:qt(c),startIndex:p,endIndex:u};o.unshift(S);const k="_".repeat(c.length);r=r.slice(0,p)+k+r.slice(u)}return o.length===0?null:{id:qe(),type:"hhh",originalSentence:t,sentenceWithBlanks:r,queries:o,createdAt:new Date}}function We(){return Math.random().toString(36).substring(2,10)}function Bt(e){return Array.from(e).filter(t=>/[\p{L}\p{M}'''\-\s]/u.test(t)).join("")}function Ft(e){return e.split("").map(t=>({expected:t,actual:"",revealed:!1}))}function Pt(e,t){const n=e.slice(t.question.start,t.question.end).trim(),o=Bt(e.slice(t.answer.start,t.answer.end).trim());if(n.length===0||o.length===0)return null;const r={id:We(),answer:o,blanks:Ft(o),startIndex:0,endIndex:o.length},s="_".repeat(o.length);return{id:We(),type:"qa",originalSentence:n,sentenceWithBlanks:s,queries:[r],createdAt:new Date}}const De=new Date("2026-09-28");function ze(e){return e.split("").map(t=>({expected:t,actual:"",revealed:!1}))}function A(e,t,n){return{id:e,type:"qa",originalSentence:t,sentenceWithBlanks:"_".repeat(n.length),queries:[{id:`${e}-q1`,answer:n,blanks:ze(n),startIndex:0,endIndex:n.length}],createdAt:De}}function jt(e,t){let n=0;for(;;){const o=e.indexOf(t,n);if(o<0)throw new Error(`Fixture error: "${t}" not found in "${e}"`);const r=e[o-1],s=e[o+t.length],i=d=>d!==void 0&&new RegExp("\\p{L}","u").test(d);if(!i(r)&&!i(s))return o;n=o+1}}function I(e,t,n){const o=n.map((s,i)=>{const d=jt(t,s);return{id:`${e}-q${i+1}`,answer:s,blanks:ze(s),startIndex:d,endIndex:d+s.length}}).sort((s,i)=>s.startIndex-i.startIndex);let r=t;for(const s of o)r=r.slice(0,s.startIndex)+"_".repeat(s.answer.length)+r.slice(s.endIndex);return{id:e,type:"hhh",originalSentence:t,sentenceWithBlanks:r,queries:o,createdAt:De}}A("b1-nl-qa-1","Hoe noem je de persoon die brood en taarten bakt?","de bakker"),A("b1-nl-qa-2","Wat neem je mee als het regent?","een paraplu"),A("b1-nl-qa-3","Hoe noem je het gebouw waar je boeken kunt lenen?","de bibliotheek"),A("b1-nl-qa-4","Welk seizoen komt na de zomer?","de herfst"),A("b1-nl-qa-5","Hoe noem je de dokter die zieke dieren beter maakt?","de dierenarts"),A("b1-nl-qa-6","Hoe noem je het eerste eten van de dag?","het ontbijt"),A("b1-nl-qa-7","Hoe noem je de broer van je moeder?","de oom"),A("b1-nl-qa-8","Waar wacht je op de trein?","op het station"),A("b1-nl-qa-9","Hoe noem je iemand die in een restaurant kookt?","de kok"),A("b1-nl-qa-10","Hoe noem je het geld dat je elke maand verdient?","het salaris"),I("b1-nl-pres-1","Hallo, ik heet Thomas en ik ben dertig jaar oud.",["heet","oud"]),I("b1-nl-pres-2","Ik werk als verpleegkundige in een groot ziekenhuis in Antwerpen.",["verpleegkundige","ziekenhuis"]),I("b1-nl-pres-3","In het weekend ga ik graag wandelen in het bos met mijn hond.",["wandelen","hond"]),I("b1-nl-pres-4","Mijn grootste droom is om een lange reis door Azië te maken.",["droom","reis"]),I("b1-nl-pres-5","Daarom spaar ik elke maand een beetje geld voor die reis.",["spaar","geld"]),I("b1-nl-pres-6","Elke ochtend fiets ik in twintig minuten naar mijn werk.",["twintig minuten","werk"]),I("b1-nl-pres-7","Mijn zus woont in Gent en ik bezoek haar elke zondag.",["woont","elke zondag"]),I("b1-nl-pres-8","Op vrijdag kook ik graag verse soep met groenten uit de tuin.",["verse soep","tuin"]),I("b1-nl-pres-9","Volgend jaar wil ik een cursus Japans volgen voor mijn reis.",["cursus Japans","reis"]),I("b1-nl-pres-10","Mijn hond heet Max en hij wordt volgende maand vier jaar oud.",["volgende maand","vier jaar"]),A("b1-nl-opp-1","Wat is het tegenovergestelde van 'duur'?","goedkoop"),A("b1-nl-opp-2","Wat is het tegenovergestelde van 'groot'?","klein"),A("b1-nl-opp-3","Wat is het tegenovergestelde van 'snel'?","langzaam"),A("b1-nl-opp-4","Wat is het tegenovergestelde van 'makkelijk'?","moeilijk"),A("b1-nl-opp-5","Wat is het tegenovergestelde van 'vol'?","leeg"),A("b1-nl-opp-6","Wat is het tegenovergestelde van 'zwaar'?","licht"),A("b1-nl-opp-7","Wat is het tegenovergestelde van 'schoon'?","vuil"),A("b1-nl-opp-8","Wat is het tegenovergestelde van 'dichtbij'?","ver weg"),A("b1-nl-opp-9","Wat is het tegenovergestelde van 'beginnen'?","stoppen"),A("b1-nl-opp-10","Wat is het tegenovergestelde van 'vroeg'?","laat"),I("b1-nl-city-1","Vanochtend nemen we de trein naar het centrum van Amsterdam.",["de trein","centrum"]),I("b1-nl-city-2","Eerst drinken we koffie met appeltaart in een klein café aan de gracht.",["koffie","gracht"]),I("b1-nl-city-3","Daarna huren we fietsen om door het Vondelpark te rijden.",["huren","fietsen"]),I("b1-nl-city-4","In het museum bekijken we de beroemde schilderijen van Van Gogh.",["museum","beroemde schilderijen"]),I("b1-nl-city-5","Voor de lunch eten we een broodje haring bij een kraampje op de markt.",["broodje haring","markt"]),I("b1-nl-city-6","In de middag maken we een rondvaart door de oude grachten van de stad.",["rondvaart","oude grachten"]),I("b1-nl-city-7","We kopen souvenirs en verse kaas in een gezellige winkel.",["souvenirs","verse kaas"]),I("b1-nl-city-8","Het begint zacht te regenen, dus we schuilen onder een grote paraplu.",["regenen","grote paraplu"]),I("b1-nl-city-9","Voor het diner bestellen we pannenkoeken met stroop en poedersuiker.",["bestellen","pannenkoeken"]),I("b1-nl-city-10","Moe maar gelukkig nemen we de laatste trein terug naar huis.",["laatste trein","huis"]),A("b1-en-qa-1","What do you call the person who flies a plane?","a pilot"),A("b1-en-qa-2","What do you use to open a locked door?","a key"),A("b1-en-qa-3","What do you call the meal you eat in the morning?","breakfast"),A("b1-en-qa-4","Which season comes after winter?","spring"),A("b1-en-qa-5","What do you call the place where you watch films on a big screen?","the cinema"),A("b1-en-qa-6","What do you call the room where you cook your meals?","the kitchen"),A("b1-en-qa-7","What do you call your mother's brother?","your uncle"),A("b1-en-qa-8","Where do you wait for a train?","at the station"),A("b1-en-qa-9","What do you call a person who cooks in a restaurant?","a chef"),A("b1-en-qa-10","What do you call the money you earn every month?","a salary"),I("b1-en-pres-1","Hi, my name is Sarah and I am twenty-eight years old.",["name","old"]),I("b1-en-pres-2","I work as an engineer at a small software company in Manchester.",["engineer","company"]),I("b1-en-pres-3","Every morning I take the train to work and read a book on the way.",["train","book"]),I("b1-en-pres-4","My biggest dream is to open my own restaurant one day.",["dream","restaurant"]),I("b1-en-pres-5","That is why I save money every month and take cooking classes in the evening.",["save","cooking"]),I("b1-en-pres-6","Every evening I cook a new recipe from an old Italian cookbook.",["new recipe","cookbook"]),I("b1-en-pres-7","My brother lives in Leeds and I visit him every weekend.",["lives","every weekend"]),I("b1-en-pres-8","Next year I want to take a business course to learn about restaurants.",["business course","learn"]),I("b1-en-pres-9","My favourite dish is a simple pasta with fresh tomatoes and basil.",["favourite dish","fresh tomatoes"]),I("b1-en-pres-10","With a bit of luck I will open the doors of my restaurant in five years.",["doors","five years"]),A("b1-en-opp-1","What is the opposite of 'expensive'?","cheap"),A("b1-en-opp-2","What is the opposite of 'big'?","small"),A("b1-en-opp-3","What is the opposite of 'fast'?","slow"),A("b1-en-opp-4","What is the opposite of 'easy'?","difficult"),A("b1-en-opp-5","What is the opposite of 'full'?","empty"),A("b1-en-opp-6","What is the opposite of 'heavy'?","light"),A("b1-en-opp-7","What is the opposite of 'clean'?","dirty"),A("b1-en-opp-8","What is the opposite of 'near'?","far away"),A("b1-en-opp-9","What is the opposite of 'to begin'?","to stop"),A("b1-en-opp-10","What is the opposite of 'early'?","late"),I("b1-en-city-1","This morning we take the red bus to the centre of London.",["red bus","centre"]),I("b1-en-city-2","First we drink tea with scones in a small café near the river.",["tea","river"]),I("b1-en-city-3","Then we walk through Hyde Park and feed the friendly ducks.",["walk","friendly ducks"]),I("b1-en-city-4","In the museum we look at old maps and famous paintings.",["museum","famous paintings"]),I("b1-en-city-5","For lunch we eat fish and chips at a busy market.",["lunch","busy market"]),I("b1-en-city-6","In the afternoon we take a boat trip on the River Thames.",["afternoon","boat trip"]),I("b1-en-city-7","We buy postcards and small gifts for our friends at home.",["postcards","small gifts"]),I("b1-en-city-8","It starts to rain softly, so we hide under a large umbrella.",["rain","large umbrella"]),I("b1-en-city-9","For dinner we order hot soup and fresh bread in a warm pub.",["order","hot soup"]),I("b1-en-city-10","Tired but happy, we take the last train back to our hotel.",["last train","hotel"]);const he=ft;function Be(e){var b,g,$,L;te(),(b=document.getElementById("tt-cue-overlay"))==null||b.remove();const t=document.createElement("div");t.id="tt-cue-overlay",t.className="tt-save-overlay",t.innerHTML=`<div class="tt-save-card tt-cue-card">
    <div class="tt-brand-row">
      ${Le(34)}
      <div>
        <h3 class="tt-brand-title" style="color:#FFFFFF !important"><span style="color:#0FFFB9 !important">✎</span> My cue — this ${e.scope}</h3>
        <p class="tt-brand-kicker" style="color:#B6A6EB !important">A hint in your own words, offered during play</p>
      </div>
    </div>
    <div class="tt-cue-context">“${Ut(e.context)}”</div>
    <input class="tt-cue-input" id="tt-cue-input" placeholder="e.g. where you sit" maxlength="${he}" />
    <div class="tt-cue-meta" id="tt-cue-meta"></div>
    <div class="tt-cue-actions">
      ${e.initial?'<span class="tt-cue-remove" id="tt-cue-remove">🗑 Remove</span>':""}
      <span class="tt-save-cancel" style="margin:0" id="tt-cue-cancel">Cancel</span>
      <button class="tt-save-create-btn" id="tt-cue-save">✓ Save cue</button>
    </div>
  </div>`,document.body.appendChild(t);const n=t.querySelector("#tt-cue-input"),o=t.querySelector("#tt-cue-meta");n.value=e.initial,setTimeout(()=>n.focus(),50);const r=()=>n.value.trim().length>he,s=(_=!1)=>{o.textContent=_?`Keep it a nudge — max ${he} characters`:`${n.value.length}/${he}`,o.classList.toggle("tt-cue-meta--over",_||r())};n.addEventListener("input",()=>s()),s();const i=()=>t.remove(),d=()=>{if(r()){s(!0),n.focus();return}const _=n.value.trim();_?e.onSave(_):e.initial&&e.onRemove(),i()};(g=t.querySelector("#tt-cue-save"))==null||g.addEventListener("click",d),n.addEventListener("keydown",_=>{_.key==="Enter"&&d(),_.key==="Escape"&&i(),_.stopPropagation()}),($=t.querySelector("#tt-cue-cancel"))==null||$.addEventListener("click",i),(L=t.querySelector("#tt-cue-remove"))==null||L.addEventListener("click",()=>{e.onRemove(),i()}),t.addEventListener("click",_=>{_.target===t&&i()})}function Ut(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}let Qt=1;function G(){const e=window.getSelection();e&&(window.__tiptongClearing=!0,e.removeAllRanges(),window.__tiptongClearing=!1)}function ke(e,t,n){const o=[];if(e.startContainer===e.endContainer&&e.startContainer.nodeType===Node.TEXT_NODE){const b=document.createElement("span");return b.className=t,b.dataset.ttId=n,e.surroundContents(b),o.push(b),o}const r=[],s=document.createTreeWalker(e.commonAncestorContainer,NodeFilter.SHOW_TEXT);let i,d=!1;for(;i=s.nextNode();)if(i===e.startContainer)d=!0,r.push({node:i,start:e.startOffset,end:i.textContent.length});else if(i===e.endContainer){r.push({node:i,start:0,end:e.endOffset});break}else d&&r.push({node:i,start:0,end:i.textContent.length});for(let b=r.length-1;b>=0;b--){const{node:g,start:$,end:L}=r[b];if($===L)continue;const _=document.createRange();_.setStart(g,$),_.setEnd(g,L);const c=document.createElement("span");c.className=t,c.dataset.ttId=n,_.surroundContents(c),o.push(c)}return o.reverse(),o}function Xt(e){const t=document.caretRangeFromPoint(e.clientX,e.clientY);if(!t||t.startContainer.nodeType!==Node.TEXT_NODE)return null;const n=t.startContainer,o=n.textContent||"",r=t.startOffset;if(r>=o.length||o[r]===" "||o[r]===`
`)return null;let s=r;for(;s>0&&o[s-1]!==" "&&o[s-1]!==`
`;)s--;let i=r;for(;i<o.length&&o[i]!==" "&&o[i]!==`
`;)i++;const d=document.createRange();return d.setStart(n,s),d.setEnd(n,i),d}function Yt(e,t,n){if(n!=="qa")return;const o=document.createElement("span");o.className=`tt-badge ${t==="answer"?"tt-badge--a":"tt-badge--q"}`,o.setAttribute("data-tt-badge",""),o.textContent=t==="answer"?"A":"Q",e.insertBefore(o,e.firstChild)}function Vt(e){return Array.from(e).filter(t=>/[\p{L}\p{M}'''\-\s]/u.test(t)).join("")}function le(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function Se(e){let t="";for(const n of e.childNodes)if(n.nodeType===Node.TEXT_NODE)t+=n.textContent;else if(n.nodeType===Node.ELEMENT_NODE){const o=n;if(o.dataset.ttHandle||o.hasAttribute("data-tt-badge"))continue;t+=Se(o)}return t}function Gt(e){if(e.startContainer.nodeType===Node.TEXT_NODE){const t=e.startContainer.textContent||"";let n=e.startOffset;for(;n>0&&t[n-1]!==" "&&t[n-1]!==`
`;)n--;e.setStart(e.startContainer,n)}if(e.endContainer.nodeType===Node.TEXT_NODE){const t=e.endContainer.textContent||"";let n=e.endOffset;for(;n<t.length&&t[n]!==" "&&t[n]!==`
`;)n++;e.setEnd(e.endContainer,n)}}function Kt(){te();const e={mode:"hhh",highlights:[],deleteMode:!1};let t=[];function n(c){var u,S,k,m;let p=c.nodeType===Node.TEXT_NODE?c.parentElement:c;for(;p;){if((u=p.dataset)!=null&&u.ttId)return e.highlights.find(y=>y.id===p.dataset.ttId)??null;if((S=p.classList)!=null&&S.contains("tt-underline")&&((m=(k=p.parentElement)==null?void 0:k.dataset)!=null&&m.ttId))return e.highlights.find(y=>y.id===p.parentElement.dataset.ttId)??null;p=p.parentElement}return null}function o(){if(e.deleteMode){const v=window.getSelection();if(v&&!v.isCollapsed&&v.toString().trim().length>0){e.deleteMode=!1;for(const w of e.highlights)for(const f of w.spans)f.classList.remove("tt-highlight--delete")}else return}const c=window.getSelection();if(!c||c.isCollapsed||!c.rangeCount||!c.toString().trim())return;const u=c.getRangeAt(0),S=document.getElementById("tt-toolbar"),k=document.getElementById("tt-popup");if(S!=null&&S.contains(u.startContainer)){G();return}if(k!=null&&k.contains(u.startContainer)){G();return}Gt(u);const m=u.toString().trim();if(!m){G();return}const y=n(u.startContainer),T=n(u.endContainer);if(y&&y===T){if(e.mode==="hhh"&&y.role==="sentence"){G();return}G();return}const R=y||T;if(R){d(R,u),G();return}if(e.mode==="hhh"&&m.split(/\s+/).filter(Boolean).length<2){G();return}const O=e.highlights.filter(v=>v.role!=="sentence").length,q=e.mode==="qa"?O%2===0?"question":"answer":"sentence",l=`tt-${Qt++}`,h=ke(u,q==="answer"?"tt-highlight tt-highlight--answer":"tt-highlight",l);if(h.length>0){Yt(h[0],q,e.mode);const v={id:l,text:m,role:q,spans:h,underlinedWords:[]};e.highlights.push(v),h.forEach(w=>L(w,v))}G()}function r(c,p){const u=c.underlinedWords[p];if(!u)return;const S=u.span.parentNode;if(S){for(;u.span.firstChild;)S.insertBefore(u.span.firstChild,u.span);S.removeChild(u.span),S.normalize()}c.underlinedWords.splice(p,1)}function s(c,p){var m,y;const u=Xt(p);if(!u)return;const S=u.toString().trim();if(!S)return;const k=c.underlinedWords.findIndex(T=>T.span.contains(u.startContainer)||T.text===S);if(k>=0)r(c,k);else{const T=p.target;if((m=T.classList)!=null&&m.contains("tt-underline")||(y=T.closest)!=null&&y.call(T,".tt-underline")){const l=T.classList.contains("tt-underline")?T:T.closest(".tt-underline"),x=c.underlinedWords.findIndex(h=>h.span===l);if(x>=0){r(c,x);return}}const R=c.text.split(/\s+/).filter(Boolean).length,O=Math.floor(R/2);if(c.underlinedWords.length>=O)return;const q=document.createElement("span");q.className="tt-underline";try{u.surroundContents(q),c.underlinedWords.push({text:S,span:q})}catch{}}}function i(c){const p=e.highlights.find(S=>S.id===c);if(!p)return;const u=new Set([c]);if(p.role==="question"||p.role==="answer"){const S=e.highlights.filter(T=>T.role!=="sentence"),k=S.findIndex(T=>T.id===c),y=k%2===0?k+1:k-1;y>=0&&y<S.length&&u.add(S[y].id)}for(const S of u){const k=e.highlights.find(m=>m.id===S);if(k){for(const m of k.underlinedWords){const y=m.span.parentNode;if(y){for(;m.span.firstChild;)y.insertBefore(m.span.firstChild,m.span);y.removeChild(m.span)}}for(const m of k.spans)m.querySelectorAll("[data-tt-badge]").forEach(y=>y.remove());for(const m of k.spans){const y=m.parentNode;if(y){for(;m.firstChild;)y.insertBefore(m.firstChild,m);y.removeChild(m),y.normalize()}}}}e.highlights=e.highlights.filter(S=>!u.has(S.id)),e.highlights.length===0&&(e.deleteMode=!1)}function d(c,p){try{const u=n(p.startContainer)===c,S=n(p.endContainer)===c;if(!u){const k=c.spans[0],m=document.createRange();if(m.setStart(p.startContainer,p.startOffset),m.setEndBefore(k),m.toString().length>0)try{const y=ke(m,k.className,c.id);c.spans.unshift(...y);const T=k.querySelector("[data-tt-badge]");T&&y[0]&&y[0].insertBefore(T,y[0].firstChild),y.forEach(R=>L(R,c))}catch{}}if(!S){const k=c.spans[c.spans.length-1],m=document.createRange();if(m.setStartAfter(k),m.setEnd(p.endContainer,p.endOffset),m.toString().length>0)try{const y=ke(m,k.className,c.id);c.spans.push(...y),y.forEach(T=>L(T,c))}catch{}}for(c.text=c.spans.map(k=>Se(k)).join("");c.underlinedWords.length>0;)r(c,0)}catch{}}let b=0;function g(c,p){c.classList.toggle("tt-has-cue",!!p),p?c.title=`My cue: ${p}`:c.removeAttribute("title")}function $(c,p){c.addEventListener("pointerdown",u=>{var O,q;if(e.deleteMode)return;const S=u.clientX,k=u.clientY,m=(q=(O=u.target).closest)==null?void 0:q.call(O,".tt-underline");let y=setTimeout(()=>{y=null,b=Date.now()+600,G();const l=m?p.underlinedWords.find(x=>x.span===m):void 0;Be({context:l?l.text:p.text,scope:l?"word":"exercise",initial:(l?l.cue:p.cue)??"",onSave:x=>{l?(l.cue=x,g(l.span,x)):(p.cue=x,g(p.spans[0],x))},onRemove:()=>{l?(l.cue=void 0,g(l.span,void 0)):(p.cue=void 0,g(p.spans[0],void 0))}})},500);const T=()=>{y&&(clearTimeout(y),y=null),document.removeEventListener("pointermove",R),document.removeEventListener("pointerup",T)},R=l=>{Math.hypot(l.clientX-S,l.clientY-k)>8&&T()};document.addEventListener("pointermove",R),document.addEventListener("pointerup",T)})}function L(c,p){$(c,p),c.addEventListener("click",u=>{var k,m,y,T;if(Date.now()<b){u.preventDefault(),u.stopPropagation();return}if(((m=(k=u.target).closest)==null?void 0:m.call(k,"a"))&&(u.preventDefault(),u.stopPropagation()),e.deleteMode){u.preventDefault(),u.stopPropagation();const R=(T=(y=u.target).closest)==null?void 0:T.call(y,".tt-underline");if(R&&p.role==="sentence"){const O=p.underlinedWords.findIndex(q=>q.span===R);if(O>=0){r(p,O);return}}i(p.id);return}if(e.mode==="hhh"&&!e.deleteMode){const R=window.getSelection();if(R&&!R.isCollapsed)return;u.preventDefault(),u.stopPropagation(),s(p,u)}})}const _=()=>setTimeout(o,10);return document.addEventListener("mouseup",_,!0),{getSelections:()=>e.highlights.map(c=>({id:c.id,text:c.text,role:c.role,underlinedCount:c.underlinedWords.length})),validate:()=>{const c=[];return e.highlights.filter(u=>u.role!=="sentence").length%2!==0&&c.push("Last question needs an answer"),c},getMode:()=>e.mode,setMode:c=>{if(e.mode=c,e.deleteMode){e.deleteMode=!1;for(const p of e.highlights)for(const u of p.spans)u.classList.remove("tt-highlight--delete")}},toggleDeleteMode:()=>{e.deleteMode=!e.deleteMode;for(const c of e.highlights)for(const p of c.spans)p.classList.toggle("tt-highlight--delete",e.deleteMode);return e.deleteMode},isDeleteMode:()=>e.deleteMode,getQAPairs:()=>{const c=e.highlights.filter(u=>u.role!=="sentence"),p=[];for(let u=0;u+1<c.length;u+=2)p.push({question:c[u].text,answer:c[u+1].text});return p},getHHHData:()=>e.highlights.filter(p=>p.role==="sentence").map(p=>{const u=p.text,S=p.underlinedWords.map(k=>{const m=u.indexOf(k.text);return m>=0?{start:m,end:m+k.text.length}:null}).filter(k=>k!==null);return{sourceText:u,sentenceStart:0,sentenceEnd:u.length,underlinedWords:S}}),getOrderedExerciseData:()=>{const c=[];t=[];const p=[...e.highlights].sort((k,m)=>{const y=k.spans[0],T=m.spans[0];if(!y||!T)return 0;const R=y.compareDocumentPosition(T);return R&Node.DOCUMENT_POSITION_FOLLOWING?-1:R&Node.DOCUMENT_POSITION_PRECEDING?1:0}),u=p.filter(k=>k.role!=="sentence"),S=new Set;for(const k of p)if(k.role==="question"){const m=u.indexOf(k),y=Math.floor(m/2);if(S.has(y))continue;const T=u[m+1];T&&(S.add(y),c.push({type:"qa",question:k.text,answer:T.text,cue:k.cue??T.cue}),t.push(T.id))}else{if(k.role==="answer")continue;{const m=k.text;let y=k.underlinedWords.map(T=>{const R=m.indexOf(T.text);return R>=0?{start:R,end:R+T.text.length,cue:T.cue}:null}).filter(T=>T!==null);y.length===0&&k.randomPick&&(y=[{start:k.randomPick.start,end:k.randomPick.end}]),c.push({type:"hhh",sourceText:m,sentenceStart:0,sentenceEnd:m.length,underlinedWords:y,cue:k.cue}),t.push(k.id)}}return c},hideAnswers:()=>{for(const c of e.highlights)if(c.role==="answer")for(const p of c.spans){p.dataset.ttOriginal=p.innerHTML;const u="•".repeat(Math.min(c.text.length,12));p.innerHTML=`<span style="letter-spacing:2px;color:${a.violet};font-weight:bold">${u}</span>`}},hideUnderlinedWords:()=>{for(const c of e.highlights)if(c.role==="sentence")if(c.underlinedWords.length>0)for(const p of c.underlinedWords){p.span.dataset.ttOriginal=p.span.innerHTML;const u="•".repeat(Math.min(p.text.length,8));p.span.innerHTML=`<span style="letter-spacing:2px;color:${a.violet};font-weight:bold">${u}</span>`}else{const p=[];for(const u of c.spans){const S=Se(u),k=/[\p{L}\p{M}'']+/gu;let m;for(;(m=k.exec(S))!==null;)p.push({span:u,text:S,localStart:m.index,localEnd:m.index+m[0].length,word:m[0]})}if(p.length>0){const u=p[Math.floor(Math.random()*p.length)],k=c.text.indexOf(u.word);c.randomPick={text:u.word,start:k>=0?k:0,end:k>=0?k+u.word.length:u.word.length},u.span.dataset.ttOriginal=u.span.innerHTML,u.span.dataset.ttRandomStart=String(u.localStart),u.span.dataset.ttRandomEnd=String(u.localEnd);const m=le(u.text.slice(0,u.localStart)),y="•".repeat(Math.min(u.word.length,8)),T=le(u.text.slice(u.localEnd));u.span.innerHTML=`${m}<span style="letter-spacing:2px;color:${a.violet};font-weight:bold">${y}</span>${T}`}}},revealWord:(c,p)=>{var k;const u=p!=null?t[p]:void 0,S=u?e.highlights.filter(m=>m.id===u):e.highlights;for(const m of S){for(const y of m.underlinedWords)if((y.text.replace(/^[.,;:!?'"()\-–—\s]+|[.,;:!?'"()\-–—\s]+$/g,"")===c||y.text===c)&&y.span.dataset.ttOriginal){y.span.innerHTML=`<span style="color:${a.greenInk};font-weight:bold">${y.span.dataset.ttOriginal}</span>`;return}if(m.role==="sentence"&&((k=m.randomPick)==null?void 0:k.text)===c){for(const y of m.spans)if(y.dataset.ttOriginal&&y.dataset.ttRandomStart){const T=parseInt(y.dataset.ttRandomStart,10),R=parseInt(y.dataset.ttRandomEnd,10),O=document.createElement("span");O.innerHTML=y.dataset.ttOriginal;const q=O.textContent||"",l=le(q.slice(0,T)),x=le(q.slice(T,R)),h=le(q.slice(R));y.innerHTML=`${l}<span style="color:${a.greenInk};font-weight:bold">${x}</span>${h}`;return}}if(m.role==="answer"&&Vt(m.text)===c){for(const y of m.spans)y.dataset.ttOriginal&&(y.innerHTML=`<span style="color:${a.greenInk};font-weight:bold">${y.dataset.ttOriginal}</span>`);return}}},showAnswers:()=>{for(const c of e.highlights){for(const p of c.underlinedWords)p.span.dataset.ttOriginal&&(p.span.innerHTML=p.span.dataset.ttOriginal,delete p.span.dataset.ttOriginal);for(const p of c.spans)p.dataset.ttOriginal&&(p.innerHTML=p.dataset.ttOriginal,delete p.dataset.ttOriginal,delete p.dataset.ttRandomStart,delete p.dataset.ttRandomEnd);delete c.randomPick}},destroy:()=>{for(const c of[...e.highlights])i(c.id);e.highlights=[],document.removeEventListener("mouseup",_,!0)}}}let Jt=1;function Zt(e){return Array.from(e).filter(t=>/[\p{L}\p{M}'''\-\s]/u.test(t)).join("")}function V(){const e=window.getSelection();e&&(window.__tiptongClearing=!0,e.removeAllRanges(),window.__tiptongClearing=!1)}function D(e){try{return e.startContainer.isConnected&&e.endContainer.isConnected}catch{return!1}}function en(e){let t=e.nodeType===Node.ELEMENT_NODE?e:e.parentElement;for(;t;){if(t.id||t.hasAttribute("data-page")||t.hasAttribute("data-chapter")||t.tagName==="ARTICLE"||t.tagName==="MAIN"||t.tagName==="SECTION")return t;t=t.parentElement}return document.body}function tn(e){if(e===document.body)return"body";if(e.id)return`#${CSS.escape(e.id)}`;const t=[];let n=e;for(;n&&n!==document.body;){if(n.id){t.unshift(`#${CSS.escape(n.id)}`);break}const o=n.parentElement;if(!o)break;const r=Array.from(o.children).indexOf(n);t.unshift(`${n.tagName.toLowerCase()}:nth-child(${r+1})`),n=o}return t.join(" > ")||"body"}function Fe(e,t,n){const o=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);let r=0,s;for(;s=o.nextNode();){if(s===t)return r+n;r+=(s.textContent||"").length}return r+n}function fe(e){const t=en(e.commonAncestorContainer);return{ancestorSelector:tn(t),charStart:Fe(t,e.startContainer,e.startOffset),charEnd:Fe(t,e.endContainer,e.endOffset),text:e.toString()}}function me(e){const t=document.querySelector(e.ancestorSelector);if(!t)return null;const n=document.createTreeWalker(t,NodeFilter.SHOW_TEXT);let o=0,r=null,s=0,i=null,d=0,b;for(;b=n.nextNode();){const g=(b.textContent||"").length;if(!r&&o+g>e.charStart&&(r=b,s=e.charStart-o),!i&&o+g>=e.charEnd){i=b,d=e.charEnd-o;break}o+=g}if(!r||!i)return null;try{const g=document.createRange();return g.setStart(r,s),g.setEnd(i,d),e.text&&g.toString()!==e.text?(console.warn("[TipTong] Re-anchored range text mismatch, skipping"),null):g}catch{return null}}function nn(e){const t=document.caretRangeFromPoint(e.clientX,e.clientY);if(!t||t.startContainer.nodeType!==Node.TEXT_NODE)return null;const n=t.startContainer,o=n.textContent||"",r=t.startOffset;if(r>=o.length||o[r]===" "||o[r]===`
`)return null;let s=r;for(;s>0&&o[s-1]!==" "&&o[s-1]!==`
`;)s--;let i=r;for(;i<o.length&&o[i]!==" "&&o[i]!==`
`;)i++;const d=document.createRange();return d.setStart(n,s),d.setEnd(n,i),d}function on(e){if(e.startContainer.nodeType===Node.TEXT_NODE){const t=e.startContainer.textContent||"";let n=e.startOffset;for(;n>0&&t[n-1]!==" "&&t[n-1]!==`
`;)n--;e.setStart(e.startContainer,n)}if(e.endContainer.nodeType===Node.TEXT_NODE){const t=e.endContainer.textContent||"";let n=e.endOffset;for(;n<t.length&&t[n]!==" "&&t[n]!==`
`;)n++;e.setEnd(e.endContainer,n)}}function Pe(e,t,n){try{const o=document.createRange();return o.setStart(e,t),o.collapse(!0),n.compareBoundaryPoints(Range.START_TO_START,o)<=0&&n.compareBoundaryPoints(Range.END_TO_END,o)>=0}catch{return!1}}function je(e,t){try{return e.compareBoundaryPoints(Range.START_TO_END,t)>0&&e.compareBoundaryPoints(Range.END_TO_START,t)<0}catch{return!1}}function Ee(e,t){try{return e.compareBoundaryPoints(Range.START_TO_START,t)}catch{return 0}}const Ce="tt-css-overlay",Ue=4;function rn(e){if(e.length===0)return[];const t=Array.from(e).sort((r,s)=>r.top-s.top||r.left-s.left),n=[];let o=t[0];for(let r=1;r<t.length;r++){const s=t[r];if(Math.abs(s.top-o.top)<2){const i=Math.min(o.left,s.left),d=Math.max(o.right,s.right),b=Math.min(o.top,s.top),g=Math.max(o.bottom,s.bottom);o=new DOMRect(i,b,d-i,g-b)}else n.push(o),o=s}return n.push(o),n}let Qe=!1;function Xe(){if(Qe)return;Qe=!0;let e=0;const t=()=>{e||(e=requestAnimationFrame(()=>{e=0,document.querySelectorAll(`.${Ce}, .${be}`).forEach(n=>{var o;(o=n.__ttRelayout)==null||o.call(n)})}))};document.addEventListener("scroll",t,!0),window.addEventListener("resize",t)}function Ye(e,t,n){const o=document.createElement("div");o.className=Ce,o.style.cssText="position: absolute; top: 0; left: 0; pointer-events: none; z-index: 999;";const r=()=>{o.textContent="";const s=e.getClientRects();let i;if(s.length>0)i=rn(s);else{const g=e.getBoundingClientRect();i=g.width===0&&g.height===0?[]:[g]}if(i.length===0){o.style.display="none";return}o.style.display="";const d=window.scrollX,b=window.scrollY;for(let g=0;g<i.length;g++){const $=i[g];let L="8px";i.length>1&&(L=g===0?"8px 8px 0 0":g===i.length-1?"0 0 8px 8px":"0");const _=document.createElement("div");_.style.cssText=`
        position: absolute;
        top: ${$.top+b}px;
        left: ${$.left+d-Ue}px;
        width: ${$.width+Ue*2}px;
        height: ${$.height}px;
        ${n}
        border-radius: ${L};
        display: flex;
        align-items: center;
        justify-content: center;
        pointer-events: none;
      `,g===0&&(_.textContent=t),o.appendChild(_)}};return r(),o.__ttRelayout=r,Xe(),document.body.appendChild(o),o}function sn(){document.querySelectorAll(`.${Ce}`).forEach(e=>e.remove())}const be="tt-css-badge";function Ve(){document.querySelectorAll(`.${be}`).forEach(e=>e.remove())}function Te(e){if(Ve(),e.deleteMode)return;const t=e.highlights.filter(o=>o.role==="question"||o.role==="answer");for(const o of t){const r=o.ranges[0];if(!r||!D(r))continue;const s=r.getClientRects(),i=s.length>0?s[0]:r.getBoundingClientRect();if(i.width===0&&i.height===0)continue;const d=document.createElement("div");d.className=be;const b=o.role==="answer";d.textContent=b?"A":"Q",d.style.cssText=`
      position: absolute;
      top: ${i.top+window.scrollY-8}px;
      left: ${i.left+window.scrollX-8}px;
      width: 18px;
      height: 18px;
      background: ${b?a.green:a.violet};
      color: ${b?a.dark:"white"};
      font-size: ${C.small};
      font-weight: bold;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      pointer-events: none;
      z-index: 1000;
      line-height: 1;
    `,d.__ttRelayout=()=>{const g=r.getClientRects(),$=g.length>0?g[0]:r.getBoundingClientRect();d.style.display=$.width===0&&$.height===0?"none":"flex",d.style.top=`${$.top+window.scrollY-8}px`,d.style.left=`${$.left+window.scrollX-8}px`},document.body.appendChild(d)}const n=[];for(const o of e.highlights){o.cue&&o.ranges[0]&&n.push({range:o.ranges[0],cue:o.cue});for(const r of o.underlinedWords)r.cue&&n.push({range:r.range,cue:r.cue})}for(const o of n){if(!D(o.range))continue;const r=document.createElement("div");r.className=be,r.textContent="✎",r.title=`My cue: ${o.cue}`,r.style.cssText=`
      position: absolute;
      width: 16px;
      height: 16px;
      background: ${a.violet};
      color: white;
      font-size: 10px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      pointer-events: none;
      z-index: 1000;
      line-height: 1;
    `;const s=()=>{const i=o.range.getClientRects(),d=i.length>0?i[0]:o.range.getBoundingClientRect();r.style.display=d.width===0&&d.height===0?"none":"flex",r.style.top=`${d.top+window.scrollY-8}px`,r.style.left=`${d.right+window.scrollX-6}px`};s(),r.__ttRelayout=s,document.body.appendChild(r)}Xe()}function K(e){if(typeof CSS>"u"||!("highlights"in CSS))return;const t=CSS.highlights,n=[],o=[],r=[],s=[],i=[];for(const d of e.highlights){const b=e.deleteMode?i:d.role==="answer"?o:d.role==="question"?n:r;for(const g of d.ranges)D(g)&&b.push(g);for(const g of d.underlinedWords)!e.deleteMode&&D(g.range)&&s.push(g.range)}t.delete("tt-question"),t.delete("tt-answer"),t.delete("tt-sentence"),t.delete("tt-underline"),t.delete("tt-delete");try{n.length>0&&t.set("tt-question",new window.Highlight(...n)),o.length>0&&t.set("tt-answer",new window.Highlight(...o)),r.length>0&&t.set("tt-sentence",new window.Highlight(...r)),s.length>0&&t.set("tt-underline",new window.Highlight(...s)),i.length>0&&t.set("tt-delete",new window.Highlight(...i))}catch(d){console.warn("[TipTong] CSS Highlight API error:",d)}Te(e)}function an(){te(),ht();const e={mode:"hhh",highlights:[],deleteMode:!1},t=[];let n=[],o=null;function r(){let l=!1;for(const x of e.highlights){for(let h=0;h<x.ranges.length;h++)if(!D(x.ranges[h])&&x.anchors[h]){const v=me(x.anchors[h]);v&&(x.ranges[h]=v,l=!0)}for(let h=0;h<x.underlinedWords.length;h++){const v=x.underlinedWords[h];if(!D(v.range)&&v.anchor){const w=me(v.anchor);w&&(v.range=w,l=!0)}}}l&&K(e)}function s(){o&&clearTimeout(o),o=setTimeout(r,100)}const i=new MutationObserver(l=>{if(e.highlights.length===0)return;l.some(h=>h.type==="childList"&&(h.addedNodes.length>0||h.removedNodes.length>0))&&s()});i.observe(document.body,{childList:!0,subtree:!0});let d=null;document.addEventListener("mouseup",()=>{const l=window.getSelection();l&&!l.isCollapsed&&l.rangeCount>0?(d=l.getRangeAt(0).cloneRange(),V()):d=null},!0);function b(l,x){for(const h of e.highlights){for(const v of h.ranges)if(Pe(l,x,v))return h;for(const v of h.underlinedWords)if(Pe(l,x,v.range))return h}return null}function g(l){for(const x of e.highlights)for(const h of x.ranges)if(je(l,h))return x;return null}function $(){const l=d;if(d=null,!l)return;if(e.deleteMode)if(l.toString().trim().length>0)e.deleteMode=!1,K(e);else return;if(!l.toString().trim())return;const h=document.getElementById("tt-toolbar"),v=document.getElementById("tt-popup");if(h!=null&&h.contains(l.startContainer)){V();return}if(v!=null&&v.contains(l.startContainer)){V();return}on(l);const w=l.toString().trim();if(!w){V();return}const f=b(l.startContainer,l.startOffset),E=b(l.endContainer,l.endOffset);if(f&&f===E){if(e.mode==="hhh"&&f.role==="sentence"){V();return}V();return}const H=f||E||g(l);if(H){L(H,l),V(),K(e);return}if(e.mode==="hhh"&&w.split(/\s+/).filter(Boolean).length<2){V();return}const M=e.highlights.filter(ce=>ce.role!=="sentence").length,j=e.mode==="qa"?M%2===0?"question":"answer":"sentence",Z=`tt-css-${Jt++}`,oe=fe(l),B={id:Z,text:w,role:j,ranges:[l],anchors:[oe],underlinedWords:[]};e.highlights.push(B),V(),K(e)}function L(l,x){try{const h=[...l.ranges,x];let v=h[0],w=h[0];for(const E of h)E.compareBoundaryPoints(Range.START_TO_START,v)<0&&(v=E),E.compareBoundaryPoints(Range.END_TO_END,w)>0&&(w=E);const f=document.createRange();f.setStart(v.startContainer,v.startOffset),f.setEnd(w.endContainer,w.endOffset),l.ranges=[f],l.anchors=[fe(f)],l.text=f.toString().trim(),l.underlinedWords=[]}catch{}}function _(l,x){const h=nn(x);if(!h)return;const v=h.toString().trim();if(!v)return;const w=l.underlinedWords.findIndex(f=>{try{return je(f.range,h)||f.text===v}catch{return f.text===v}});if(w>=0)l.underlinedWords.splice(w,1);else{const f=l.text.split(/\s+/).filter(Boolean).length,E=Math.floor(f/2);if(l.underlinedWords.length>=E)return;const H=h.cloneRange();l.underlinedWords.push({text:v,range:H,anchor:fe(H)})}K(e)}function c(l){const x=e.highlights.find(v=>v.id===l);if(!x)return;const h=new Set([l]);if(x.role==="question"||x.role==="answer"){const v=e.highlights.filter(H=>H.role!=="sentence"),w=v.findIndex(H=>H.id===l),E=w%2===0?w+1:w-1;E>=0&&E<v.length&&h.add(v[E].id)}e.highlights=e.highlights.filter(v=>!h.has(v.id)),e.highlights.length===0&&(e.deleteMode=!1),K(e)}let p=0;function u(l){var oe;if(e.deleteMode)return;const x=document.getElementById("tt-toolbar"),h=document.getElementById("tt-popup");if(x!=null&&x.contains(l.target)||h!=null&&h.contains(l.target)||(oe=document.getElementById("tt-cue-overlay"))!=null&&oe.contains(l.target))return;const v=document.caretRangeFromPoint(l.clientX,l.clientY);if(!v)return;const w=b(v.startContainer,v.startOffset);if(!w)return;const f=w.underlinedWords.find(B=>{try{return D(B.range)&&B.range.comparePoint(v.startContainer,v.startOffset)===0}catch{return!1}}),E=l.clientX,H=l.clientY;let M=setTimeout(()=>{M=null,p=Date.now()+600,V(),Be({context:f?f.text:w.text,scope:f?"word":"exercise",initial:(f?f.cue:w.cue)??"",onSave:B=>{f?f.cue=B:w.cue=B,Te(e)},onRemove:()=>{f?f.cue=void 0:w.cue=void 0,Te(e)}})},500);const j=()=>{M&&(clearTimeout(M),M=null),document.removeEventListener("pointermove",Z),document.removeEventListener("pointerup",j)},Z=B=>{Math.hypot(B.clientX-E,B.clientY-H)>8&&j()};document.addEventListener("pointermove",Z),document.addEventListener("pointerup",j)}function S(l){var E,H;if(Date.now()<p){l.preventDefault(),l.stopPropagation();return}const x=document.getElementById("tt-toolbar"),h=document.getElementById("tt-popup");if(x!=null&&x.contains(l.target)||h!=null&&h.contains(l.target))return;const v=document.caretRangeFromPoint(l.clientX,l.clientY);if(!v)return;const w=b(v.startContainer,v.startOffset);if(!w)return;if(e.deleteMode){if(l.preventDefault(),l.stopPropagation(),w.role==="sentence"){const M=w.underlinedWords.findIndex(j=>{try{return D(j.range)&&j.range.comparePoint(v.startContainer,v.startOffset)===0}catch{return!1}});if(M>=0){w.underlinedWords.splice(M,1),K(e);return}}c(w.id);return}if(e.mode==="hhh"&&w.role==="sentence"){const M=window.getSelection();if(M&&!M.isCollapsed)return;l.preventDefault(),l.stopPropagation(),_(w,l)}((H=(E=l.target).closest)==null?void 0:H.call(E,"a"))&&w&&(l.preventDefault(),l.stopPropagation())}const k=()=>setTimeout($,10);document.addEventListener("mouseup",k,!0),document.addEventListener("click",S,!0),document.addEventListener("pointerdown",u,!0);function m(l,x){const h="•".repeat(Math.min(x.length,12)),v=Ye(l,h,`background: white; color: ${a.violet}; font-weight: bold; letter-spacing: 2px; font-size: inherit; box-shadow: 0 1px 4px rgba(0,0,0,0.1);`);return t.push(v),v}function y(l,x){const h=Ye(l,x,`background: white; color: ${a.greenInk}; font-weight: bold; font-size: inherit; box-shadow: 0 1px 4px rgba(0,0,0,0.1);`);return t.push(h),h}function T(){for(const l of t)l.remove();t.length=0,sn()}function R(l){const x=l.ranges[0];if(!x||!D(x))return null;const h=[],v=O(x);let w=0;for(const Z of v){const oe=Z.textContent||"",B=Z===x.startContainer?x.startOffset:0,ce=Z===x.endContainer?x.endOffset:oe.length,dt=oe.slice(B,ce),$n=/[\p{L}\p{M}'']+/gu;let ie;for(;(ie=$n.exec(dt))!==null;)h.push({word:ie[0],node:Z,localStart:B+ie.index,localEnd:B+ie.index+ie[0].length,hlTextOffset:w+ie.index});w+=dt.length}if(h.length===0)return null;const f=h[Math.floor(Math.random()*h.length)],E=document.createRange();try{E.setStart(f.node,f.localStart),E.setEnd(f.node,f.localEnd)}catch{return null}const H=l.text.indexOf(f.word,f.hlTextOffset>0?f.hlTextOffset-1:0),M=H>=0?H:f.hlTextOffset,j=M+f.word.length;return{text:f.word,start:M,end:j,range:E}}function O(l){const x=l.commonAncestorContainer,h=[];if(x.nodeType===Node.TEXT_NODE)h.push(x);else{const v=document.createTreeWalker(x,NodeFilter.SHOW_TEXT);let w;for(;w=v.nextNode();){try{const f=document.createRange();if(f.selectNodeContents(w),l.compareBoundaryPoints(Range.START_TO_END,f)>0||l.compareBoundaryPoints(Range.END_TO_START,f)<0)continue}catch{continue}h.push(w)}}return h}function q(l,x){const h=O(l);for(const v of h){const f=(v.textContent||"").indexOf(x);if(f>=0)try{const E=document.createRange();return E.setStart(v,f),E.setEnd(v,f+x.length),E}catch{continue}}return null}return{getSelections:()=>e.highlights.map(l=>({id:l.id,text:l.text,role:l.role,underlinedCount:l.underlinedWords.length})),validate:()=>{const l=[];return e.highlights.filter(h=>h.role!=="sentence").length%2!==0&&l.push("Last question needs an answer"),l},getMode:()=>e.mode,setMode:l=>{e.mode=l,e.deleteMode&&(e.deleteMode=!1),K(e)},toggleDeleteMode:()=>(e.deleteMode=!e.deleteMode,K(e),e.deleteMode),isDeleteMode:()=>e.deleteMode,getQAPairs:()=>{const l=e.highlights.filter(h=>h.role!=="sentence"),x=[];for(let h=0;h+1<l.length;h+=2)x.push({question:l[h].text,answer:l[h+1].text});return x},getHHHData:()=>e.highlights.filter(x=>x.role==="sentence").map(x=>{const h=x.text,v=x.underlinedWords.map(w=>{const f=h.indexOf(w.text);return f>=0?{start:f,end:f+w.text.length}:null}).filter(w=>w!==null);return{sourceText:h,sentenceStart:0,sentenceEnd:h.length,underlinedWords:v}}),getOrderedExerciseData:()=>{const l=[];n=[];const x=[...e.highlights].sort((w,f)=>{const E=w.ranges[0],H=f.ranges[0];return!E||!H?0:Ee(E,H)}),h=x.filter(w=>w.role!=="sentence"),v=new Set;for(const w of x)if(w.role==="question"){const f=h.indexOf(w),E=Math.floor(f/2);if(v.has(E))continue;const H=h[f+1];H&&(v.add(E),l.push({type:"qa",question:w.text,answer:H.text,cue:w.cue??H.cue}),n.push(H.id))}else{if(w.role==="answer")continue;{const f=w.text;let E=w.underlinedWords.map(H=>{const M=f.indexOf(H.text);return M>=0?{start:M,end:M+H.text.length,cue:H.cue}:null}).filter(H=>H!==null);E.length===0&&w.randomPick&&(E=[{start:w.randomPick.start,end:w.randomPick.end}]),l.push({type:"hhh",sourceText:f,sentenceStart:0,sentenceEnd:f.length,underlinedWords:E,cue:w.cue}),n.push(w.id)}}return l},hideAnswers:()=>{for(const l of e.highlights)if(l.role==="answer"){for(const x of l.ranges)if(D(x))try{m(x,l.text)}catch(h){console.warn("[TipTong] hideAnswers overlay error:",h)}}},hideUnderlinedWords:()=>{for(const l of e.highlights)if(l.role==="sentence")if(l.underlinedWords.length>0){const x=l.underlinedWords.filter(v=>D(v.range)).sort((v,w)=>Ee(v.range,w.range)),h=[];for(const v of x){const w=h[h.length-1];if(w){const f=w.range.getBoundingClientRect(),E=v.range.getBoundingClientRect();if(Math.abs(f.top-E.top)<2&&E.left-f.right<f.height){const M=document.createRange();M.setStart(w.range.startContainer,w.range.startOffset),M.setEnd(v.range.endContainer,v.range.endOffset),w.range=M,w.text+=" "+v.text;continue}}h.push({range:v.range.cloneRange(),text:v.text})}for(const v of h)try{m(v.range,v.text)}catch(w){console.warn("[TipTong] hideUnderlinedWords overlay error:",w)}}else{const x=R(l);if(x){l.randomPick={text:x.text,start:x.start,end:x.end,range:x.range,anchor:fe(x.range)};try{m(x.range,x.text)}catch(h){console.warn("[TipTong] hideRandom overlay error:",h)}}}},revealWord:(l,x)=>{var w;const h=x!=null?n[x]:void 0,v=h?e.highlights.filter(f=>f.id===h):e.highlights;for(const f of v){for(const E of f.underlinedWords)if(E.text.replace(/^[.,;:!?'"()\-–—\s]+|[.,;:!?'"()\-–—\s]+$/g,"")===l||E.text===l){D(E.range)&&y(E.range,E.text);return}if(f.underlinedWords.length>1&&f.role==="sentence"){const E=[...f.underlinedWords].filter(M=>D(M.range)).sort((M,j)=>Ee(M.range,j.range)),H=E.map(M=>M.text.replace(/^[.,;:!?'"()\-–—\s]+|[.,;:!?'"()\-–—\s]+$/g,"")).join(" ");if(H===l||H.includes(l)){for(const M of E)D(M.range)&&y(M.range,M.text);return}}if(f.role==="sentence"&&((w=f.randomPick)==null?void 0:w.text)===l){let E=f.randomPick.range;if(E&&!D(E)&&f.randomPick.anchor&&(E=me(f.randomPick.anchor)??void 0,E&&(f.randomPick.range=E)),E&&D(E)){y(E,l);return}const H=f.ranges[0];if(H&&D(H)){const M=q(H,l);if(M){y(M,l);return}}}if(f.role==="answer"&&Zt(f.text)===l){for(let E=0;E<f.ranges.length;E++){let H=f.ranges[E];if(!D(H)&&f.anchors[E]){const M=me(f.anchors[E]);M&&(f.ranges[E]=M,H=M)}D(H)&&y(H,f.text)}return}}},showAnswers:()=>{T();for(const l of e.highlights)delete l.randomPick},destroy:()=>{if(T(),Ve(),i.disconnect(),o&&clearTimeout(o),e.highlights=[],e.deleteMode=!1,typeof CSS<"u"&&"highlights"in CSS){const l=CSS.highlights;l.delete("tt-question"),l.delete("tt-answer"),l.delete("tt-sentence"),l.delete("tt-underline"),l.delete("tt-delete")}document.removeEventListener("mouseup",k,!0),document.removeEventListener("click",S,!0),document.removeEventListener("pointerdown",u,!0)}}}function Ge(e,t){return e.hintUsages.filter(n=>n.queryId===t&&n.type===W.SELF_AUTHORED).length}function Ke(e,t,n){const o=e.hintUsages.some(r=>r.queryId===t.id&&re(r.type).autoRevealsLength);return Lt(n,t.answer,ae(t),{lengthAlreadyKnown:o,remainingCues:Rt(t.customCues,Ge(e,t.id)).length})}function _e(e,t,n){const o=e.exercise.queries.find(i=>i.id===t);if(!o)return null;const r=new Set(e.hintUsages.filter(i=>i.queryId===t).map(i=>i.type)),s=we.filter(i=>n!=null&&n.has(i.id)?!1:(!r.has(i.id)||i.repeatable)&&Ke(e,o,i));return s.length===0?null:s[Math.floor(Math.random()*s.length)]}function ln(e,t){const n=t?e.hintUsages.filter(d=>d.queryId===t):[],o=Math.min(n.reduce((d,b)=>d+b.cost,0),100),r=e.exercise.queries.filter(d=>z(d).correct===z(d).total).map(d=>ye(e.hintUsages.filter(b=>b.queryId===d.id))),s=r.length>0?r.reduce((d,b)=>d+b,0)/r.length:0,i=o<30?a.green:o<60?a.yellow:a.orange;return`
    <div class="tt-help-bar" data-score="${o}">
      <div class="tt-help-bar__labels">
        <span class="tt-help-bar__label">Help used: ${Math.round(o)}%<span class="tt-help-bar__preview"></span></span>
        ${r.length>0?`<span class="tt-help-bar__avg">avg: ${Math.round(s)===0?"Perfect!":Math.round(s)+"%"}</span>`:""}
      </div>
      <div class="tt-help-bar__track">
        <div class="tt-help-bar__fill" style="width:${Math.min(o,100)}%;background:${i}"></div>
        <div class="tt-help-bar__ghost" style="left:${Math.min(o,100)}%"></div>
      </div>
    </div>
  `}const cn=(()=>{try{return localStorage.getItem("tiptong_app_url")??"https://maganino.github.io/TipTong-pilot"}catch{return"https://maganino.github.io/TipTong-pilot"}})();function Je(e,t){var r,s,i;(r=document.getElementById("tt-save-overlay"))==null||r.remove();const n=document.createElement("div");n.id="tt-save-overlay",n.className="tt-save-overlay";const o=e.length;n.innerHTML=`<div class="tt-save-card tt-save-card--invite">
    <div class="tt-save-wordmark">TipTong</div>
    <div class="tt-save-num">${o}</div>
    <div class="tt-save-what">exercise${o!==1?"s":""} ready</div>
    <div class="tt-save-line">Yours to keep — play anywhere, hints and scores included.</div>
    <button class="tt-save-go-btn" id="tt-save-go">▶&nbsp; Save &amp; play in the app</button>
    <div class="tt-save-cancel" id="tt-save-cancel">Not now</div>
  </div>`,document.body.appendChild(n),(s=n.querySelector("#tt-save-go"))==null||s.addEventListener("click",()=>{var L;const d=t&&t.length>0?{exercises:e,scores:t}:e,b=JSON.stringify(d),g=btoa(encodeURIComponent(b).replace(/%([0-9A-F]{2})/g,(_,c)=>String.fromCharCode(parseInt(c,16)))),$=`${cn}/?import=${g}`;typeof chrome<"u"&&((L=chrome.runtime)!=null&&L.sendMessage)?chrome.runtime.sendMessage({type:"tiptong:open-tab",url:$}):window.open($,"_blank"),n.querySelector(".tt-save-card").innerHTML=`
      <div class="tt-save-done-ring">&#10003;</div>
      <div class="tt-save-what">Off to the app</div>
      <div class="tt-save-line" style="margin-bottom:8px">Pick a playlist there to finish</div>
    `,setTimeout(()=>n.remove(),2e3)}),(i=n.querySelector("#tt-save-cancel"))==null||i.addEventListener("click",()=>n.remove()),n.addEventListener("click",d=>{d.target===n&&n.remove()})}function dn(e,t){var i,d;const n=new Array(e.blanks.length).fill(null),o=new Set;for(let b=0;b<e.blanks.length;b++){const g=e.blanks[b];if(g.revealed||g.actual!==""&&g.actual.toLowerCase()===g.expected.toLowerCase()){if(!o.has(b)&&((i=t[b])==null?void 0:i.toLowerCase())===g.expected.toLowerCase())o.add(b);else for(let $=0;$<t.length;$++)if(!o.has($)&&((d=t[$])==null?void 0:d.toLowerCase())===g.expected.toLowerCase()){o.add($);break}}}const r=[];for(let b=0;b<t.length;b++)!o.has(b)&&t[b]!==" "&&r.push(t[b]);let s=0;for(let b=0;b<e.blanks.length;b++){const g=e.blanks[b];g.expected===" "||g.revealed||g.actual!==""&&g.actual.toLowerCase()===g.expected.toLowerCase()||g.actual===""&&s<r.length&&(n[b]=r[s],s++)}return n}function Ze(e,t){return t.some(n=>n.queryId!==e?!1:re(n.type).autoRevealsLength)}function et(e,t){if(!e.blanks.some(i=>i.actual!==""||i.revealed))return`<span class="tt-inline-blank ${t?"tt-inline-blank--active":""}" data-query="${e.id}">···</span>`;let o=-1;for(let i=e.blanks.length-1;i>=0;i--){const d=e.blanks[i];if(d.revealed||d.actual!==""){o=i;break}}const r=o<e.blanks.length-1;let s=`<span class="tt-inline-blank" data-query="${e.id}">`;for(let i=0;i<=o;i++){const d=e.blanks[i];if(d.expected===" ")s+=" ";else if(d.revealed)s+=`<span class="tt-inline-char tt-inline-char--revealed">${d.expected}</span>`;else if(d.actual==="")s+='<span class="tt-inline-char tt-inline-char--empty">·</span>';else{const b=d.actual.toLowerCase()===d.expected.toLowerCase();s+=`<span class="tt-inline-char ${b?"tt-inline-char--correct":"tt-inline-char--wrong"}">${d.actual}</span>`}}return r&&(s+='<span class="tt-inline-char tt-inline-char--empty">...</span>'),s+="</span>",s}function tt(e,t,n){const o=n?dn(e,n):null;let r='<div class="tt-blanks">';for(let s=0;s<e.blanks.length;s++){const i=e.blanks[s];if(i.expected===" "){r+='<div class="tt-blank-word-gap"></div>';continue}const d=i.actual!=="",b=i.revealed,g=d&&i.actual.toLowerCase()===i.expected.toLowerCase(),$=d&&!g&&!b,L=o==null?void 0:o[s],_=!b&&!d&&!!L;let c="tt-blank";b?c+=" tt-blank--revealed":g?c+=" tt-blank--correct":$?c+=" tt-blank--wrong":_&&(c+=" tt-blank--shuffled"),t&&(c+=" tt-blank--active");const p=b?i.expected:d?i.actual:_?L:" ";r+=`<div class="${c}" data-reveal-char="${s}" data-reveal-query="${e.id}" style="cursor:pointer">${p}</div>`}return r+="</div>",r}function un(e){const t=e.state,{exercise:n}=t,{originalSentence:o,queries:r}=n;let s="",i=0;for(const d of r){d.startIndex>i&&(s+=`<span class="tt-sentence-text">${ne(o.slice(i,d.startIndex))}</span>`);const b=z(d),g=b.correct===b.total,$=Ze(d.id,t.hintUsages),L=e.activeQueryId===d.id,_=t.shuffledLettersMap[d.id];g?s+=`<span class="tt-solved">${ne(d.answer)}</span>`:$?s+=`<span data-query="${d.id}">${tt(d,L,_)}</span>`:s+=et(d,L),i=d.endIndex}return i<o.length&&(s+=`<span class="tt-sentence-text">${ne(o.slice(i))}</span>`),s}function pn(e){const t=e.state.exercise.queries;if(t.length<=1)return"";let n='<div class="tt-word-progress">';for(let o=0;o<t.length;o++){const r=t[o],s=z(r).correct===z(r).total,i=e.activeQueryId===r.id;let d="tt-word-dot";s&&(d+=" tt-word-dot--done"),i&&(d+=" tt-word-dot--active"),n+=`<span class="${d}" data-query-dot="${r.id}">${s?"✓":o+1}</span>`}return n+="</div>",n}function gn(e,t){const n=e.exercise.queries.find(s=>s.id===t);if(!n)return"";const o=new Set(e.hintUsages.filter(s=>s.queryId===t).map(s=>s.type));let r='<div class="tt-hints">';for(const s of we){const d=o.has(s.id)&&!s.repeatable||!Ke(e,n,s),b=`tt-hint-chip${d?" tt-hint-chip--disabled":""}`,g=d?0:Ie(s,n.answer,ae(n)),$=g>0?`${s.description} — costs ${g}% help`:s.description;r+=`<button class="${b}" data-hint="${s.id}" data-cost="${g}" title="${$}"${d?" disabled":""}>${s.icon} ${s.label.split(" ")[0]}</button>`}return r+="</div>",r}function hn(e,t){const n=Math.round(t)===0?"Perfect!":`Help: ${Math.round(t)}%`,o=t<30?a.green:t<60?a.yellow:a.orange,r=document.createElement("div");r.className="tt-query-score",r.style.cssText=`
    text-align:center;padding:6px 12px;margin:4px 0;
    border-radius: ${N.sm};font-size: ${C.small};font-weight:700;
    color:${o};background:${o}15;
    animation:tt-fade-in 0.2s ease;
  `,r.textContent=n;const s=e.querySelector(".tt-answer-box");s?s.parentNode.insertBefore(r,s):e.appendChild(r)}function P(e){var p;if(!e.state||!e.popup)return;const{exercise:t}=e.state,n=e.popup.querySelector(".tt-popup__body");if(!n)return;if(e.minimized){n.style.display="none";return}n.style.display="block",t.type;const o=t.type==="hhh";if(!e.activeQueryId){const u=t.queries.find(S=>z(S).correct!==z(S).total);u&&(e.activeQueryId=u.id)}if(t.queries.every(u=>z(u).correct===z(u).total)){const u=e.currentIndex>=e.exercises.length-1,S=ye(e.state.hintUsages),k=Math.round(S)===0?"Perfect!":`Help needed: ${Math.round(S)}%`;n.innerHTML=`
      <div class="tt-complete">
        <div class="tt-complete__check">&#10003;</div>
        <p style="font-size: ${C.body};margin:8px 0">${ne(t.originalSentence)}</p>
        <p style="font-size: ${C.small};color:${S<30?a.green:S<60?a.yellow:a.orange};font-weight:600;margin:4px 0">${k}</p>
        ${u?`<button class="tt-hint-chip" style="margin-top:16px;font-size:${C.small}" data-action="close">Done</button>`:`<button class="tt-hint-chip" style="margin-top:16px;font-size:${C.small}" data-action="next">Next &rarr;</button>`}
        ${u?`<button class="tt-hint-chip" style="margin-top:8px;font-size:${C.small};border:1px solid ${a.yellow};color:${a.yellow}" data-action="save">Save to playlist</button>`:""}
      </div>
    `,nt(e);return}const s=t.queries.find(u=>u.id===e.activeQueryId)??null,i=s?t.queries.indexOf(s):-1;let d="";if(o)d+=`<div class="tt-sentence">${un(e)}</div>`,d+=pn(e);else if(d+=`<div class="tt-popup__question">${ne(t.originalSentence)} ?</div>`,s){const u=Ze(s.id,e.state.hintUsages),S=e.state.shuffledLettersMap[s.id];u?d+=tt(s,!0,S):d+=et(s,!0)}if(s){const u=At(s),S=o?`${i+1}/${t.queries.length}`:"Type the answer",k=e.flashHint?`<span class="tt-hint-flash-inline">${e.flashHint.icon} ${e.flashHint.label}</span>`:"",m=e.suggestedFor===s.id?e.suggested:null,y=!e.showHints&&!e.flashHint&&m?`<button class="tt-hint-flash-inline tt-hint-chip--suggested" id="tt-suggested">${m.icon} ${m.label.split(" ")[0]} · ${Ie(m,s.answer,ae(s))}%</button>`:"",T=e.showHints?`<div class="tt-hints-inline">${gn(e.state,s.id)}</div>`:"",O=(s.customCues??[]).slice(0,Ge(e.state,s.id)),q=O.length>0?`<div class="tt-cue-reveal">${O.map(l=>`<div>✎ ${ne(l)}</div>`).join("")}</div>`:"";d+=`
      <div class="tt-answer-box">
        <div class="tt-answer-header">
          <span class="tt-answer-label">${S}</span>
          ${T}
          <div style="display:flex;align-items:center;margin-left:auto;gap:4px">
            ${k}${y}
            <button class="tt-bulb ${e.showHints?"tt-bulb--active":""}" id="tt-bulb">💡</button>
          </div>
        </div>
        ${q}
        <input class="tt-input" value="${ne(u)}" placeholder="Type here..." autocomplete="off" autocorrect="off" autocapitalize="off" />
      </div>
    `}d+=ln(e.state,e.activeQueryId),d+=`<div class="tt-score">Exercise ${e.currentIndex+1} of ${e.exercises.length}</div>`,n.innerHTML=d;const b=u=>{!e.state||!s||(e.state=Mt(e.state,s.id,u.id),e.flashHint=u,e.suggested=null,e.suggestedFor=null,e.showHints=!1,P(e),setTimeout(()=>{e.flashHint===u&&(e.flashHint=null,P(e))},2e3))},g=n.querySelector("#tt-bulb");if(g&&s){let k=null,m=!1,y=!1,T=0,R=0,O=null;const q=()=>{O==null||O.classList.remove("tt-hint-chip--tracked"),O=null},l=(h,v)=>{var f,E;const w=(E=(f=document.elementFromPoint(h,v))==null?void 0:f.closest)==null?void 0:E.call(f,"[data-hint]");w!==O&&(q(),w&&!w.hasAttribute("disabled")&&(O=w,w.classList.add("tt-hint-chip--tracked")))},x=()=>{if(!e.state)return;const h=new Set;e.suggested&&h.add(e.suggested.id),e.lastSuggestion&&h.add(e.lastSuggestion);const v=e.suggested?new Set([e.suggested.id]):void 0,w=_e(e.state,s.id,h)??_e(e.state,s.id,v)??_e(e.state,s.id);w&&(e.lastSuggestion=w.id,e.suggested=w,e.suggestedFor=s.id,e.flashHint=null,P(e))};g.addEventListener("pointerdown",h=>{h.preventDefault(),m=!1,y=!1,T=h.clientX,R=h.clientY,e.showHints||(k=setTimeout(()=>{k=null,y=!0,e.suggested=null,e.suggestedFor=null,e.flashHint=null,e.showHints=!0,P(e)},300));const v=f=>{!m&&Math.hypot(f.clientX-T,f.clientY-R)>10&&(m=!0),e.showHints&&l(f.clientX,f.clientY)},w=()=>{if(document.removeEventListener("pointermove",v),k&&(clearTimeout(k),k=null),e.showHints){const f=O;q(),f?b(re(f.dataset.hint)):!y&&!m&&(e.showHints=!1,P(e))}else m||x()};document.addEventListener("pointermove",v),document.addEventListener("pointerup",w,{once:!0})}),g.addEventListener("contextmenu",h=>h.preventDefault())}(p=n.querySelector("#tt-suggested"))==null||p.addEventListener("click",()=>{const u=e.suggestedFor===(s==null?void 0:s.id)?e.suggested:null;u&&b(u)});const $=n.querySelector(".tt-input");$&&s&&($.focus(),$.setSelectionRange($.value.length,$.value.length),$.addEventListener("input",()=>{var k;if(!e.state||!s)return;e.flashHint=null,e.state=It(e.state,s.id,$.value);const u=e.state.exercise.queries.find(m=>m.id===s.id),S=z(u);if(S.correct===S.total){(k=e.onWordComplete)==null||k.call(e,u.answer,e.currentIndex);const m=e.state.hintUsages.filter(R=>R.queryId===s.id),y=ye(m);e.completedScores.push({exerciseId:e.state.exercise.id,queryId:s.id,score:y,hintUsages:m.map(R=>({type:R.type,cost:R.cost}))});const T=e.state.exercise.queries.find(R=>R.id!==s.id&&z(R).correct!==z(R).total);if(T){hn(n,y),setTimeout(()=>{e.activeQueryId=T.id,P(e)},1200);return}}P(e)}));const L=n.querySelector(".tt-help-bar"),_=n.querySelector(".tt-help-bar__ghost"),c=n.querySelector(".tt-help-bar__preview");n.querySelectorAll("[data-hint]").forEach(u=>{u.addEventListener("click",()=>{!e.state||!s||b(re(u.dataset.hint))}),u.addEventListener("mouseenter",()=>{const S=Number(u.dataset.cost??0);if(!L||!_||S<=0)return;const k=Number(L.dataset.score??0);_.style.width=`${Math.max(0,Math.min(S,100-k))}%`,c&&(c.textContent=` → ${Math.min(Math.round(k+S),100)}%`)}),u.addEventListener("mouseleave",()=>{_&&(_.style.width="0%"),c&&(c.textContent="")})}),n.querySelectorAll("[data-reveal-char]").forEach(u=>{u.addEventListener("click",S=>{var T;if(S.stopPropagation(),!e.state)return;const k=parseInt(u.dataset.revealChar,10),m=u.dataset.revealQuery;e.activeQueryId!==m&&(e.activeQueryId=m),e.state=Nt(e.state,m,k);const y=e.state.exercise.queries.find(R=>R.id===m);if(y){const R=z(y);R.correct===R.total&&((T=e.onWordComplete)==null||T.call(e,y.answer,e.currentIndex))}P(e)})}),n.querySelectorAll("[data-query]").forEach(u=>{u.addEventListener("click",()=>{const S=u.dataset.query;e.activeQueryId!==S&&(e.activeQueryId=S,P(e))})}),n.querySelectorAll("[data-query-dot]").forEach(u=>{u.addEventListener("click",()=>{const S=u.dataset.queryDot;e.activeQueryId=S,e.showHints=!1,e.flashHint=null,P(e)})}),nt(e)}function nt(e){var t,n;e.popup&&(e.popup.querySelectorAll("[data-action]").forEach(o=>{o.addEventListener("click",()=>{const r=o.dataset.action;r==="next"?(e.currentIndex++,e.activeQueryId=null,e.showHints=!1,e.flashHint=null,e.currentIndex<e.exercises.length&&(e.state=Oe(e.exercises[e.currentIndex]),P(e))):r==="close"?ot(e):r==="save"&&Je(e.exercises,e.completedScores)})}),(t=e.popup.querySelector(".tt-popup__close"))==null||t.addEventListener("click",()=>{ot(e)}),(n=e.popup.querySelector(".tt-popup__minimize"))==null||n.addEventListener("click",()=>{e.minimized=!e.minimized;const o=e.popup.querySelector(".tt-popup__minimize");o&&(o.textContent=e.minimized?"▲":"▼"),P(e)}))}function ot(e){var t,n;e._keyHandler&&document.removeEventListener("keydown",e._keyHandler),(t=e.popup)==null||t.remove(),e.popup=null,(n=e.onClose)==null||n.call(e)}function ne(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function fn(e,t){var s;te(),(s=document.getElementById("tt-popup"))==null||s.remove();const n=document.createElement("div");n.id="tt-popup",n.className="tt-popup",n.innerHTML=`
    <div class="tt-popup__header">
      <span class="tt-popup__title">TipTong</span>
      <div style="display:flex;gap:8px">
        <button class="tt-popup__minimize" title="Minimize">▼</button>
        <button class="tt-popup__close" title="Close">&times;</button>
      </div>
    </div>
    <div class="tt-popup__body"></div>
  `,document.body.appendChild(n);const o={exercises:e,currentIndex:0,state:e.length>0?Oe(e[0]):null,activeQueryId:null,showHints:!1,flashHint:null,minimized:!1,popup:n,suggested:null,suggestedFor:null,lastSuggestion:null,completedScores:[],onClose:t==null?void 0:t.onClose,onWordComplete:t==null?void 0:t.onWordComplete},r=i=>{if(i.key!=="Enter"||!o.popup)return;const d=o.popup.querySelector("[data-action='next']"),b=o.popup.querySelector("[data-action='close']");d?(i.preventDefault(),d.click()):b&&(i.preventDefault(),b.click())};document.addEventListener("keydown",r),o._keyHandler=r,P(o)}function mn(e,t,n){const o=e.slice(t,n),r=[],s=/[\p{L}\p{M}'']+/gu;let i;for(;(i=s.exec(o))!==null;)r.push({start:t+i.index,end:t+i.index+i[0].length});return r.length===0?{start:t,end:n}:r[Math.floor(Math.random()*r.length)]}function rt(e,t){if(t.cue&&(e.queries=e.queries.map(n=>({...n,customCues:[t.cue]}))),t.type==="hhh")for(const n of t.underlinedWords){if(!n.cue)continue;const o=n.start-t.sentenceStart,r=n.end-t.sentenceStart,s=e.queries.find(i=>i.startIndex<r&&i.endIndex>o);s&&(s.customCues=[...s.customCues??[],n.cue])}return e}function st(e){const t=[];for(const n of e)if(n.type==="qa"){const o=n.question+" "+n.answer,r=Pt(o,{question:{start:0,end:n.question.length},answer:{start:n.question.length+1,end:o.length}});r&&t.push(rt(r,n))}else{let o=n.underlinedWords;o.length===0&&(o=[mn(n.sourceText,n.sentenceStart,n.sentenceEnd)]);const r=zt({sourceText:n.sourceText,sentenceSelection:{start:n.sentenceStart,end:n.sentenceEnd},wordSelections:o});r&&t.push(rt(r,n))}return t}function bn(e,t){fn(st(e),t)}function xn(e){const t=st(e);return t.length===0?!1:(te(),Je(t),!0)}function it(e){var o,r;te(),(o=document.getElementById("tt-guide-overlay"))==null||o.remove();const t=document.createElement("div");t.id="tt-guide-overlay",t.className="tt-save-overlay",t.innerHTML=`<div class="tt-save-card tt-cue-card">
    <div class="tt-brand-row">
      ${Le(38)}
      <div>
        <h3 class="tt-brand-title" style="color:#FFFFFF !important">Turn this page into exercises</h3>
        <p class="tt-brand-kicker" style="color:#B6A6EB !important">Four steps, right on the text</p>
      </div>
    </div>
    <div class="tt-guide-steps">
      <div class="tt-guide-step"><span class="tt-guide-num">1</span>
        <div><b>Choose a mode</b>
          <p><span class="tt-guide-chip">HHH</span> fill-in-the-blanks from a sentence ·
             <span class="tt-guide-chip">Q&amp;A</span> question-and-answer pair</p>
        </div>
      </div>
      <div class="tt-guide-step"><span class="tt-guide-num">2</span>
        <div><b>Highlight 🖍</b>
          <p>Select text on the page — it becomes the exercise sentence
             (in Q&amp;A: first the question, then the answer).</p>
        </div>
      </div>
      <div class="tt-guide-step"><span class="tt-guide-num">3</span>
        <div><b>Hide 🙈</b>
          <p>Select words <i>inside</i> a highlight to underline them — those are
             what you’ll type during play. No underline? TipTong picks a word for you.</p>
        </div>
      </div>
      <div class="tt-guide-step"><span class="tt-guide-num">4</span>
        <div><b>Add a cue ✎</b>
          <p>Long-press a highlight or an underlined word and write a hint in
             your own words — it’s offered during play under “My cue”.</p>
        </div>
      </div>
    </div>
    <button class="tt-save-go-btn" id="tt-guide-go">Got it — let’s go</button>
    <p class="tt-brand-kicker" style="text-align:center;margin-top:10px !important">
      Reopen this guide anytime with the ? button in the toolbar</p>
  </div>`,document.body.appendChild(t);const n=()=>{t.remove()};(r=t.querySelector("#tt-guide-go"))==null||r.addEventListener("click",n),t.addEventListener("click",s=>{s.target===t&&n()}),document.addEventListener("keydown",function s(i){i.key==="Escape"&&(n(),document.removeEventListener("keydown",s))})}const Q={green:Y.brandEnergeticGreen,orange:Y.brandBrightOrange,dark:Y.brandDarkViolet},X={display:F.familyDisplay,sans:F.familySans,label:F.sizeLabel,body:F.sizeBody,small:F.sizeSmall},se={lg:ee.lg},at=window===window.top;function vn(){return typeof CSS>"u"||!("highlights"in CSS)||typeof window.Highlight!="function"?!1:[()=>!!window.__NEXT_DATA__,()=>!!document.querySelector("[data-reactroot]"),()=>!!document.querySelector("#__next"),()=>{const t=document.body;return t?Object.keys(t).some(n=>n.startsWith("__reactFiber")||n.startsWith("__reactInternalInstance")):!1},()=>{const t=document.getElementById("root")||document.getElementById("app");return t?t._reactRootContainer?!0:Object.keys(t).some(n=>n.startsWith("__reactFiber")||n.startsWith("__reactContainer")):!1},()=>!!document.getElementById("___gatsby"),()=>window.location.hostname.includes("perlego"),()=>/(^|\.)(chatgpt\.com|openai\.com|claude\.ai)$/.test(window.location.hostname),()=>{const t=document.querySelectorAll("body > *, body > * > *");for(const n of t)if(Object.keys(n).some(o=>o.startsWith("__reactFiber")||o.startsWith("__reactContainer")))return!0;return!1}].some(t=>{try{return t()}catch{return!1}})}function lt(){if(window.__tiptong){xe();return}te();const e=document.createElement("style");e.id="tt-suppress-host",e.textContent=`
    *, *::before, *::after {
      -webkit-user-select: text !important;
      user-select: text !important;
    }
    [class*="overlay"]:not([class*="tt-"]), [class*="Overlay"]:not([class*="tt-"]),
    [class*="mask"]:not([class*="tt-"]), [class*="Mask"]:not([class*="tt-"]),
    [class*="selection-layer"], [class*="SelectionLayer"] {
      pointer-events: none !important;
    }
    .highlighter-context, .highlighter-context * {
      pointer-events: auto !important;
      -webkit-user-select: text !important;
      user-select: text !important;
    }
    [class*="AnnotationToolbar"], [class*="annotationToolbar"],
    [class*="SelectionToolbar"], [class*="selectionToolbar"],
    [data-testid*="annotation"], [data-testid*="highlight"],
    [class*="Popover"], [class*="popover"],
    [class*="highlightMenu"], [class*="selectionPopover"],
    [class*="SelectionPopover"], [class*="tooltip-selection"] {
      display: none !important;
      visibility: hidden !important;
      pointer-events: none !important;
    }
  `,document.head.appendChild(e);const t=Selection.prototype.removeAllRanges,n=Selection.prototype.empty;Selection.prototype.removeAllRanges=function(){if(!(window.__tiptong&&!window.__tiptongClearing))return t.call(this)},Selection.prototype.empty=function(){if(!(window.__tiptong&&!window.__tiptongClearing))return n.call(this)},window.__tiptongSelectionRestore={origRemoveAllRanges:t,origEmpty:n};const o=vn();o&&console.log("[TipTong] Using CSS Highlight API (React site detected)");const r=o?an():Kt();window.__tiptong=r,at?wn(r):yn(r)}function wn(e){const t=document.createElement("div");t.id="tt-toolbar",t.style.cssText=`
    position: fixed; top: 0; left: 0; right: 0; z-index: 999998;
    background: ${U.gradient}; padding: 10px 16px;
    display: flex; align-items: center; gap: 10px;
    border-bottom: ${U.cardBorder};
    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
    font-family: ${X.sans};
  `,t.innerHTML=`
    <span style="color:${Q.green};font-family:${X.display};font-weight:800;font-size: ${X.body};margin-right:auto">TipTong</span>
    <div style="display:flex;background:rgba(255,255,255,0.15);border-radius: ${se.lg};overflow:hidden">
      <button data-tt-mode="hhh" style="background:white;border:none;color:${Q.dark};padding:6px 12px;font-size: ${X.small};font-weight:600;cursor:pointer;border-radius: ${se.lg}">HHH</button>
      <button data-tt-mode="qa" style="background:transparent;border:none;color:rgba(255,255,255,0.7);padding:6px 12px;font-size: ${X.small};font-weight:600;cursor:pointer;border-radius: ${se.lg}">Q&A</button>
    </div>
    <button id="tt-delete-btn" style="background:transparent;border:1px solid rgba(255,138,0,0.5);color:${Q.orange};padding:6px 12px;font-size: ${X.small};font-weight:600;cursor:pointer;border-radius: ${se.lg}">Delete</button>
    <span id="tt-status" style="color:rgba(255,255,255,0.7);font-size: ${X.small}">Select text to highlight</span>
    <button id="tt-save-btn" style="background:transparent;border:1px solid ${Q.green};color:${Q.green};padding:6px 14px;font-size: ${X.small};font-weight:bold;cursor:pointer;border-radius: ${se.lg}">Save</button>
    <button id="tt-play-btn" style="background:${Q.green};border:none;color:${Q.dark};padding:6px 16px;font-size: ${X.small};font-weight:bold;cursor:pointer;border-radius: ${se.lg}">Play</button>
    <button id="tt-guide-btn" title="How it works" style="background:none;border:1px solid rgba(255,255,255,0.3);color:white;font-size: ${X.small};font-weight:700;cursor:pointer;opacity:0.7;width:24px;height:24px;border-radius:50%;padding:0">?</button>
    <button id="tt-close-btn" style="background:none;border:none;color:white;font-size: ${X.label};cursor:pointer;opacity:0.6;padding:4px">&times;</button>
  `,document.body.appendChild(t),document.body.style.marginTop=t.offsetHeight+"px",t.querySelector("#tt-guide-btn").addEventListener("click",()=>it());try{chrome.storage.local.get("tt_guide_seen",g=>{g!=null&&g.tt_guide_seen||(it(),chrome.storage.local.set({tt_guide_seen:!0}))})}catch{}const n=t.querySelector("#tt-status"),o=t.querySelector("#tt-delete-btn");t.querySelectorAll("[data-tt-mode]").forEach(g=>{g.addEventListener("click",()=>{t.querySelectorAll("[data-tt-mode]").forEach(L=>{L.style.background="transparent",L.style.color="rgba(255,255,255,0.7)"}),g.style.background="white",g.style.color=Q.dark;const $=g.dataset.ttMode;e.setMode($),J({type:"tt:set-mode",mode:$}),r()})}),o.addEventListener("click",()=>{const g=e.toggleDeleteMode();o.style.background=g?Q.orange:"transparent",o.style.color=g?"white":Q.orange,o.textContent=g?"Done":"Delete",J({type:"tt:toggle-delete"})}),t.querySelector("#tt-play-btn").addEventListener("click",()=>{const g=e.getSelections();ct("tt:get-exercises",$=>{if(g.length===0&&$.length===0){n.textContent="No highlights yet";return}const L=e.validate();if(L.length>0){b(L[0]);return}e.isDeleteMode()&&e.toggleDeleteMode(),o.style.display="none",e.showAnswers(),e.hideAnswers(),e.hideUnderlinedWords(),J({type:"tt:prepare-play"});let _=e.getOrderedExerciseData();if($.length>0&&(_=_.concat($)),_.length===0){n.textContent="No complete exercises";return}bn(_,{onClose:()=>{e.showAnswers(),o.style.display="",J({type:"tt:end-play"})},onWordComplete:(c,p)=>{e.revealWord(c,p),J({type:"tt:reveal-word",word:c,exerciseIndex:p})}})})}),t.querySelector("#tt-save-btn").addEventListener("click",()=>{const g=e.validate();if(g.length>0){b(g[0]);return}ct("tt:get-exercises-data",$=>{const L=e.getOrderedExerciseData().concat($);if(L.length===0){n.textContent="No highlights yet";return}xn(L)||(n.textContent="No complete exercises")})}),window.addEventListener("message",g=>{var $;(($=g.data)==null?void 0:$.type)==="tt:status-update"&&i(g.data)});function r(){e.isDeleteMode()||(o.style.background="transparent",o.style.color=Q.orange,o.textContent="Delete"),J({type:"tt:request-status"}),s()}function s(){const g=e.getSelections();if(g.length===0){n.textContent="Select text to highlight";return}const $=g.filter(c=>c.role!=="sentence"),L=g.filter(c=>c.role==="sentence"),_=[];if($.length>0){const c=Math.floor($.length/2);_.push(`${c} Q&A${$.length%2!==0?" · answer next":""}`)}L.length>0&&_.push(`${L.length} HHH`),n.textContent=_.join(" + ")}function i(g){const $=e.getSelections(),L=$.filter(p=>p.role!=="sentence").length+g.qaCount,_=$.filter(p=>p.role==="sentence").length+g.hhhCount;if(L===0&&_===0){n.textContent="Select text to highlight";return}const c=[];if(L>0){const p=Math.floor(L/2);c.push(`${p} Q&A${L%2!==0?" · answer next":""}`)}_>0&&c.push(`${_} HHH`),n.textContent=c.join(" + ")}const d=()=>setTimeout(r,50);document.addEventListener("mouseup",d),t.querySelector("#tt-close-btn").addEventListener("click",()=>{J({type:"tt:teardown"}),xe()}),window.__tiptongCleanup={hl:e,onStatusUpdate:d},chrome.runtime.onMessage.addListener(g=>{g.type==="tiptong:toggle"&&(J({type:"tt:teardown"}),xe())});function b(g){var L;(L=document.querySelector(".tt-toast"))==null||L.remove();const $=document.createElement("div");$.className="tt-toast",$.textContent="⚠ "+g,document.body.appendChild($),setTimeout(()=>$.remove(),3e3)}}function yn(e){window.addEventListener("message",n=>{var o,r;if((r=(o=n.data)==null?void 0:o.type)!=null&&r.startsWith("tt:"))switch(n.data.type){case"tt:set-mode":e.setMode(n.data.mode);break;case"tt:toggle-delete":e.toggleDeleteMode();break;case"tt:request-status":{const s=e.getSelections();window.parent.postMessage({type:"tt:status-update",qaCount:s.filter(i=>i.role!=="sentence").length,hhhCount:s.filter(i=>i.role==="sentence").length},"*");break}case"tt:get-exercises":{e.showAnswers(),e.hideAnswers(),e.hideUnderlinedWords();const s=e.getOrderedExerciseData();window.parent.postMessage({type:"tt:exercises-response",data:s},"*");break}case"tt:get-exercises-data":{const s=e.getOrderedExerciseData();window.parent.postMessage({type:"tt:exercises-response",data:s},"*");break}case"tt:prepare-play":e.showAnswers(),e.hideAnswers(),e.hideUnderlinedWords();break;case"tt:end-play":e.showAnswers();break;case"tt:reveal-word":e.revealWord(n.data.word,n.data.exerciseIndex);break;case"tt:teardown":xe();break}});const t=()=>{setTimeout(()=>{const n=e.getSelections();window.parent.postMessage({type:"tt:status-update",qaCount:n.filter(o=>o.role!=="sentence").length,hhhCount:n.filter(o=>o.role==="sentence").length},"*")},50)};document.addEventListener("mouseup",t),window.__tiptongCleanup={hl:e,onStatusUpdate:t}}function J(e){var n;const t=document.querySelectorAll("iframe");for(const o of t)try{(n=o.contentWindow)==null||n.postMessage(e,"*")}catch{}}function ct(e,t){const n=document.querySelectorAll("iframe");if(n.length===0){t([]);return}const o=[];let r=0;const s=setTimeout(()=>t(o),500),i=d=>{var b;((b=d.data)==null?void 0:b.type)==="tt:exercises-response"&&(o.push(...d.data.data||[]),r++,r>=n.length&&(clearTimeout(s),window.removeEventListener("message",i),t(o)))};window.addEventListener("message",i),J({type:e})}function xe(){var o,r,s,i;const e=window.__tiptongCleanup;e&&(e.hl.showAnswers(),e.hl.destroy(),document.removeEventListener("mouseup",e.onStatusUpdate),delete window.__tiptongCleanup);const t=document.getElementById("tt-toolbar");t&&t.remove(),at&&(document.body.style.marginTop=""),(o=document.getElementById("tt-styles"))==null||o.remove(),(r=document.getElementById("tt-css-highlight-styles"))==null||r.remove(),(s=document.getElementById("tt-popup"))==null||s.remove(),(i=document.getElementById("tt-suppress-host"))==null||i.remove();const n=window.__tiptongSelectionRestore;n&&(Selection.prototype.removeAllRanges=n.origRemoveAllRanges,Selection.prototype.empty=n.origEmpty,delete window.__tiptongSelectionRestore),delete window.__tiptong}lt(),window.__tiptongInit=lt})();
